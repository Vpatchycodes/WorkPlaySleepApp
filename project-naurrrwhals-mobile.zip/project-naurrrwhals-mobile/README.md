# project-naurrrwhals-mobile
Mobile app for cis350/project-naurrrwhals.

## To run
Run ```npm run web``` from the ```naur_app_mobile``` directory.
