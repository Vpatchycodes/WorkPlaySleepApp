/* eslint-disable no-unused-vars */
import { StyleSheet } from 'react-native';

const {
  vw, vh, vmin, vmax,
} = require('react-native-viewport-units-fix');

const buttonStyle = StyleSheet.create({
  grayButton: {
    backgroundColor: '#a9a9a9',
    color: '#000000',
  },
});

const appStyle = StyleSheet.create({
  appBG: {
    textAlign: 'center',
    backgroundColor: '#006E90',
  },
});

const homepageStyle = StyleSheet.create({
  homepageWrapper: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100%',

  },
  navBar: {
    // position: 'absolute',
    backgroundColor: '#949EFF',
    // height: 15 * vh,
    minWidth: '100%',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    bottom: '0%',
    borderRadius: 10,
  },
  navButton: {
    maxWidth: '30%',
    paddingTop: '1%',
    paddingBottom: '1%',
    margin: '1%',
    backgroundColor: '#97FFF3',
    borderStyle: 'solid',
    borderWidth: 3,
    borderRadius: 10,
    textAlign: 'center',
  },
  textBox: {
    paddingTop: '1%',
    paddingBottom: '1%',
    margin: '1%',
    borderStyle: 'solid',
    padding: 1,
    borderWidth: 3,
    borderRadius: 10,
    backgroundColor: '#97FFF3',
  },
});

const messageStyle = StyleSheet.create({
  messagingWrapper: {
    // top: -5 * vh,
    margin: 50,
    textAlign: 'left',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  messageDisp: {
    position: 'relative',
    right: '0%',
    width: '73%',
    height: 80 * vh,
    backgroundColor: '#DBF6FC',
    borderWidth: 3,
    borderRadius: 10,
    zIndex: -1,
  },
});

const userControlStyle = StyleSheet.create({
  user_ctl: {
    position: 'relative',
    left: '0%',
    width: '27%',
    height: 80 * vh,
    backgroundColor: '#DBF6FC',
    borderWidth: 3,
    borderRadius: 10,
    zIndex: -1,
  },
  topIcon: {
    fontSize: 36,
    alignItems: 'center',
    paddingLeft: '3%',
    paddingTop: '1%',
    top: 0,
    right: 0,
    left: 0,
    borderStyle: 'solid',
    borderColor: '#1C5372',
    borderWidth: 3,
    borderRadius: 6,
  },
  firendList: {
    height: '56.5%',
  },
  messageIconWrapper: {
    position: 'absolute',
    alignItems: 'center',
    paddingTop: '3%',
    paddingBottom: '3%',
    bottom: 0,
    right: 0,
    left: 0,
    borderTopWidth: 3,
    borderBottomRightRadius: 10,
    borderBottomLeftRadius: 10,
    backgroundColor: '#DBF6FC',
  },
  messageButton: {
    width: '70%',
    aspectRatio: 1,
    paddingTop: '1%',
    paddingBottom: '1%',
    margin: '5%',
    textAlign: 'center',
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'center',
    backgroundColor: '#DBF6FC',
    fontSize: 36,
  },
});

const singleUserStyle = StyleSheet.create({
  single_user: {
    display: 'flex',
    maxWidth: 90 * vw,
    alignItems: 'center',
    justifyContent: 'center',
    borderStyle: 'solid',
    borderWidth: 3,
    borderRadius: 10,
    borderColor: '#1C5372',
  },
  options_disp: {
    alignItems: 'center',
  },
  actions_wrapper: {
    flexDirection: 'row',
  },
  actionButton: {
    borderWidth: 3,
    borderRadius: 10,
    backgroundColor: '#006E90',
    height: 40,
    minWidth: 20 * vw,
    marginTop: '2%',
    marginBottom: '2%',
    marginLeft: '4%',
    marginRight: '4%',
    flexDirection: 'column',
    justifyContent: 'center',
    color: '#FFFFFF',
  },
  actionText: {
    fontSize: 15,
    textAlign: 'center',
  },
  userButton: {
    position: 'relative',
    paddingTop: '5%',
    paddingBottom: '10%',
    backgroundColor: '#DBF6FC',
    textAlign: 'center',
  },
  unclicked: {
    paddingTop: '10%',
    paddingBottom: '5%',
    color: 'black',
  },
  clicked: {
    paddingTop: '10%',
    paddingBottom: '5%',
    color: 'blue',
    fontWeight: 'bold',
  },
});

const popUpStyle = StyleSheet.create({
  v_popup_box: {
    position: 'absolute',
    backgroundColor: '#00000050',
    borderRadius: 10,
    width: 100 * vw,
    height: 80 * vh,
    top: -40 * vh,
    left: 0,
    zIndex: 5,
  },
  v_box: {
    position: 'relative',
    alignItems: 'center',
    width: '100%',
    margin: 0,
    height: '100%',
    backgroundColor: '#DBF6FC',
    borderWidth: 4,
    borderRadius: 10,
    padding: 20,
    borderStyle: 'solid',
    borderColor: '#1C5372',
    overflow: 'scroll',
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
    color: '#1C5372',
  },
  v_close_btn: {
    position: 'absolute',
    alignItems: 'center',
    borderWidth: 3,
    borderRadius: 10,
    height: 40,
    aspectRatio: 1,
    marginTop: '5%',
    marginLeft: '5%',
    marginRight: '5%',
    top: 0,
    right: 0,
    flexDirection: 'column',
    justifyContent: 'center',
    color: '#1C5372',
    fontWeight: 'bold',
  },
  button_txt: {
    fontSize: 30,
    textAlign: 'center',
  },
  removebtn: {
    borderWidth: 3,
    borderRadius: 10,
    backgroundColor: '#006E90',
    height: 60,
    minWidth: 60 * vw,
    marginTop: '2%',
    marginBottom: '2%',
    marginLeft: '4%',
    marginRight: '4%',
    flexDirection: 'column',
    justifyContent: 'center',
    color: '#FFFFFF',
  },
  popup_content_wrapper: {
    position: 'absolute',
    top: 0,
    marginTop: 10 * vh,
    alignItems: 'center',
  },
  text_input: {
    marginTop: '5%',
    marginBottom: '5%',
    // minWidth: 50 * vw,
    borderStyle: 'solid',
    borderWidth: 2,
    borderRadius: 5,
    borderColor: '#00000050',
    fontSize: 20,
  },
});

const messageListStyle = StyleSheet.create({
  msg_list: {
    height: 62 * vh,
  },
  messagelist_date: {
    textAlign: 'center',
    backgroundColor: '#6a73fd',
  },
  msg_time: {
    fontSize: 10,
    marginTop: '1%',
  },
  my_msg: {
    marginTop: '1%',
    marginLeft: '13%',
    paddingTop: '2%',
    paddingBottom: '2%',
    backgroundColor: 'blue',
    borderRadius: 10,
  },
  my_msg_txt: {
    color: 'white',
    textAlign: 'right',
    right: '3%',
    marginLeft: '5%',
  },
  friend_msg: {
    marginTop: '1%',
    marginRight: '13%',
    paddingTop: '2%',
    paddingBottom: '2%',
    backgroundColor: 'gray',
    borderRadius: 10,
  },
  friend_msg_txt: {
    color: 'black',
    textAlign: 'left',
    left: '3%',
    marginRight: '3%',
  },
  img_msg: {
    marginTop: '2%',
    marginBottom: '2%',
    maxWidth: '100%',
    minHeight: 30 * vh,
  },
});

const sendMessageBoxStyle = StyleSheet.create({
  sendbtn_wrapper: {
    flexDirection: 'row',
    justifyContent: 'center',
    margin: 10,
  },
  sendbtn: {
    borderWidth: 2,
    borderRadius: 10,
    borderColor: '#014a44',
    backgroundColor: '#00c49d',
    height: 50,
    minWidth: 100,
    marginTop: '2%',
    marginBottom: '2%',
    marginLeft: '4%',
    marginRight: '4%',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  popup_wrapper: {
    height: 100 * vh,
    top: -37.5 * vh,
    left: -27.5 * vw,
  },
});

const pendingStyle = StyleSheet.create({
  list_box: {
    paddingTop: '5%',
    height: 65 * vh,
    minWidth: 50 * vw,
  },
});

export {
  buttonStyle, appStyle, homepageStyle, messageStyle,
  userControlStyle, singleUserStyle, popUpStyle, messageListStyle,
  sendMessageBoxStyle, pendingStyle,
};
