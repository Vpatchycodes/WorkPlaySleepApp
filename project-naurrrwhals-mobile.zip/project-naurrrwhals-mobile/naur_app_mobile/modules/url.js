const rootURL = 'http://10.102.112.216:80';

export default rootURL;
