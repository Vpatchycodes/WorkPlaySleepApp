/* eslint-disable react/prop-types */
import { React, useState } from 'react';
import {
  StyleSheet, View, Text, TextInput, Button,
} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
// import '../assets/Register.css';
const styles = StyleSheet.create({
  header: {
    backgroundColor: '#3EACB2',
  },
});
function SecurityQuestions({ setNewUserState }) {
  const [errorMessage, setErrorMessage] = useState('');
  const [sq1, setSq1] = useState('');
  const [sq2, setSq2] = useState('');
  const [sq3, setSq3] = useState('');

  const dropDownOptions = [
    { label: 'What is your mother\'s maidenname?', value: '5' },
    { label: 'What was the name of your first pet?', value: '4' },
    { label: 'What city were you born in?', value: '3' },
    { label: 'What is your oldest cousin\'s first name?', value: '2' },
    { label: 'What is your the middle name of your oldest child?', value: '1' },
  ];

  const dropDownOptions2 = [
    { label: 'What is your mother\'s maidenname?', value: '5' },
    { label: 'What was the name of your first pet?', value: '4' },
    { label: 'What city were you born in?', value: '3' },
    { label: 'What is your oldest cousin\'s first name?', value: '2' },
    { label: 'What is your the middle name of your oldest child?', value: '1' },
    { label: 'None', value: '6' },
  ];

  const [open1, setOpen1] = useState(false);
  const [value1, setValue1] = useState(null);
  const [items1, setItems1] = useState(dropDownOptions);

  const [open2, setOpen2] = useState(false);
  const [value2, setValue2] = useState(null);
  const [items2, setItems2] = useState(dropDownOptions2);

  const [open3, setOpen3] = useState(false);
  const [value3, setValue3] = useState(null);

  function handleSetSQ() {
    // e.preventDefault();
    // const sq1 = document.getElementById('sq1').value;
    if (!sq1) {
      setErrorMessage('You must include at least 1 security question.');
      return;
    }
    console.log(sq2);
    console.log(sq3);
    // call up to 3 posts depending on how many answers the user gives
    setNewUserState(false);
  }

  return (
    <View className="registrationWrapper">
      <View>
        <Text style={styles.h1}>Welcome!</Text>
      </View>
      <Text id="sec1">
        Security questions will be used for validation, should you need to reset your password.
      </Text>
      <Text className="error">
        &nbsp;
        {errorMessage}
      </Text>
      <View>
        <DropDownPicker
          dropDownContainerStyle={{
            backgroundColor: '#dfdfdf',
          }}
          open={open1}
          value={value1}
          items={items1}
          setOpen={setOpen1}
          setValue={setValue1}
          setItems={setItems1}
          placeholder="select question"
          onSelectItem={(item) => setSq1(item)}
          style={{ marginBottom: open1 ? 175 : 20 }}
        />
        <TextInput placeholder="Security Question 1" onChangeText={(text) => setSq1(text)} />
      </View>
      <View>
        <DropDownPicker
          dropDownContainerStyle={{
            backgroundColor: '#dfdfdf',
          }}
          style={{ marginBottom: open2 ? 175 : 20 }}
          open={open2}
          value={value2}
          items={items2}
          setOpen={setOpen2}
          setValue={setValue2}
          setItems={setItems2}
          placeholder="select question"
          onSelectItem={(item) => setSq2(item)}
        />
        <TextInput placeholder="Security Question 2" onChangeText={(text) => setSq2(text)} />
      </View>
      <View>
        <DropDownPicker
          dropDownContainerStyle={{
            backgroundColor: '#dfdfdf',
          }}
          style={{ marginBottom: open3 ? 175 : 20 }}
          open={open3}
          value={value3}
          items={items2}
          setOpen={setOpen3}
          setValue={setValue3}
          setItems={setItems2}
          placeholder="select question"
          onSelectItem={(item) => setSq3(item)}
        />
        <TextInput placeholder="Security Question 3" onChangeText={(text) => setSq3(text)} />
      </View>
      <View>
        <Button onPress={() => handleSetSQ()} title="Set" />
      </View>
    </View>
  );
}

export default SecurityQuestions;
