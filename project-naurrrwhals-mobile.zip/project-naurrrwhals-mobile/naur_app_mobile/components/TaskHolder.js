/* eslint-disable react/prop-types */
import { React, useState, useRef } from 'react'; // useState
import {
  StyleSheet, View, Button, TextInput, Text, ScrollView,
} from 'react-native';
import Tasks from './Tasks';
import {
  postNewTask, getTaskList,
} from '../modules/taskApi';

import { dateToStringLocal } from '../modules/timeFuncs';

// on passing functions to child and back up:
// https://stackoverflow.com/questions/38394015/how-to-pass-data-from-child-component-to-its-parent-in-reactjs
// const { v4: uuidv4 } = require('uuid');

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#3EACB2',
    width: '100%',
    fontFamily: 'cursive',
    fontSize: 30,
    fontWeight: 'bold',
    height: '20 px',
    color: 'white',
  },
  container: {
    backgroundColor: 'black',
    color: 'white',
  },
  text: {
    color: 'white',
  },
});

function rankOf(task) {
  return parseInt(task?.notes || '0', 10) || 0;
}

function noSorter(arr) {
  return arr;
}

function alphaSorter(arr) {
  return arr.sort((a, b) => {
    if (a.title < b.title) {
      return -1;
    } if (a.title > b.title) {
      return 1;
    }
    return 0;
  });
}

function dateSorter(arr) {
  return arr.sort((a, b) => {
    if (a.due_date < b.due_date) {
      return -1;
    } if (a.due_date > b.due_date) {
      return 1;
    }
    return 0;
  });
}

function rankSorter(arr) {
  return arr.sort((a, b) => {
    if (rankOf(a) < rankOf(b)) {
      return 1;
    } if (rankOf(a) > rankOf(b)) {
      return -1;
    }
    return 0;
  });
}

function TaskHolder({ username }) {
  const sortFunc = useRef(noSorter);
  const [taskList, setTaskList] = useState([]);
  const gotList = useRef(false);
  const newTextRef = useRef('');

  if (!gotList.current) {
    gotList.current = true;
    (async () => {
      setTaskList(sortFunc.current(await getTaskList(username)));
    })();
  }

  function handleAdd() {
    const title = newTextRef.current;
    if ((!title) || (!title?.length)) {
      return;
    }
    const date = dateToStringLocal(new Date());
    const rank = 0;
    const newTask = {
      title,
      due_date: date,
      notes: `${rank}`,
    };
    (async () => {
      await postNewTask(username, newTask);
      setTaskList(sortFunc.current(await getTaskList(username)));
    })();
  }

  function setSorter(sorter) {
    sortFunc.current = sorter;
    (async () => {
      setTaskList(sortFunc.current(await getTaskList(username)));
    })();
  }

  return (
    <View className="taskView">
      <View style={styles.header}>
        <Text>Here are your things!</Text>
      </View>
      <ScrollView className="task-body" id="parent">
        {
          taskList.map((task) => (
            <Tasks
              task={task}
              sortFunc={sortFunc}
              setTaskList={setTaskList}
              username={username}
            />
          ))
        }
      </ScrollView>
      <View>
        <View>
          <TextInput id="newTask" placeholder="new task here" onChangeText={(text) => { newTextRef.current = text; }} />
        </View>
        <View>
          <Button className="taskButton" title="Add" onPress={() => handleAdd()} />
          <Button className="taskButton" title="Sort by Name" onPress={() => { setSorter(alphaSorter); }} />
          <Button className="taskButton" title="Sort by Rank" onPress={() => { setSorter(rankSorter); }} />
          <Button className="taskButton" title="Sort by Date" onPress={() => { setSorter(dateSorter); }} />
          <Button className="taskButton" title="Don&apos;t Sort" onPress={() => { setSorter(noSorter); }} />
        </View>
      </View>
    </View>

  );
}

export default TaskHolder;
