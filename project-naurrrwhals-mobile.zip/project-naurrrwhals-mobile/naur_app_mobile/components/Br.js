/* eslint-disable no-nested-ternary */
// https://javascript.plainenglish.io/react-native-compensating-for-no-br-tag-5c44cd03f3d5

import React from 'react';
import { StyleSheet, View } from 'react-native';

const baseHeight = 6;
const makeStyles = ({
  double,
  triple,
  quad,
}) => StyleSheet.create({
  br: {
    height: quad ? 4 * baseHeight
      : triple ? 3 * baseHeight
        : double ? 2 * baseHeight
          : baseHeight,
  },
});

function Br({
  double,
  triple,
  quad,
}) {
  const styles = makeStyles({
    double,
    triple,
    quad,
  });
  return (
    <View style={styles.br} />
  );
}

export default Br;
