/* eslint-disable react/prop-types */
import { React, useState, useRef } from 'react';
import {
  StyleSheet, View, Button, TextInput, Text,
} from 'react-native';
// import DatePicker from 'react-mobile-datepicker';
// import DateTimePicker from '@react-native-community/datetimepicker';
import { MyDatePicker } from './DateTimePicker';
import { extractDateString } from '../modules/timeFuncs';
import { getTaskList, putTask, deleteTask } from '../modules/taskApi';

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#3EACB2',
    width: '100%',
    fontFamily: 'cursive',
    fontSize: 30,
    fontWeight: 'bold',
    height: '20 px',
    color: 'white',
  },
  container: {
    // backgroundColor: 'black',
    color: 'white',
  },
  text: {
    color: 'white',
  },
  complete: {
    width: '10%',
    backgroundColor: 'black',
  },
});

function rankOf(task) {
  return parseInt(task?.notes || '0', 10) || 0;
}

function Tasks({
  task, sortFunc, username, setTaskList,
}) {
  const [isInput, setIsInput] = useState(false);
  const newTitleRef = useRef('');

  async function readTasks() {
    setTaskList(sortFunc.current(await getTaskList(username)));
  }

  async function updateTasks(newTask) {
    await putTask(username, newTask.task_id, newTask);
    readTasks();
  }

  function rankUp() {
    const newTask = { ...task };
    if (!newTask?.task_id) {
      return;
    }
    newTask.notes = `${rankOf(newTask) + 1}`;
    updateTasks(newTask);
  }

  function titleChange() {
    const newTitle = newTitleRef.current;
    if (!newTitle || !newTitle?.length) {
      setIsInput(false);
      return;
    }
    const newTask = { ...task };
    if (!newTask?.task_id) {
      setIsInput(false);
      return;
    }
    newTask.title = newTitle;
    updateTasks(newTask);
    setIsInput(false);
  }

  function dateChange(newDate) {
    const newTask = { ...task };
    if (!newTask?.task_id) {
      return;
    }
    newTask.due_date = extractDateString(newDate);
    updateTasks(newTask);
  }

  function remove() {
    if (!task?.task_id) {
      return;
    }
    deleteTask(username, task.task_id).then(
      () => readTasks(),
      () => readTasks(),
    );
  }

  if (!isInput) {
    return (
      <>
        <View style={styles.container} className="btn-grp">
          <Button style={styles.complete} title="complete" onPress={() => remove()} />
          <Button onPress={() => rankUp()} style={{ width: '8%' }} title={`rank: ${rankOf(task)}`} />
          <Button
            title={`${task.title}`}
            className="taskButton"
            // id={task.id}
            onPress={() => setIsInput(!isInput)}
            style={{ width: '50%' }}
          />
          { /* <Text>Due Date: </Text> */ }
          <MyDatePicker
            testID="dateTimePicker"
            value={task.due_date}
            mode="date"
            onChange={(date) => dateChange(date)}
          />
        </View>
        <Text> &nbsp;</Text>
      </>
    );
  }
  return (
    <View style={styles.container} className="btn-grp" id="container">
      <Button type="submit" onPress={() => rankUp()} style={{ width: '8%' }} title={`rank: ${rankOf(task)}`} />
      <Button type="submit" onPress={() => rankUp()} style={{ width: '8%' }} title="rank" />
      <TextInput
        type="text"
        id="editTaskName"
        placeholder={task.title}
        onChangeText={(text) => { newTitleRef.current = text; }}
        style={{ width: '40%' }}
      />
      <Button
        title="update"
        onPress={titleChange}
        // style={{ width: '10%' }}
      />
      {/* <Button title={`${time}`} onPress={() => toggleIsOpen(true)} /> */}
      <Text>Due Date: </Text>
      {/* <input
        type="date"
      /> */}
      <MyDatePicker
        testID="dateTimePicker"
        value={task.due_date}
        mode="date"
        onChange={(date) => dateChange(date)}
      />
    </View>
  );
}

export default Tasks;
