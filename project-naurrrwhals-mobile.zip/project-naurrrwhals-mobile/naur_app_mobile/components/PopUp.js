import React from 'react';
import { View, Text, Pressable } from 'react-native';

import { popUpStyle } from '../assets/styles';

function PopUp(props) {
  const prop = props;
  return (
    <View>
      <View style={popUpStyle.v_popup_box}>
        <View style={popUpStyle.v_box}>
          <View style={popUpStyle.v_close_btn}>
            <Pressable
              title="pop-close-test"
              onPress={prop.handleClose}
            >
              <Text style={popUpStyle.button_txt}>{prop.closetext}</Text>
            </Pressable>
          </View>
          {prop.content}
        </View>
      </View>
    </View>
  );
}

export default PopUp;
