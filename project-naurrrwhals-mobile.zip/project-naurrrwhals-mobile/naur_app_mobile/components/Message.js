import React from 'react';
import PropTypes from 'prop-types';
import { Text, View, Image } from 'react-native';

import { messageListStyle } from '../assets/styles';

// eslint-disable-next-line no-unused-vars
function Message({
  message, user, sender, time,
}) {
  let boxStyle = messageListStyle.friend_msg;
  let textStyle = messageListStyle.friend_msg_txt;
  let messageBody;
  if (user === sender) {
    boxStyle = messageListStyle.my_msg;
    textStyle = messageListStyle.my_msg_txt;
  }
  if (message.imageURL) {
    messageBody = (
      <Image
        style={messageListStyle.img_msg}
        source={{ uri: message.imageURL }}
        alt="Invalid URL"
        resizeMode="contain"
      />
    );
  } else {
    messageBody = <Text style={textStyle}>{message.msgText}</Text>;
  }

  return (
    <View style={boxStyle}>
      {messageBody}
      <View>
        <Text style={[messageListStyle.msg_time, textStyle]}>{time}</Text>
      </View>
    </View>
  );
}
Message.propTypes = {
  // eslint-disable-next-line react/forbid-prop-types
  message: PropTypes.object.isRequired,
  user: PropTypes.string.isRequired,
  sender: PropTypes.string.isRequired,
  time: PropTypes.string.isRequired,
};

export default Message;
