/* eslint-disable react/prop-types */
/* eslint-disable camelcase */

import React, { useState } from 'react';
import {
  View, Button, StyleSheet, Text, TextInput,
} from 'react-native';
import NumberPlease from 'react-native-number-please';
import { RadioButton } from 'react-native-paper';
import {
  PUT_desiredHoursRelax, PUT_desiredHoursSleep, PUT_desiredHoursWork,
  PUT_desiredRelaxActivity, PUT_desiredWorkBlock, PUT_desiredWorkEndTime,
  PUT_desiredTimeSleep,
} from '../modules/wellnessApi';

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'black',
    color: 'white',
  },
  text: {
    color: 'white',
  },
  h1: {

  },
  h2: {

  },
  dropdown: {
    marginBottom: '70px',
  },
});

function Priority({ data, username }) {
  const [sleepGoalHr, setSleepGoalHr] = useState([{ id: 'hours', value: 8 }]);
  const [sleepGoalTime, setSleepGoalTime] = useState(2200);
  const [workGoalHr, setWorkGoalHr] = useState([{ id: 'hours', value: 8 }]);
  const [workBlock, setWorkBlock] = useState([{ id: 'hours', value: 8 }]);
  const [workEndTime, setWorkEndTime] = useState(2200);
  const [relaxGoalHr, setRelaxGoalHr] = useState([{ id: 'hours', value: 8 }]);
  const [relaxActivity, setRelaxActivity] = useState('Ride a bike');
  const [isSub, setIsSub] = useState(0);

  const [checked, setChecked] = React.useState('AM');

  const [bedTimeHr, setBedTimeHr] = useState([{ id: 'hours', value: 10 }]);
  const [bedTimeMin, setBedTimeMin] = useState([{ id: 'min', value: 0 }]);

  const [workTimeHr, setWorkTimeHr] = useState([{ id: 'hours', value: 10 }]);
  const [workTimeMin, setWorkTimeMin] = useState([{ id: 'min', value: 0 }]);

  // const [sleep, setSleep] = useState([{ id: 'hours', value: 8 }]);
  const hourNumbers = [{
    id: 'hours', label: 'hrs', min: 0, max: 24,
  }];
  const minNumbers = [{
    id: 'minutes', label: 'min', min: 0, max: 60,
  }];

  // defaults in case user doesn't change selections
  PUT_desiredTimeSleep(username, sleepGoalTime);
  PUT_desiredHoursSleep(username, sleepGoalHr);
  PUT_desiredHoursWork(username, workGoalHr);
  PUT_desiredWorkBlock(username, workBlock);
  PUT_desiredWorkEndTime(username, workEndTime);
  PUT_desiredHoursRelax(username, relaxGoalHr);
  PUT_desiredRelaxActivity(username, relaxActivity);

  function handleSleepHours(e) {
    setSleepGoalHr(e);
    PUT_desiredHoursSleep(username, sleepGoalHr.value);
  }

  function handleSleepTimeHr(e) {
    setBedTimeHr(e[0].value);
    setSleepGoalTime(e[0].value * 100);
    PUT_desiredTimeSleep(username, sleepGoalTime);
  }

  function handleSleepTimeMin(e) {
    setBedTimeMin(e[0].value);
    setSleepGoalTime(sleepGoalTime + e[0].value);
    PUT_desiredTimeSleep(username, sleepGoalTime);
  }

  function handleSleepTimeM(e) {
    setChecked(e);
    if (e === 'PM') {
      setSleepGoalTime(sleepGoalTime + 1200);
      PUT_desiredTimeSleep(username, sleepGoalTime);
    }
  }

  function handleWorkHours(e) {
    console.log('handleWorkHours: problem here?');
    setWorkGoalHr(e);
    PUT_desiredHoursWork(username, workGoalHr.value);
  }

  function handleWorkBlock(e) {
    console.log('handleWorkBlock: problem here?');
    setWorkBlock(e);
    PUT_desiredWorkBlock(username, workBlock.value);
  }

  function handleWorkTimeHr(e) {
    setWorkTimeHr(e[0].value);
    setWorkEndTime(e[0].value * 100);
    PUT_desiredWorkEndTime(username, workEndTime);
  }

  function handleWorkTimeMin(e) {
    setWorkTimeMin(e);
    setWorkEndTime(workEndTime + e[0].value);
    PUT_desiredWorkEndTime(username, workEndTime);
  }

  function handleWorkTimeM(e) {
    setChecked(e);
    if (e === 'PM') {
      setWorkEndTime(workEndTime + 1200);
      PUT_desiredWorkEndTime(username, workEndTime);
    }
  }

  function handleRelaxHours(e) {
    setRelaxGoalHr(e);
    PUT_desiredHoursRelax(username, relaxGoalHr.value);
  }

  function handleRelaxActivity(e) {
    console.log('133: problem here?');
    console.log(e);
    console.log(e.target.value);
    setRelaxActivity(e.target.value);
    console.log('135: problem here?');
    PUT_desiredRelaxActivity(username, relaxActivity);
    console.log('137: problem here?');
  }

  if (isSub === 1) {
    return (
      <View>
        <Text style={styles.h1}>
          {' '}
          Welcome back,
          {' '}
          {username}
        </Text>
        <Text style={styles.h2}> Curating an amazing day for you </Text>
      </View>
    );
  }

  if (data[0] === 'Sleep') {
    return (
      <View>
        <Text style={styles.h2}>Let&apos;s optimize sleep for today</Text>
        <View>
          <Text style={styles.h4}>Desired Sleep (Hours)</Text>
          <NumberPlease
            digits={hourNumbers}
            values={sleepGoalHr}
            onChange={(values) => handleSleepHours(values)}
          />
          {/* <input type="number" id="desiredHoursSleep" placeholder="8" min="0"
          max="24" step="1" onChange={handleSleepHours} /> */}
          <Text style={styles.h2}>Desired Bedtime</Text>
          <NumberPlease
            digits={hourNumbers}
            values={bedTimeHr}
            onChange={(values) => handleSleepTimeHr(values)}
          />
          <NumberPlease
            digits={minNumbers}
            values={bedTimeMin}
            onChange={(values) => handleSleepTimeMin(values)}
          />
          <Text>
            <RadioButton
              status={checked === 'AM' ? 'checked' : 'unchecked'}
              onPress={() => handleSleepTimeM('AM')}
              value="AM"
            />
            AM
          </Text>
          <Text>
            <RadioButton
              status={checked === 'PM' ? 'checked' : 'unchecked'}
              onPress={() => handleSleepTimeM('PM')}
              value="PM"
            />
            PM
          </Text>
        </View>
        <Button onPress={() => setIsSub(1)} title="Start your day" />
      </View>
    );
  }

  if (data[0] === 'Work') {
    return (
      <View>
        <Text style={styles.h2}>Let&apos;s optimize work for today</Text>
        <View>
          <Text style={styles.h2}>Desired Work (Hours)</Text>
          <NumberPlease
            digits={hourNumbers}
            values={workGoalHr}
            onChange={(values) => handleWorkHours(values)}
          />
          <Text style={styles.h2}>Desired Work Block (Minutes)</Text>
          <NumberPlease
            digits={minNumbers}
            values={workBlock}
            onChange={(values) => handleWorkBlock(values)}
          />
          <Text style={styles.h2}>Desired Endtime</Text>
          <NumberPlease
            digits={hourNumbers}
            values={workTimeHr}
            onChange={(values) => handleWorkTimeHr(values)}
          />
          <NumberPlease
            digits={minNumbers}
            values={workTimeMin}
            onChange={(values) => handleWorkTimeMin(values)}
          />
          <Text>
            <RadioButton
              status={checked === 'AM' ? 'checked' : 'unchecked'}
              onPress={() => handleWorkTimeM('AM')}
              value="AM"
            />
            AM
          </Text>
          <Text>
            <RadioButton
              status={checked === 'PM' ? 'checked' : 'unchecked'}
              onPress={() => handleWorkTimeM('PM')}
              value="PM"
            />
            PM
          </Text>
        </View>
        <Button onPress={() => setIsSub(1)} title="Start your day" />
      </View>
    );
  }

  return (
    <View>
      <Text style={styles.h2}>Let&apos;s optimize relaxation for today</Text>
      <View>
        <Text style={styles.h2}>Desired Relaxation (Hours)</Text>
        <NumberPlease
          digits={hourNumbers}
          values={relaxGoalHr}
          onChange={(values) => handleRelaxHours(values)}
        />
        <Text style={styles.h2}>Desired Activity for Today</Text>
        <TextInput id="desiredRelaxActivity" placeholder="Ride a bike" onChange={(text) => handleRelaxActivity(text)} />
      </View>
      <Button onPress={() => setIsSub(1)} title="Start your day" />
    </View>
  );
}

export default Priority;
