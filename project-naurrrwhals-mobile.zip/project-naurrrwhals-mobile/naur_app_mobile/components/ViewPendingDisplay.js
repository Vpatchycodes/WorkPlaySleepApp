/* eslint-disable no-unused-vars */
import {
  React, useState, useEffect,
} from 'react';
import PropTypes from 'prop-types';
import {
  View, Text,
} from 'react-native';

import FriendList from './FriendList';
import { getPendingList, getPendingFirst, undoFriendRequest } from '../modules/messageApi';

import { popUpStyle, pendingStyle } from '../assets/styles';

function ViewPendingDisplay({ username }) {
  const [loadPendingList, setLoadPendingList] = useState(true);
  const [list, setList] = useState(undefined);
  const [selected, setSelected] = useState(undefined);

  const handleUndoRequest = () => {
    undoFriendRequest(username, selected).then(() => {
      setLoadPendingList(!loadPendingList);
    });
  };

  useEffect(() => {
    getPendingList(username).then((pendinglist) => {
      setList(pendinglist);
      getPendingFirst(username).then((first) => {
        setSelected(first);
      });
    });
  }, [loadPendingList]);

  return (

    <View style={popUpStyle.popup_content_wrapper}>
      <Text style={popUpStyle.button_txt}>Pending Friend Requests</Text>
      <View style={pendingStyle.list_box}>
        {(list !== undefined) && (selected !== undefined) && (
          <FriendList
            list={list}
            selected={selected}
            setSelected={setSelected}
            setActionOne={handleUndoRequest}
            actionTextOne="Remove"
          />
        )}
      </View>
    </View>
  );
}
ViewPendingDisplay.propTypes = {
  username: PropTypes.string.isRequired,
};

export default ViewPendingDisplay;
