/* eslint-disable no-unused-vars */
import {
  React, useEffect, useState,
} from 'react';
import PropTypes from 'prop-types';
import { View, Pressable, Text } from 'react-native';

import AntIcon from 'react-native-vector-icons/AntDesign';
import MaterialIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import FAIcon from 'react-native-vector-icons/FontAwesome';

import FriendList from './FriendList';
import { getFriendList, getFriendFirst } from '../modules/messageApi';

import { userControlStyle } from '../assets/styles';

function UserControl({
  username, selected, setSelected, time, setOptionsOpened, setPopUp, loadData, setLoadData,
}) {
  const [friendList, setFriends] = useState(undefined);

  const handleAddFriend = (e) => {
    e.preventDefault();
    setPopUp('add friend');
  };

  const handleViewPending = (e) => {
    e.preventDefault();
    setPopUp('view pending');
  };

  const handleConfirmRequest = (e) => {
    e.preventDefault();
    setPopUp('confirm request');
  };

  useEffect(() => {
    getFriendList(username).then((list) => {
      setFriends(list);
      if (list.includes(selected)) {
        return;
      }
      getFriendFirst(username).then((first) => {
        setSelected(first);
      });
    });
  }, [loadData, time]);

  return (
    <View style={userControlStyle.user_ctl}>
      <View style={userControlStyle.topIcon}>
        <FAIcon name="envelope-o" size={40} />
      </View>
      {(friendList !== undefined) && (
      <View style={userControlStyle.firendList}>
        <FriendList
          list={friendList}
          selected={selected}
          setSelected={setSelected}
          setActionOne={setOptionsOpened}
          actionTextOne="Options"
        />
      </View>
      )}
      <View style={userControlStyle.messageIconWrapper}>
        <Pressable style={userControlStyle.messageButton} title="Send Friend Request" onPress={handleAddFriend}>
          <View style={userControlStyle.messageIconInterior}>
            <AntIcon name="plussquareo" size={60} />
          </View>
        </Pressable>
        <Pressable style={userControlStyle.messageButton} title="View Pending Requests" onPress={handleViewPending}>
          <View style={userControlStyle.messageIconInterior}>
            <AntIcon name="hourglass" size={60} />
          </View>
        </Pressable>
        <Pressable style={userControlStyle.messageButton} title="Confirm Friend Requests" onPress={handleConfirmRequest}>
          <View style={userControlStyle.messageIconInterior}>
            <MaterialIcon name="email-receive-outline" size={60} />
          </View>
        </Pressable>
      </View>
    </View>
  );
}

UserControl.propTypes = {
  username: PropTypes.string.isRequired,
  selected: PropTypes.string,
  setSelected: PropTypes.func.isRequired,
  time: PropTypes.number.isRequired,
  setOptionsOpened: PropTypes.func.isRequired,
  setPopUp: PropTypes.func.isRequired,
  loadData: PropTypes.bool.isRequired,
  setLoadData: PropTypes.func.isRequired,
};

UserControl.defaultProps = {
  selected: undefined,
};

export default UserControl;
