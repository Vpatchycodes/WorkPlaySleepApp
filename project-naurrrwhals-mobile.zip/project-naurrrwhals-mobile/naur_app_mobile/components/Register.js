
/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { React, useState } from 'react';
import {
  StyleSheet, View, Text, TextInput, Button,
} from 'react-native';
// import '../assets/Register.css';
import { postRegister } from '../modules/loginStorage';
import { postMessagingUser } from '../modules/messageStorage';

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#3EACB2',
    width: '100%',
    fontFamily: 'cursive',
    fontSize: 30,
    fontWeight: 'bold',
    height: '20 px',
    color: 'white',
  },
  container: {
    backgroundColor: 'black',
    color: 'white',
  },
  text: {
    color: 'white',
  },
  h1: {

  },
  h2: {

  },
  dropdown: {
    marginBottom: '70 px',
  },
});
function usernameError(str) {
  if (!str.match(/^[A-Za-z0-9_]*$/)) {
    return 'Username must be made up of letters, numbers, or underscores';
  }
  if (!str.match(/^[A-Za-z_][A-Za-z0-9_]*$/)) {
    return 'Username must start with a letter or underscore';
  }
  if (!str.match(/[A-Za-z0-9]/)) {
    return 'Username must contain contain at least one letter or number';
  }
  if (!(str.length >= 3)) {
    return 'Username must be at least 3 characters long';
  }
  return '';
}

// Returns error if the given string is not a valid password
function passwordError(str) {
  if (!str.match(/^[A-Za-z0-9\\!"#$%&'()*+,\-./:;<=>?@[\]^_`{|}~]+$/)) {
    return 'Password contains illegal character';
  }
  if (!(str.length >= 6)) {
    return 'Password must be at least 6 characters long';
  }
  return '';
}

function Register({ setNewUserState, setSQs }) {
  const [errorMessage, setErrorMessage] = useState('');
  const [userName, setUserName] = useState('');
  const [userPass, setUserPass] = useState('');

  function handleUsernameInput(name) {
    console.log(`name: ${name}`);
    // const name = e.target.value;
    if (name === '') {
      setErrorMessage('');
    } else {
      setErrorMessage(usernameError(name));
      setUserName(name);
    }
  }

  function handlePasswordInput(pword) {
    if (pword === '') {
      setErrorMessage('');
    } else {
      setErrorMessage(passwordError(pword));
      setUserPass(pword);
    }
  }

  function handleRegister() {
    console.log(`in handleRegister: name = ${userName}`);
    const name = userName;
    const pword = userPass;
    const nameErr = usernameError(name);
    const pwordErr = passwordError(pword);
    if (nameErr) {
      setErrorMessage(nameErr);
      return;
    }
    if (pwordErr) {
      setErrorMessage(pwordErr);
      return;
    }

    (async function handleRegisterAsync() {
      const status = await postRegister(name, pword);
      if (status === 403) {
        setErrorMessage('User already exists');
        return;
      }
      if ((status < 200) || (status >= 300)) {
        setErrorMessage('An unknown error occured');
        return;
      }
      await postMessagingUser(name);
      // eslint-disable-next-line no-param-reassign
      // setNewUserState(false);
      setSQs(true);
    }());
  }

  function handleBack() {
    setNewUserState(false);
  }

  return (
    <View className="registrationWrapper">
      <View>
        <Text style={styles.h1}>Welcome!</Text>
      </View>
      <View id="sec1">
        <Text>tell us a little about yourself</Text>
      </View>
      <View>
        <View className="error">
          <Text>
            &nbsp;
            {' '}
            {errorMessage}
          </Text>
        </View>
        <View onSubmit={() => handleRegister}>
          <Text>CONFIRM USERNAME*</Text>
          <TextInput placeholder="Johndoe" onChangeText={(text) => handleUsernameInput(text)} />
          <Text>CONFIRM PASSWORD*</Text>
          <TextInput placeholder="password123" onChangeText={(pword) => handlePasswordInput(pword)} />
        </View>
        <Button className="lButtons" onPress={() => handleRegister()} title="Register" />
        <Button className="lButtons" onPress={() => handleBack()} title="Back" />
      </View>
    </View>
  );
}

export default Register;
