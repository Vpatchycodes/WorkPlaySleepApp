/* eslint-disable react/prop-types */
import React, { useRef, useState } from 'react';
import { FaCalendarAlt } from 'react-icons/fa';
import ColorPicker from 'react-native-wheel-color-picker';
import DropDownPicker from 'react-native-dropdown-picker';
import Svg, {
  G,
  TSpan,
  Text,
  Rect,
} from 'react-native-svg';

import {
  StyleSheet, View, TextInput, Button,
} from 'react-native';
import { MyDatePicker, MyTimePicker } from './DateTimePicker'; // '@react-native-community/datetimepicker';

import {
  getCalendarEventList, postCalendarEventCreate,
  deleteCalendarEventEventID,
  getCalendarBlobList, postCalendarBlobCreate,
  postCalendarBlobBlobID, deleteCalendarBlobBlobID,
} from '../modules/calendarApi';

import {
  dateToStringLocal, combineDateTimeString, extractTimeString,
  stringToDatetimeLocal, stringToDateLocal, extractDateString,
  getCurrentTimeString,
} from '../modules/timeFuncs';

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#3EACB2',
    width: '100%',
    fontFamily: 'cursive',
    fontSize: 30,
    fontWeight: 'bold',
    height: '20 px',
    color: 'white',
  },
  container: {
    backgroundColor: 'black',
    color: 'white',
  },
  Text: {
    color: 'white',
  },
  h1: {

  },
  h2: {

  },
  dropdown: {
    marginBottom: '70 px',
  },
});

function Calendar({ username }) {
  const [date, setDate] = useState(dateToStringLocal(new Date()));

  // eslint-disable-next-line no-unused-vars
  const [_updateListValue, updateLists] = useState(0);

  return (
    <CalendarContainer
      username={username}
      date={date}
      setDate={setDate}
      eventListPromise={getCalendarEventList(username)}
      blobListPromise={getCalendarBlobList(date, username)}
      updateLists={updateLists}
    />
  );
}

function CalendarContainer({
  username, date, setDate, eventListPromise, blobListPromise, updateLists,
}) {
  const [eventList, setEventList] = useState([]);
  eventListPromise.then((value) => { setEventList(value); });
  const [blobList, setBlobList] = useState([]);
  blobListPromise.then((value) => { setBlobList(value); });

  const [selectedBlob, setSelectedBlob] = useState(null);

  const [selectedEvent, setSelectedEvent] = useState(null);

  // console.log('CalendarContainer rerendered');
  // console.log('eventList value:');
  // console.log(eventList);

  return (
    <View id="calendar">
      <View id="editBar">
        <View id="topBar">
          <FaCalendarAlt id="top" />
          <Text>{'\n'}</Text>
          <DatePicker date={date} setDate={setDate} setSelectedBlob={setSelectedBlob} />
          <Text>{'\n'}</Text>
        </View>
        <EventAdder username={username} updateLists={updateLists} />
        <Text>{'\n'}</Text>
        <BlobAdder
          username={username}
          eventList={eventList}
          date={date}
          updateLists={updateLists}
          selectedEvent={selectedEvent}
          setSelectedEvent={setSelectedEvent}
        />
        <Text>{'\n'}</Text>
      </View>
      <CalendarView
        blobList={blobList}
        selectedBlob={selectedBlob}
        setSelectedBlob={setSelectedBlob}
      />
      <BlobEditor
        username={username}
        date={date}
        selectedBlob={selectedBlob}
        setSelectedBlob={setSelectedBlob}
        updateLists={updateLists}
      />
    </View>
  );
}

function EventAdder({ username, updateLists }) {
  const eventNameRef = useRef('Default Event Name');
  const eventColorRef = useRef('#888888');

  function createEvent() {
    (async function anon1BlobAdder() {
      await postCalendarEventCreate(username, eventNameRef.current, eventColorRef.current);
      updateLists((val) => (!val));
    }());
  }

  // console.log('EventAdder rerendered');

  return (
    <View id="eventadder">
      <View>
        <Text style={styles.h3}>Create New Event</Text>
      </View>
      <View>
        <Text>
          Event Name:&nbsp;
          <TextInput
            id="eventnameinput"
            placeholder="Default Event Name"
            onChangeText={(text) => { eventNameRef.current = text; }}
          />
        </Text>
      </View>
      <View>
        <Text>
          Event Color:&nbsp;
        </Text>
        <ColorPicker
          color={eventColorRef.current}
          onColorChange={(color) => { eventColorRef.current = color; }}
          onColorChangeComplete={(color) => { eventColorRef.current = color; }}
          swatches={false}
          sliderHidden
        />
      </View>
      <View>
        <Button
          title="Create New Event"
          onPress={() => createEvent()}
        />
      </View>
    </View>
  );
}

function BlobAdder({
  username, eventList, updateLists, date, selectedEvent, setSelectedEvent,
}) {
  // console.log('BlobAdder rerendered');
  // console.log('eventList value:');
  // console.log(eventList);

  const dropDownOptions = eventList.map((event) => ({ label: event.name, value: event.event_id }));

  const [open, setOpen] = useState(false);
  const [value, setValue] = useState('');

  const startTimeRef = useRef(getCurrentTimeString());
  const endTimeRef = useRef(getCurrentTimeString());
  // const [items, setItems] = useState(dropDownOptions);
  // const [selectedEvent, setSelectedEvent] = useState(null);
  // const [startTime, setStartTime] = useState(new Date());
  // const [endTime, setEndTime] = useState(new Date());
  function createBlob() {
    const eventID = selectedEvent;
    const startDateTime = combineDateTimeString(date, startTimeRef.current);
    const endDateTime = combineDateTimeString(date, endTimeRef.current);
    // console.log(eventID);
    // console.log(startDateTime);
    // console.log(endDateTime);
    if (!eventID || !startDateTime || !endDateTime) {
      return;
    }
    (async function anon1BlobAdder() {
      await postCalendarBlobCreate(eventID, username, startDateTime, endDateTime);
      updateLists((val) => (!val));
    }());
  }

  // TODO: Fix this
  function deleteEvent() {
    // const eventPicker = selectedEvent;
    // const eventID = eventPicker.value;
    const eventID = selectedEvent;
    if (!eventID?.length) {
      return;
    }
    (async function anon2BlobAdder() {
      await deleteCalendarEventEventID(eventID, username);
      updateLists((val) => (!val));
    }());
  }

  return (
    <View id="blobadder">
      <View>
        <Text style={styles.h3}>Add Events to Calendar</Text>
      </View>
      <View>
        <Text>
          Event:&nbsp;
          <DropDownPicker
            open={open}
            value={value}
            items={dropDownOptions}
            setOpen={setOpen}
            setValue={setValue}
            placeholder="Select an event"
            onSelectItem={(event) => setSelectedEvent(event.value)}
          />
        </Text>
      </View>
      <Text>&nbsp;</Text>
      <Text>
        Start time:&nbsp;
        <MyTimePicker
          testID="dateTimePicker"
          value={startTimeRef.current}
          mode="time"
          onChange={(time) => { startTimeRef.current = time; }}
        />
      </Text>
      <Text>
        End time:&nbsp;
        <MyTimePicker
          testID="dateTimePicker"
          value={endTimeRef.current}
          mode="time"
          onChange={(time) => { endTimeRef.current = time; }}
        />
      </Text>
      <Text>{'\n'}</Text>
      <View>
        <Button title="Delete Event" onPress={deleteEvent} />
        <Button title="Create New Blob" onPress={createBlob} />
      </View>
    </View>
  );
}

// TODO: ^ COME BACK TO FIX TIME SHTUFF

function BlobEditor({
  username, date, updateLists, selectedBlob, setSelectedBlob,
}) {
  const startTimeRef = useRef(getCurrentTimeString());
  const endTimeRef = useRef(getCurrentTimeString());

  function editBlob() {
    const startDateTime = combineDateTimeString(date, startTimeRef.current);
    const endDateTime = combineDateTimeString(date, endTimeRef.current);
    setSelectedBlob(null);
    (async function anon1BlobEditor() {
      await postCalendarBlobBlobID(
        selectedBlob.blob_id,
        selectedBlob.event.event_id,
        username,
        startDateTime,
        endDateTime,
      );
      updateLists((val) => (!val));
    }());
  }

  function deleteBlob() {
    setSelectedBlob(null);
    (async function anonwBlobEditor() {
      await deleteCalendarBlobBlobID(
        selectedBlob.blob_id,
        selectedBlob.event.event_id,
        username,
      );
      updateLists((val) => (!val));
    }());
  }

  const prevBlob = useRef(null);
  if (!selectedBlob) {
    startTimeRef.current = '';
    endTimeRef.current = '';
  } else if (prevBlob.current !== selectedBlob) {
    startTimeRef.current = extractTimeString(selectedBlob.time.start);
    endTimeRef.current = extractTimeString(selectedBlob.time.end);
  }

  prevBlob.current = selectedBlob;

  // console.log('BlobEditor rerendered');

  return (
    <View id="blobeditor">
      <View>
        <Text style={styles.h3}>Edit Event on Calendar</Text>
      </View>
      <View>
        <Text>
          Start time:&nbsp;
          <MyTimePicker
            testID="dateTimePickerModify"
            value={startTimeRef.current}
            mode="time"
            onChange={(time) => { startTimeRef.current = time; }}
          />
        </Text>
        <Text>
          End time:&nbsp;
          <MyTimePicker
            testID="dateTimePickerModify"
            value={endTimeRef.current}
            mode="time"
            onChange={(time) => { endTimeRef.current = time; }}
          />
        </Text>
      </View>
      <Text>&nbsp;</Text>
      <View>
        {/* <label htmlFor="endtimepickermodify">
          End time:&nbsp;
          <input type="time" className="calLabel" id="endtimepickermodify" />
        </label> */}

      </View>
      <Text>{'\n'}</Text>
      <Button onPress={editBlob} title="Edit Blob Time" />
      <Button onPress={deleteBlob} title="Delete Blob" />
      {/* <input type="button" value="Edit Event Time" className="calLabel" onClick={editBlob} />
      <input type="button" value="Delete Event" className="calLabel" onClick={deleteBlob} /> */}
    </View>
  );
}

function DatePicker({ date, setDate, setSelectedBlob }) {
  function dateChanged(e) {
    // if (e.target.value) {
    //   setSelectedBlob(null);
    //   setDate(e.target.value);
    // }
    if (e) {
      setSelectedBlob(null);
      setDate(e);
    }
  }

  return (
    // <label htmlFor="datepicker">
    //   Choose date:&nbsp;
    //   <input type="date" id="datepicker" defaultValue={date} onChange={dateChanged} />
    // </label>
    <View>
      <Text>Choose date:&nbsp;</Text>
      <MyDatePicker
        testID="dateTimePicker"
        value={date}
        mode="time"
        onChange={(time) => dateChanged(time)}
      />
    </View>
  );
}

const calendarWidth = 400;
const calendarHeight = 1000;
const calendarPadL = 50;
const calendarPadR = 10;
const calendarPadU = 10;
const calendarPadD = 10;

function CalendarView({ blobList, selectedBlob, setSelectedBlob }) {
  const hourList = Array.from({ length: 24 }, (_x, i) => i);
  // console.log('CalendarView rerendered');
  // console.log(blobList);
  return (
    <View className="calendarview">
      <Svg
        width={calendarPadL + calendarWidth + calendarPadR}
        height={calendarPadU + calendarHeight + calendarPadD}
      >
        <Rect x={calendarPadL} y={calendarPadU} width={calendarWidth} height={calendarHeight} stroke="black" strokeWidth="0.4%" />
        {hourList.map((hour) => <HourBox key={hour} hour={hour} />)}
        {blobList.map((blob) => (
          <CalendarBlob key={`${blob.event.event_id}_${blob.blob_id}`} selectedBlob={selectedBlob} setSelectedBlob={setSelectedBlob} blob={blob} />
        ))}
      </Svg>
    </View>
  );
}

function CalendarBlob({ blob, selectedBlob, setSelectedBlob }) {
  const millisAtMidnight = stringToDateLocal(extractDateString(blob.time.start)).getTime();
  const millisAtStart = stringToDatetimeLocal(blob.time.start).getTime() - millisAtMidnight;
  const millisAtEnd = stringToDatetimeLocal(blob.time.end).getTime() - millisAtMidnight;
  const millisDay = 86400000; // Milliseconds in a day

  const x = calendarPadL;
  const y = calendarPadU + (calendarHeight * millisAtStart) / millisDay;
  const height = (calendarHeight * (millisAtEnd - millisAtStart)) / millisDay;
  const width = calendarWidth;

  const label = blob.event.name;

  // eslint-disable-next-line prefer-destructuring
  const color = blob.event.color;

  return (
    <G onClick={() => (setSelectedBlob(blob))}>
      <Rect
        x={x}
        y={y}
        width={width}
        height={height}
        fill={color}
        stroke="black"
        strokeWidth={(selectedBlob === blob) ? '1%' : '0.2%'}
        opacity="0.7"
      />
      <Text
        x={x + width / 2}
        y={y + height / 3}
        dominantBaseline="middle"
        textAnchor="middle"
      >
        <TSpan textAnchor="middle" x={x + width / 2}>
          {label}
        </TSpan>
        <TSpan textAnchor="middle" x={x + width / 2} dy="1.2em">
          {extractTimeString(blob.time.start)}
          -
          {extractTimeString(blob.time.end)}
        </TSpan>
      </Text>
    </G>
  );
}

function HourBox({ hour }) {
  const height = calendarHeight / 24;
  const width = calendarWidth;
  const x = calendarPadL;
  const y = calendarPadU + (hour * height);
  const color = (hour % 2) ? 'white' : '#cccccc';

  return (
    <G>
      <Rect x={x} y={y} width={width} height={height} fill={color} />
      <Text x={0} y={y + height / 4} dominantBaseline="middle">
        {hour.toString().padStart(2, '0')}
        :00
      </Text>
    </G>
  );
}

export default Calendar;
