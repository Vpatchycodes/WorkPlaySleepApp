/* eslint-disable no-unused-vars */
import { React, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';

import MessageDisplay from './MessageDisplay';
import UserControl from './UserControl';
import PopUp from './PopUp';
import RemoveFriendDisplay from './RemoveFriendDisplay';
import AddFriendDisplay from './AddFriendDisplay';
import ViewPendingDisplay from './ViewPendingDisplay';
import RequestDisplay from './RequestDisplay';

import { messageStyle } from '../assets/styles';

import { getFriendFirst } from '../modules/messageApi';

function MessagingView({ username, time, setNotifCount }) {
  const [loadSelected, setLoad] = useState(false);
  const [loadData, setLoadData] = useState(true);
  const [selectedUser, setSelectedUser] = useState(undefined);
  const [isInPopUp, setPopUp] = useState('none');
  const [areOptionsOpened, setOptionsOpened] = useState(false);

  useEffect(() => {
    getFriendFirst(username).then((first) => {
      setSelectedUser(first);
    });
  }, [loadSelected]);

  useEffect(() => {
    setNotifCount(0);
  }, [loadSelected, time]);

  const handleClose = () => {
    setPopUp('none');
  };

  const handleCloseRemoveFriend = () => {
    setOptionsOpened(false);
  };

  useEffect(() => {
    setNotifCount(0);
  }, [loadSelected, time]);

  return (
    <View style={messageStyle.messagingWrapper}>
      {areOptionsOpened && (
      <PopUp
        content={(
          <RemoveFriendDisplay
            username={username}
            toRemove={selectedUser}
            loadData={loadData}
            setLoadData={setLoadData}
            handleClose={handleCloseRemoveFriend}
          />
        )}
        handleClose={handleCloseRemoveFriend}
        closetext="X"
      />
      )}

      {(isInPopUp === 'add friend') && (
      <PopUp
        content={(
          <AddFriendDisplay
            username={username}
          />
        )}
        handleClose={handleClose}
        closetext="X"
      />
      )}

      {(isInPopUp === 'view pending') && (
      <PopUp
        content={(
          <ViewPendingDisplay
            username={username}
          />
)}
        handleClose={handleClose}
        closetext="X"
      />
      )}
      {(isInPopUp === 'confirm request') && (
      <PopUp
        content={(
          <RequestDisplay
            username={username}
            loadFriendList={loadData}
            setLoadFriendList={setLoadData}
            setSelectedFriend={setSelectedUser}
          />
)}
        handleClose={handleClose}
        closetext="X"
      />
      )}

      <UserControl
        username={username}
        selected={selectedUser}
        setSelected={setSelectedUser}
        time={time}
        setOptionsOpened={setOptionsOpened}
        setPopUp={setPopUp}
        loadData={loadData}
        setLoadData={setLoadData}
      />
      <MessageDisplay username={username} time={time} selected={selectedUser} />
    </View>
  );
}
MessagingView.propTypes = {
  username: PropTypes.string.isRequired,
  time: PropTypes.number.isRequired,
  setNotifCount: PropTypes.func.isRequired,
};

export default MessagingView;
