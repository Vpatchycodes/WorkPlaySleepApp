/* eslint-disable no-unused-vars */
import {
  React, useRef,
} from 'react';
import PropTypes from 'prop-types';
import {
  View, Text, Pressable, TextInput,
} from 'react-native';

import { sendMessageBoxStyle, popUpStyle } from '../assets/styles';

function SendMediaDisplay({
  sender, receiver, sendMessage, handleClose,
}) {
  const imageURLObj = useRef('');

  const setCurrentImageURL = (newURL) => {
    imageURLObj.current = { imageURL: newURL };
  };

  const handleSendMedia = () => {
    if (imageURLObj.current === undefined
       || imageURLObj.current.imageURL === undefined
       || imageURLObj.current.imageURL === '') {
      return;
    }
    sendMessage(sender, receiver, imageURLObj.current);
    handleClose();
  };

  return (
    <View>
      <Text style={popUpStyle.button_txt}>Send Image</Text>
      <TextInput
        style={popUpStyle.text_input}
        placeholder="Enter Image URL"
        onChangeText={setCurrentImageURL}
      />
      <Pressable
        style={popUpStyle.removebtn}
        onPress={handleSendMedia}
      >
        <Text style={popUpStyle.button_txt}>Media</Text>
      </Pressable>
    </View>
  );
}
SendMediaDisplay.propTypes = {
  sender: PropTypes.string.isRequired,
  receiver: PropTypes.string.isRequired,
  sendMessage: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
};

export default SendMediaDisplay;
