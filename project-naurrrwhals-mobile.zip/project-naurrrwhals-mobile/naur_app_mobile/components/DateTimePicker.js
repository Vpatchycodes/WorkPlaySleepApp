import { createElement } from 'react';

export function MyDatePicker({ value, onChange }) {
  return createElement('input', {
    type: 'date',
    value: value,
    onInput: (e) => onChange(e.target.value),
  });
}

export function MyTimePicker({ value, onChange }) {
  return createElement('input', {
    type: 'time',
    value: value,
    onInput: (e) => onChange(e.target.value),
  });
}
