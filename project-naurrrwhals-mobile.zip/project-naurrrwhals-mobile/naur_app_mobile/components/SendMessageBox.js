import { React, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import {
  View, Text, Pressable, TextInput,
} from 'react-native';

import { getMessageLog, putMessageLog } from '../modules/messageApi';
import PopUp from './PopUp';
import SendMediaDisplay from './SendMediaDisplay';

import { sendMessageBoxStyle, popUpStyle } from '../assets/styles';

function SendMessageBox({ username, friendName, setMessageLog }) {
  const [isInSendMediaPopUp, setMediaPopUp] = useState(false);
  const message = useRef(undefined);

  const sendMessage = (sender, receiver, msg) => {
    if (msg === undefined) {
      return;
    }
    putMessageLog(sender, receiver, msg).then(() => {
      getMessageLog(sender, receiver).then((log) => {
        setMessageLog(log);
      });
    });
  };

  const handleWriteMsg = (newMsg) => {
    message.current = { msgText: newMsg };
  };

  const handleSendMsg = () => {
    if (message.current === undefined
     || message.current.msgText === undefined
     || message.current.msgText === '') {
      return;
    }
    sendMessage(username, friendName, message.current);
  };

  const handlePressMedia = () => {
    setMediaPopUp(true);
  };

  const handleCloseMedia = () => {
    setMediaPopUp(false);
  };

  return (
    <View>
      <TextInput
        style={popUpStyle.text_input}
        placeholder="Message"
        onChangeText={handleWriteMsg}
      />
      <View style={sendMessageBoxStyle.sendbtn_wrapper}>
        <Pressable
          style={sendMessageBoxStyle.sendbtn}
          onPress={handleSendMsg}
        >
          <Text style={popUpStyle.button_txt}>Send</Text>
        </Pressable>
        <Pressable
          style={sendMessageBoxStyle.sendbtn}
          onPress={handlePressMedia}
        >
          <Text style={popUpStyle.button_txt}>Media</Text>
        </Pressable>
      </View>
      {isInSendMediaPopUp && (
      <View style={sendMessageBoxStyle.popup_wrapper}>
        <PopUp
          content={(
            <SendMediaDisplay
              sender={username}
              receiver={friendName}
              sendMessage={sendMessage}
              handleClose={handleCloseMedia}
            />
        )}
          handleClose={handleCloseMedia}
          closetext="X"
        />
      </View>
      )}
    </View>
  );
}
SendMessageBox.propTypes = {
  username: PropTypes.string.isRequired,
  friendName: PropTypes.string.isRequired,
  setMessageLog: PropTypes.func.isRequired,
};

export default SendMessageBox;
