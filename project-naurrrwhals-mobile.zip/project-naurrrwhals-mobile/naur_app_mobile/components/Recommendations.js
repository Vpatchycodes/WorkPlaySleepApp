/* eslint-disable react/prop-types */
/* eslint-disable camelcase */

import React, { useState } from 'react';
import {
  View, Button, StyleSheet, Text,
} from 'react-native';
import NumberPlease from 'react-native-number-please';
import {
  GET_desiredHoursSleep, GET_desiredTimeSleep,
  GET_desiredHoursWork, GET_desiredWorkBlock,
  GET_desiredWorkEndTime, GET_desiredHoursRelax,
  GET_desiredRelaxActivity,
} from '../modules/wellnessApi';

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#3EACB2',
    width: '100%',
    fontFamily: 'cursive',
    fontSize: 30,
    fontWeight: 'bold',
    height: '20 px',
    color: 'white',
  },
  container: {
    backgroundColor: 'black',
    color: 'white',
  },
  text: {
    color: 'white',
  },
  h1: {

  },
  h2: {

  },
  dropdown: {
    marginBottom: '70px',
  },
});

function Recommendations({ username }) {
  // allow form inputs
  const [currHrSleep, setCurrHoursSleep] = useState([{ id: 'hours', value: 8 }]);
  const [currTSleep, setCurrTimeSleep] = useState([{ id: 'hours', value: 1800 }]);
  const [currHrWork, setCurrHoursWork] = useState([{ id: 'hours', value: 8 }]);
  const [currWkBlock, setCurrWorkBlock] = useState([{ id: 'min', value: 45 }]);
  const [currWkEndTime, setCurrWorkEndTime] = useState([{ id: 'hours', value: 1800 }]);
  const [currHrRelax, setCurrHourRelax] = useState([{ id: 'hours', value: 8 }]);

  // allow rec outputs
  const [sleepSugg, setSleepSugg] = useState([]);
  const [workSugg, setWorkSugg] = useState([]);
  const [relaxSugg, setRelaxSugg] = useState('');

  const hourNumbers = [{
    id: 'hours', label: 'hrs', min: 0, max: 24,
  }];
  const TFNumbers = [{
    id: 'hoursmins', label: 'hrsmin', min: 0, max: 2359,
  }];
  const minNumbers = [{
    id: 'minutes', label: 'min', min: 0, max: 60,
  }];

  // recommendation functions - computes & interprets
  function computeSleepSuggestions(currHoursSleep, currTimeSleep) {
    const desiredHoursSleep = GET_desiredHoursSleep(username);
    const desiredTimeSleep = GET_desiredTimeSleep(username);

    let hoursRec = 0;
    let timeRec = 0;
    if (desiredHoursSleep < currHoursSleep) {
      hoursRec = desiredHoursSleep - currHoursSleep;
    } else if (currHoursSleep < 6) {
      hoursRec = 6 - currHoursSleep;
    }

    if (desiredTimeSleep < currTimeSleep) {
      timeRec = desiredTimeSleep - currTimeSleep;
    }

    return [hoursRec, timeRec];
  }

  function interpretSleepSuggestions([hoursRec, timeRec]) {
    let sleepHr = '';
    let sleepTime = '';
    if (hoursRec < 0) {
      sleepHr = 'Need to sleep more hours';
    } else {
      sleepHr = 'Good job! You are sleeping enough hours';
    }

    if (timeRec < 0) {
      sleepTime = 'Need to sleep earlier';
    } else {
      sleepTime = 'Good job! You are sleeping on time';
    }

    return [sleepHr, sleepTime];
  }

  function computeWorkSuggestions(currHoursWork, currWorkBlock, currWorkEndTime) {
    const desiredHoursWork = GET_desiredHoursWork(username);
    const desiredWorkBlock = GET_desiredWorkBlock(username);
    const desiredWorkEndTime = GET_desiredWorkEndTime(username);

    let hoursRec = 0;
    let blockRec = 0;
    let timeRec = 0;
    if (desiredHoursWork !== currHoursWork) {
      hoursRec = desiredHoursWork - currHoursWork;
    }

    if (desiredWorkBlock !== currWorkBlock) {
      blockRec = desiredWorkBlock - currWorkBlock;
    }

    if (desiredWorkEndTime < currWorkEndTime) {
      timeRec = desiredWorkEndTime - currWorkEndTime;
    }

    return [hoursRec, blockRec, timeRec];
  }

  function interpretWorkSuggestions([hoursRec, blockRec, timeRec]) {
    let workHr = '';
    let workBlock = '';
    let workTime = '';
    if (hoursRec < 0) {
      workHr = 'Need to work fewer hours';
    } else {
      workHr = 'Good job! You are working enough hours';
    }

    if (blockRec < 0) {
      workBlock = 'Need to work for less time at a stretch';
    } else {
      workBlock = 'Good job! You are working for a healthy amount of time at a stretch';
    }

    if (timeRec < 0) {
      workTime = 'Need to end work earlier';
    } else {
      workTime = 'Good job! You are ending work at a good time';
    }

    return [workHr, workBlock, workTime];
  }

  function computeRelaxSuggestions(currHoursRelax) {
    const desiredHoursRelax = GET_desiredHoursRelax(username);
    const desiredRelaxActivity = GET_desiredRelaxActivity(username);

    let hoursRec = 0;
    if (desiredHoursRelax > currHoursRelax) {
      hoursRec = desiredHoursRelax - currHoursRelax;
    }

    return [hoursRec, desiredRelaxActivity];
  }

  function interpretRelaxSuggestions([hoursRec, desiredRelaxActivity]) {
    let relaxHr = '';
    if (hoursRec < 0) {
      relaxHr = 'Need to relax more hours\n Try: ';
      relaxHr += desiredRelaxActivity;
    } else {
      relaxHr = 'Good job! You are relaxing enough hours';
    }

    return relaxHr;
  }

  // trigger computations
  function handleRec() {
    setSleepSugg(interpretSleepSuggestions(computeSleepSuggestions(
      currHrSleep.value,
      currTSleep.value,
    )));
    setWorkSugg(interpretWorkSuggestions(
      computeWorkSuggestions(currHrWork.value, currWkBlock.value, currWkEndTime.value),
    ));
    setRelaxSugg(interpretRelaxSuggestions(computeRelaxSuggestions(currHrRelax.value)));
    console.log('recommendations computed');
  }

  // TODO - output times out -> audit error (chrome, firefox, and explorer)
  // testing on default inputs at the moment since format of current (actual) data not decided
  return (
    <View>
      <Text style={styles.h2}>Recommendations</Text>
      <View>
        <Text style={styles.h4}>Actual Sleep (Hours)</Text>
        <NumberPlease
          digits={hourNumbers}
          values={currHrSleep}
          onChange={(values) => setCurrHoursSleep(values)}
        />
        <Text style={styles.h4}>Actual Bedtime [24h format]</Text>
        <NumberPlease
          digits={TFNumbers}
          values={currTSleep}
          onChange={(values) => setCurrTimeSleep(values)}
        />
        <Text style={styles.h4}>Actual Work (Hours)</Text>
        <NumberPlease
          digits={hourNumbers}
          values={currHrWork}
          onChange={(values) => setCurrHoursWork(values)}
        />
        <Text style={styles.h4}>Actual Work Block (Minutes)</Text>
        <NumberPlease
          digits={minNumbers}
          values={currWkBlock}
          onChange={(values) => setCurrWorkBlock(values)}
        />
        <Text style={styles.h4}>Actual Endtime [24h format]</Text>
        <NumberPlease
          digits={TFNumbers}
          values={currWkEndTime}
          onChange={(values) => setCurrWorkEndTime(values)}
        />
        <Text style={styles.h4}>Actual Relaxation (Hours)</Text>
        <NumberPlease
          digits={hourNumbers}
          values={currHrRelax}
          onChange={(values) => setCurrHourRelax(values)}
        />
        <Button type="submit" onPress={() => handleRec()} title="Compute Recommendations" />
      </View>
      <Text style={styles.h4}>
        {sleepSugg[0]}
      </Text>
      <Text style={styles.h4}>
        {sleepSugg[1]}
      </Text>
      <Text style={styles.h4}>
        {workSugg[0]}
      </Text>
      <Text style={styles.h4}>
        {workSugg[1]}
      </Text>
      <Text style={styles.h4}>
        {workSugg[2]}
      </Text>
      <Text style={styles.h4}>
        {relaxSugg}
      </Text>
    </View>
  );
}

export default Recommendations;
