/* eslint-disable no-unused-vars */
import { React, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
  View, Text, Pressable,
} from 'react-native';

import AntIcon from 'react-native-vector-icons/AntDesign';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';

import { getMessageCount } from '../modules/messageApi';

import TaskHolder from './TaskHolder';
import MessagingView from './MessagingView';
import Survey from './Survey';
import Calendar from './Calendar';
import Recommendations from './Recommendations';

import { getCurrentTimeString, getCurrentDateString } from '../modules/timeFuncs';

import { homepageStyle } from '../assets/styles';

function Homepage({ username, setUsername, time }) {
  const [page, setPage] = useState('wellness');
  const [notifCount, setNotifCount] = useState(0);
  const [messageCount, setMessageCount] = useState(-1);

  const handleLogout = () => {
    setUsername('');
  };

  const handleCalendar = () => {
    setPage('calendar');
  };

  const handleTasks = () => {
    setPage('task');
  };

  const handleMessaging = () => {
    setPage('message');
  };

  const handleRec = () => {
    setPage('rec');
  };

  useEffect(() => {
    getMessageCount(username).then((newCount) => {
      if (messageCount >= 0 && newCount !== messageCount) {
        setNotifCount(notifCount + 1);
      }
      setMessageCount(newCount);
    });
  }, [time]);

  return (
    <View style={homepageStyle.homepageWrapper}>
      <View>
        {page === 'wellness' && (
          <View>
            <Survey username={username} />
          </View>
        )}
        {page === 'calendar' && (
          <View>
            <Calendar username={username} />
          </View>
        )}
        {page === 'task' && (
          <View>
            <TaskHolder username={username} />
          </View>
        )}
        {page === 'message' && (
          <View>
            <MessagingView username={username} time={time} setNotifCount={setNotifCount} />
          </View>
        )}
        {page === 'rec' && (
          <View>
            <Recommendations username={username} />
          </View>
        )}
      </View>
      <View style={homepageStyle.navBar}>
        <Pressable style={homepageStyle.textBox}><Text>{username}</Text></Pressable>
        <Pressable style={homepageStyle.navButton} title="messaging" onPress={handleMessaging}>
          <AntIcon name="message1" size={30} />
        </Pressable>
        <Pressable style={homepageStyle.navButton} title="Calendar" onPress={handleCalendar}>
          <AntIcon name="contacts" size={30} />
        </Pressable>
        <Pressable style={homepageStyle.navButton} title="Tasks" onPress={handleTasks}>
          <EntypoIcon name="list" size={30} />
        </Pressable>
        <Pressable style={homepageStyle.navButton} title="logout" onPress={handleLogout}>
          <MaterialIcon name="logout" size={30} />
        </Pressable>
        <Pressable style={homepageStyle.navButton} title="Analytics" onPress={handleRec}>
          <EntypoIcon name="bar-graph" size={30} />
        </Pressable>
        <View>
          <Pressable style={homepageStyle.textBox}>
            <Text>
              {' '}
              {getCurrentDateString()}
            </Text>
          </Pressable>
          <Pressable style={homepageStyle.textBox}>
            <Text>
              {' '}
              {getCurrentTimeString()}
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

Homepage.propTypes = {
  username: PropTypes.string.isRequired,
  time: PropTypes.number.isRequired,
};

export default Homepage;
