/* eslint-disable no-unused-vars */
import { React, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';

import { messageStyle } from '../assets/styles';
import MessageList from './MessageList';
import SendMessageBox from './SendMessageBox';

import { getFriendExists, getMessageLog } from '../modules/messageApi';

function MessageDisplay({ username, time, selected }) {
  const [messageLog, setMessageLog] = useState(undefined);

  useEffect(() => {
    if (!selected) {
      return;
    }
    getFriendExists(username, selected).then((hasFriend) => {
      if (!hasFriend) {
        return;
      }
      getMessageLog(username, selected).then((log) => {
        setMessageLog(log);
      });
    });
  }, [selected, time]);

  return (
    <View style={messageStyle.messageDisp}>
      <Text>Messages</Text>
      {(selected === undefined) && (
      <Text>You currently have no friends</Text>
      )}
      {!(selected === undefined) && !(messageLog === undefined)
      && (
        <View>
          <MessageList
            username={username}
            list={messageLog}
          />
          <View />
          <SendMessageBox
            username={username}
            friendName={selected}
            setMessageLog={setMessageLog}
          />
        </View>
      )}
    </View>
  );
}
MessageDisplay.propTypes = {
  username: PropTypes.string.isRequired,
  time: PropTypes.number.isRequired,
  selected: PropTypes.string,
};

MessageDisplay.defaultProps = {
  selected: undefined,
};

export default MessageDisplay;
