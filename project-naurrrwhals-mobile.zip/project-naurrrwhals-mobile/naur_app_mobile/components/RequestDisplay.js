/* eslint-disable no-unused-vars */
import {
  React, useEffect, useState,
} from 'react';
import PropTypes from 'prop-types';
import {
  View, Text,
} from 'react-native';

import FriendList from './FriendList';
import {
  getRequestedList, getRequestedFirst, acceptFriendRequest, rejectFriendRequest,
} from '../modules/messageApi';

import { popUpStyle, pendingStyle } from '../assets/styles';

function RequestDisplay({
  username, loadFriendList, setLoadFriendList, setSelectedFriend,
}) {
  const [loadRequestedList, setLoadRequestedList] = useState(true);
  const [list, setList] = useState(undefined);
  const [selected, setSelected] = useState(undefined);

  const handleAcceptRequest = () => {
    acceptFriendRequest(username, selected).then(() => {
      setLoadFriendList(!loadFriendList);
      setLoadRequestedList(!loadRequestedList);
      setSelectedFriend(selected);
    });
  };

  const handleRejectRequest = () => {
    rejectFriendRequest(username, selected);
    setLoadRequestedList(!loadRequestedList);
  };

  useEffect(() => {
    getRequestedList(username).then((requestedlist) => {
      setList(requestedlist);
      getRequestedFirst(username).then((first) => {
        setSelected(first);
      });
    });
  }, [loadRequestedList]);

  return (
    <View style={popUpStyle.popup_content_wrapper}>
      <Text style={popUpStyle.button_txt}>Recieved Friend Requests</Text>
      <View style={pendingStyle.list_box}>
        {(list !== undefined) && (selected !== undefined) && (
        <FriendList
          list={list}
          selected={selected}
          setSelected={setSelected}
          setActionOne={handleAcceptRequest}
          actionTextOne="Confirm"
          setActionTwo={handleRejectRequest}
          actionTextTwo="Reject"
        />
        )}
      </View>
    </View>
  );
}
RequestDisplay.propTypes = {
  username: PropTypes.string.isRequired,
  loadFriendList: PropTypes.bool.isRequired,
  setLoadFriendList: PropTypes.func.isRequired,
  setSelectedFriend: PropTypes.func.isRequired,
};

export default RequestDisplay;
