/* eslint-disable react/prop-types */
/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable camelcase */

import React, { useState } from 'react';
import {
  View, Button, StyleSheet, Text, ScrollView,
} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import { RadioButton } from 'react-native-paper';
import Priority from './Priority';
import {
  PUT_sleepSat, PUT_workSat, PUT_relaxSat,
  PUT_mood, PUT_priority,
} from '../modules/wellnessApi';

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#3EACB2',
    width: '100%',
    fontFamily: 'cursive',
    fontSize: 30,
    fontWeight: 'bold',
    height: 20,
    color: 'white',
  },
  container: {
    margin: 50,
  },
  text: {
    color: 'white',
  },
  h1: {

  },
  h2: {

  },
  dropdown: {
    marginBottom: 70,
  },
  radio: {
    backgroundColor: '#a9a9a9',
  },
});

function Survey({ username }) {
  const [selected, setSelected] = useState('');
  const [sleepSat, setSleepSat] = useState(5);
  const [workSat, setWorkSat] = useState(5);
  const [relaxSat, setRelaxSat] = useState(5);
  const [mood, setMood] = useState(5);
  const [isSubmit, setIsSubmit] = useState(false);
  const [priority, setPriority] = useState('Relaxation');

  const dropDownOptions = [
    { label: 'Very Satisfied', value: '5' },
    { label: 'Satisfied', value: '4' },
    { label: 'Nuetral', value: '3' },
    { label: 'Not Satisfied', value: '2' },
    { label: 'Extremely Unsatisfied', value: '1' },
  ];

  const [open1, setOpen1] = useState(false);
  const [value1, setValue1] = useState(null);
  const [items1, setItems1] = useState(dropDownOptions);

  const [open2, setOpen2] = useState(false);
  const [value2, setValue2] = useState(null);
  const [items2, setItems2] = useState(dropDownOptions);

  const [open3, setOpen3] = useState(false);
  const [value3, setValue3] = useState(null);
  const [items3, setItems3] = useState(dropDownOptions);

  const [open4, setOpen4] = useState(false);
  const [value4, setValue4] = useState(null);
  const [items4, setItems4] = useState([
    { label: 'Amazing', value: '5' },
    { label: 'Great', value: '4' },
    { label: 'Good', value: '3' },
    { label: 'Ok', value: '2' },
    { label: 'Not Good', value: '1' },
    { label: 'Terrible', value: '0' },
  ]);

  // defaults in case user doesn't change the survey answers
  PUT_sleepSat(username, sleepSat);
  PUT_workSat(username, workSat);
  PUT_relaxSat(username, relaxSat);
  PUT_mood(username, mood);
  PUT_priority(username, priority);

  function handleSubmit() {
    if (selected && selected !== '') {
      setPriority(selected);
      PUT_priority(username, priority);
      setIsSubmit(true);
      return;
    }
    if (priority && priority !== '') {
      PUT_priority(username, priority);
      setIsSubmit(true);
      return;
    }
    // eslint-disable-next-line no-alert
    alert('Must choose a priority for today');
  }

  function handleSleepSat(e) {
    setSleepSat(e.target.value);
    PUT_sleepSat(username, sleepSat);
  }

  function handleWorkSat(e) {
    setWorkSat(e.target.value);
    PUT_workSat(username, workSat);
  }

  function handleRelaxSat(e) {
    setRelaxSat(e.target.value);
    PUT_relaxSat(username, relaxSat);
  }

  function handleMood(e) {
    setMood(e.target.value);
    PUT_mood(username, mood);
  }

  function on1Open() {
    setOpen2(false);
    setOpen3(false);
    setOpen4(false);
  }

  function on2Open() {
    setOpen2(false);
    setOpen3(false);
    setOpen4(false);
  }

  function on3Open() {
    setOpen2(false);
    setOpen3(false);
    setOpen4(false);
  }

  function on4Open() {
    setOpen2(false);
    setOpen3(false);
    setOpen4(false);
  }
  if (isSubmit) {
    return (
      <View>
        <Priority data={[priority]} username={username} />
      </View>
    );
  }

  return (
    <View styles={styles.container} className="survey">
      <Text style={styles.h2}> Rate your day yesterday </Text>
      <Text style={styles.h4}> How was your sleep? </Text>
      <View style={styles.dropdown}>
        <DropDownPicker
          open={open1}
          value={value1}
          items={items1}
          setOpen={setOpen1}
          setValue={setValue1}
          setItems={setItems1}
          placeholder="select"
          onSelectItem={() => handleSleepSat}
          onOpen={() => on1Open}
          dropDownDirection="AUTO"
          bottomOffset={100}
          zIndex={1000}
          zIndexInverse={4000}
          dropDownContainerStyle={{
            backgroundColor: '#dfdfdf',
          }}
          required
        />
      </View>
      <Text style={styles.h4}> How was your work? </Text>
      <View style={styles.dropdown}>
        <DropDownPicker
          open={open2}
          value={value2}
          items={items2}
          setOpen={setOpen2}
          setValue={setValue2}
          setItems={setItems2}
          placeholder="select"
          onSelectItem={() => handleWorkSat}
          onOpen={() => on2Open}
          zIndex={2000}
          zIndexInverse={3000}
          required
        />
      </View>
      <Text style={styles.h4}> How was your relaxation? </Text>
      <View style={styles.dropdown}>
        <DropDownPicker
          open={open3}
          value={value3}
          items={items3}
          setOpen={setOpen3}
          setValue={setValue3}
          setItems={setItems3}
          placeholder="select"
          onSelectItem={() => handleRelaxSat}
          onOpen={() => on3Open}
          zIndex={3000}
          zIndexInverse={2000}
          required
        />
      </View>
      <Text style={styles.h2}> Start your day today </Text>
      <Text style={styles.h4}> How do you feel today? </Text>
      <View style={styles.dropdown}>
        <DropDownPicker
          open={open4}
          value={value4}
          items={items4}
          setOpen={setOpen4}
          setValue={setValue4}
          setItems={setItems4}
          placeholder="select"
          onSelectItem={() => handleMood}
          onOpen={() => on4Open}
          zIndex={4000}
          zIndexInverse={1000}
          required
        />
      </View>
      <Text style={styles.h1}> What is most important to you today </Text>
      {/* <form onSubmit={handleSubmit}> */}
      <View>
        <Text className="goals">
          <RadioButton
            style={styles.radio}
            status={selected === 'Sleep' ? 'checked' : 'unchecked'}
            onPress={() => setSelected('Sleep')}
            value="Sleep"
            color="white"
          />
          {' '}
          Sleep
        </Text>
        <Text className="goals">
          <RadioButton
            style={styles.radio}
            status={selected === 'Work' ? 'checked' : 'unchecked'}
            onPress={() => setSelected('Work')}
            value="Work"
            color="white"
          />
          {' '}
          Work
        </Text>
        <Text className="goals">
          <RadioButton
            style={styles.radio}
            status={selected === 'Relax' ? 'checked' : 'unchecked'}
            onPress={() => setSelected('Relax')}
            value="Relax"
            color="white"
          />
          {' '}
          Relaxation
        </Text>
        <Button className="goalButton" type="submit" onPress={() => handleSubmit()} title="Set Specific Goal" />
        {/* </form> */}
      </View>
    </View>
  );
}

export default Survey;
