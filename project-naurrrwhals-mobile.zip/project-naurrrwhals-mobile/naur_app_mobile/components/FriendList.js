/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

import { FlatList, Text } from 'react-native';

import SingleUser from './SingleUser';

function FriendList({
  list, selected, setSelected, setActionOne, actionTextOne, setActionTwo, actionTextTwo,
}) {
  return (
    <FlatList
      data={list}
      renderItem={({ item }) => (
        <SingleUser
          username={item}
          selected={selected}
          setSelected={setSelected}
          setActionOne={setActionOne}
          actionTextOne={actionTextOne}
          setActionTwo={setActionTwo}
          actionTextTwo={actionTextTwo}
        />
      )}
    />
  );
}
FriendList.propTypes = {
  // eslint-disable-next-line react/forbid-prop-types
  list: PropTypes.array,
  selected: PropTypes.string,
  setSelected: PropTypes.func.isRequired,
  setActionOne: PropTypes.func.isRequired,
  actionTextOne: PropTypes.string.isRequired,
  setActionTwo: PropTypes.func,
  actionTextTwo: PropTypes.string,
};
FriendList.defaultProps = {
  list: undefined,
  selected: undefined,
  setActionTwo: undefined,
  actionTextTwo: undefined,
};

export default FriendList;
