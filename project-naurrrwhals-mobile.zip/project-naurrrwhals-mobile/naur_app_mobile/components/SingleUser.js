/* eslint-disable max-len */
/* eslint-disable no-unused-vars */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import {
  React, useEffect, useState,
} from 'react';
import PropTypes from 'prop-types';
import {
  View, Text, Pressable,
} from 'react-native';

import SimpleIcon from 'react-native-vector-icons/SimpleLineIcons';

import { singleUserStyle, popUpStyle } from '../assets/styles';

function SingleUser({
  username, selected, setSelected, setActionOne, actionTextOne, setActionTwo, actionTextTwo,
}) {
  const [style, setStyle] = useState(singleUserStyle.unclicked);

  const handleSetSelected = () => {
    setSelected(username);
  };
  const handleActionOne = () => {
    setSelected(username);
    setActionOne(true);
  };
  const handleActionTwo = () => {
    setSelected(username);
    setActionTwo(true);
  };

  useEffect(() => {
    if (username === selected) {
      setStyle(singleUserStyle.clicked);
    } else {
      setStyle(singleUserStyle.unclicked);
    }
  }, [selected]);

  return (
    <View style={singleUserStyle.single_user}>

      <View style={singleUserStyle.actions_wrapper}>
        <View style={singleUserStyle.options_disp}>
          <Pressable style={style} title="usernamebar" onPress={handleSetSelected}><Text style={style}>{username}</Text></Pressable>
          {(actionTextOne === 'Options') && (
          <Pressable
            style={singleUserStyle.userButton}
            title={actionTextOne}
            onPress={handleActionOne}
          >
            <SimpleIcon name="options" size={30} />
          </Pressable>
          )}
        </View>

        {(actionTextOne === 'Remove') && (
        <Pressable
          style={singleUserStyle.actionButton}
          title={actionTextOne}
          onPress={handleActionOne}
        >
          <Text style={singleUserStyle.actionText}>{actionTextOne}</Text>
        </Pressable>
        )}

        {(actionTextOne === 'Confirm') && (
        <Pressable
          style={singleUserStyle.actionButton}
          title={actionTextOne}
          onPress={handleActionOne}
        >
          <Text style={singleUserStyle.actionText}>{actionTextOne}</Text>
        </Pressable>
        )}

        {setActionTwo && (
        <Pressable
          style={singleUserStyle.actionButton}
          onPress={handleActionTwo}
        >
          <Text style={singleUserStyle.actionText}>{actionTextTwo}</Text>
        </Pressable>
        )}
      </View>

    </View>
  );
}
SingleUser.propTypes = {
  // eslint-disable-next-line react/forbid-prop-types
  username: PropTypes.string.isRequired,
  selected: PropTypes.string,
  setSelected: PropTypes.func.isRequired,
  setActionOne: PropTypes.func.isRequired,
  actionTextOne: PropTypes.string.isRequired,
  setActionTwo: PropTypes.func,
  actionTextTwo: PropTypes.string,
};
SingleUser.defaultProps = {
  selected: undefined,
  setActionTwo: undefined,
  actionTextTwo: undefined,
};

export default SingleUser;
