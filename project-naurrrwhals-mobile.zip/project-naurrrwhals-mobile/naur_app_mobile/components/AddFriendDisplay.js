/* eslint-disable no-unused-vars */
import {
  React, useState, useRef,
} from 'react';
import PropTypes from 'prop-types';
import {
  View, Pressable, Text, TextInput,
} from 'react-native';
import {
  getUserExists, getFriendExists, getPendingExists, sendFriendRequest,
} from '../modules/messageApi';

import { popUpStyle } from '../assets/styles';

function AddFriendDisplay({ username }) {
  const [pressedAdd, setPressedAdd] = useState(false);
  const [isUser, setIsUser] = useState(false);
  const [sentRequest, setSentRequest] = useState(false);
  const [alreadyExists, setAlreadyExists] = useState(false);
  const [isSelf, setIsSelf] = useState(false);

  const friendName = useRef(undefined);

  const handleInputName = (newName) => {
    friendName.current = newName;
    setPressedAdd(false);
    setIsUser(false);
    setSentRequest(false);
    setIsSelf(false);
    setAlreadyExists(false);
  };

  const handleSendRequest = () => {
    setPressedAdd(true);
    if (friendName.current === username) {
      setIsSelf(true);
      return;
    }
    getFriendExists(username, friendName.current).then((friendValue) => {
      if (friendValue) {
        setAlreadyExists(true);
        return;
      }
      getPendingExists(username, friendName.current).then((pendingValue) => {
        if (pendingValue) {
          setAlreadyExists(true);
          return;
        }
        getUserExists(friendName.current).then((userValue) => {
          if (!userValue) {
            return;
          }
          setIsUser(true);
          sendFriendRequest(username, friendName.current).then(() => {
            setSentRequest(true);
          });
        });
      });
    });
    const testString = 'inexistant user';
    if (testString === 'already friends') {
      setAlreadyExists(true);
      return;
    }
    if (testString === 'already requested') {
      setAlreadyExists(true);
      return;
    }
    if (testString === 'inexistant user') {
      return;
    }
    setIsUser(true);
    setSentRequest(true);
  };

  return (
    <View style={popUpStyle.popup_content_wrapper}>
      <Text style={popUpStyle.button_txt}>Add Friend</Text>
      <View>
        <TextInput
          style={popUpStyle.text_input}
          placeholder="Enter name"
          onChangeText={handleInputName}
        />
      </View>
      <Pressable
        style={popUpStyle.removebtn}
        onPress={handleSendRequest}
      >
        <Text style={popUpStyle.button_txt}>Send</Text>

      </Pressable>
      <View>
        {pressedAdd && !isUser && !isSelf && !alreadyExists && (
        <Text style={popUpStyle.button_txt}>Inexistent user</Text>
        )}
        {sentRequest && (
        <Text style={popUpStyle.button_txt}>Sent Friend Request</Text>
        )}
        {isSelf && (
        <Text style={popUpStyle.button_txt}>Cannot send request to self</Text>
        )}
        {alreadyExists && (
        <Text style={popUpStyle.button_txt}>Already sent request</Text>
        )}
      </View>
    </View>
  );
}
AddFriendDisplay.propTypes = {
  username: PropTypes.string.isRequired,
};

export default AddFriendDisplay;
