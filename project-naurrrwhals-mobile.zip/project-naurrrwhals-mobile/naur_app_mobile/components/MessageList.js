/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';
import { FlatList, Text, View } from 'react-native';

import Message from './Message';

import { messageListStyle } from '../assets/styles';

function displayMessageList(username, list) {
  const listArray = [];
  let date;

  for (let i = 0; i < list.length; i += 1) {
    const item = list[i];
    if (date !== item[3]) {
      listArray.push(
        <Text style={messageListStyle.messagelist_date}>{item[3]}</Text>,
      );
    }
    // eslint-disable-next-line prefer-destructuring
    date = item[3];
    listArray.push(
      <View>
        <Message user={username} sender={item[0]} message={item[1]} time={item[2]} />
      </View>,
    );
  }
  return listArray;
}

function MessageList({ username, list }) {
  return (
    <View style={messageListStyle.msg_list}>
      <FlatList
        data={displayMessageList(username, list)}
        renderItem={({ item }) => (
          <View>
            {item}
          </View>
        )}
      />
    </View>
  );
}
MessageList.propTypes = {
  username: PropTypes.string.isRequired,
  // eslint-disable-next-line react/forbid-prop-types
  list: PropTypes.array,
};
MessageList.defaultProps = {
  list: undefined,
};

export default MessageList;
