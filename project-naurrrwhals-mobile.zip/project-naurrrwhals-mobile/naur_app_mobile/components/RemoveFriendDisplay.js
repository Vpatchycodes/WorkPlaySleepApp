/* eslint-disable no-unused-vars */
import {
  React,
} from 'react';
import PropTypes from 'prop-types';

import { View, Text, Pressable } from 'react-native';

import { popUpStyle } from '../assets/styles';

import { removeFriendfromFriendList } from '../modules/messageApi';

function RemoveFriendDisplay({
  username, toRemove, loadData, setLoadData, handleClose,
}) {
  const handleRemove = () => {
    removeFriendfromFriendList(username, toRemove).then(() => {
      setLoadData(!loadData);
      handleClose();
    });
  };

  return (
    <View style={popUpStyle.removebtn}>
      <Pressable onPress={handleRemove}>
        <Text style={popUpStyle.button_txt}>Remove Friend</Text>

      </Pressable>
    </View>
  );
}
RemoveFriendDisplay.propTypes = {
  username: PropTypes.string.isRequired,
  toRemove: PropTypes.string,
  loadData: PropTypes.bool.isRequired,
  setLoadData: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
};
RemoveFriendDisplay.defaultProps = {
  toRemove: undefined,
};

export default RemoveFriendDisplay;
