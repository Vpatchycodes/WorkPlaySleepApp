/* eslint-disable react/prop-types */
/* eslint-disable react/forbid-prop-types */
/* eslint-disable react/react-in-jsx-scope */

import React, { useState, useRef } from 'react';
import {
  StyleSheet, View, Text, Button, TextInput, ScrollView,
} from 'react-native';
// eslint-disable-next-line no-unused-vars
import { postLogin } from '../modules/loginApi';

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#3EACB2',
    width: '100%',
    fontFamily: 'cursive',
    fontSize: 30,
    fontWeight: 'bold',
    height: '20 px',
    color: 'white',
  },
  container: {
    margin: 100,
  },
  text: {
    color: 'white',
  },
  h1: {
    margin: 30,
    marginTop: 50,
    color: '#0F4156',
  },
  h2: {
    margin: 30,
  },
  dropdown: {
    marginBottom: '70 px',
  },
  lmessage: {
    maxWidth: 300,
    fontSize: 32,
    fontFamily: 'Gill Sans',
    marginLeft: 50,
  },
  linputs: {
    backgroundColor: '#BEC4FB',
    borderStyle: 'dashed',
    borderRadius: 3,
    textAlign: 'center',
    fontSize: 24,
  },
});

// Returns error if the given string is not a valid username
function usernameError(str) {
  if (!str.match(/^[A-Za-z0-9_]*$/)) {
    return 'Username must be made up of letters, numbers, or underscores';
  }
  if (!str.match(/^[A-Za-z_][A-Za-z0-9_]*$/)) {
    return 'Username must start with a letter or underscore';
  }
  if (!str.match(/[A-Za-z0-9]/)) {
    return 'Username must contain contain at least one letter or number';
  }
  if (!(str.length >= 3)) {
    return 'Username must be at least 3 characters long';
  }
  return '';
}

// Returns error if the given string is not a valid password
function passwordError(str) {
  if (!str.match(/^[A-Za-z0-9\\!"#$%&'()*+,\-./:;<=>?@[\]^_`{|}~]+$/)) {
    return 'Password contains illegal character';
  }
  if (!(str.length >= 6)) {
    return 'Password must be at least 6 characters long';
  }
  return '';
}

// Input: a state setter used to set the username of the current user and reload
function Login({ setUsername }) {
  const [errorMessage, setErrorMessage] = useState('');
  const userNameText = useRef('');
  const passText = useRef('');

  function handleUsernameInput(name) {
    userNameText.current = name;
    if (name === '') {
      setErrorMessage('');
    } else {
      setErrorMessage(usernameError(name));
    }
  }

  function handlePasswordInput(pword) {
    passText.current = pword;
    if (pword === '') {
      setErrorMessage('');
    } else {
      setErrorMessage(passwordError(pword));
    }
  }

  function handleLogin() {
    // console.log(userNameText.current);
    // console.log(userNameText.current);
    const name = userNameText.current;
    const pword = passText.current;
    const nameErr = usernameError(name);
    const pwordErr = passwordError(pword);
    if (nameErr) {
      setErrorMessage(nameErr);
      return;
    }
    if (pwordErr) {
      setErrorMessage(pwordErr);
      return;
    }

    (async function handleLoginAsync() {
      const status = await postLogin(name, pword);
      if (status === 401) {
        setErrorMessage('Password is incorrect');
        return;
      }
      if (status === 403) {
        setErrorMessage('Too many attempts');
        return;
      }
      if (status === 404) {
        setErrorMessage('User does not exist');
        return;
      }
      if ((status < 200) || (status >= 300)) {
        setErrorMessage('An unknown error occured');
        return;
      }
      setUsername(name);
    }());
  }

  return (
    <View className="regLoginWrapper" style={styles.container}>
      <ScrollView className="loginWrapper">
        <View className="loginWelcome">
          <Text style={styles.h1}>
            Breathe,
          </Text>
          <Text style={styles.h1}>
            work,
          </Text>
          <Text style={styles.h1}>
            play,
          </Text>
          <Text style={styles.h1}>
            sleep,
          </Text>
          <Text style={styles.h1}>
            repeat.
          </Text>
        </View>
        <View className="loginInputs">
          <View className="lMessage">
            <Text style={styles.lmessage}>
              stay well & get productive, all in one place
            </Text>
          </View>
          <Text className="error">
        &nbsp;
            {errorMessage}
          </Text>
          <View>
            <TextInput style={styles.linput} placeholder="username" onChangeText={handleUsernameInput} />
            <TextInput secureTextEntry style={styles.linput} placeholder="password" onChangeText={handlePasswordInput} />
          </View>
          <Button onPress={handleLogin} title="Login" />
        </View>
      </ScrollView>
    </View>

  );
}

export default Login;
