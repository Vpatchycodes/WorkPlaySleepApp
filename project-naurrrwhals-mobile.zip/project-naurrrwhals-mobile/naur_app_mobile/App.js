/* eslint-disable no-unused-vars */
import {
  React, useState, useEffect,
} from 'react';
import { StyleSheet, View, Text } from 'react-native';
import Homepage from './components/Homepage';
import Login from './components/Login';

import { appStyle } from './assets/styles';

export default function App() {
  const [username, setUsername] = useState('');
  const [time, setTime] = useState(Date.now());

  useEffect(() => {
    const interval = setInterval(() => setTime(Date.now()), 3000);
    return () => {
      clearInterval(interval);
    };
  }, []);

  return (
    <View style={appStyle.appBG}>
      {/* <Homepage namestring={username} time={time} /> */}
      <Text>
        {!username && (
        // <header className="App-header">
        <Login setUsername={setUsername} />
        //  </header>
        )}
      </Text>
      <Text>
        {username && (
        <View id="HomepageBox">
          <Homepage username={username} setUsername={setUsername} time={time} />
        </View>
        )}
      </Text>
    </View>
  );
}
