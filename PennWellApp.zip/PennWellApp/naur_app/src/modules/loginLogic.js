/* eslint-disable eqeqeq */
/* eslint-disable camelcase */

// validate username by producing appropriate status message
function checkValidUsername(str) {
  if (!str.match(/^[A-Za-z0-9_]*$/)) {
    return 'Username must be made up of letters, numbers, or underscores';
  }
  if (!str.match(/^[A-Za-z_][A-Za-z0-9_]*$/)) {
    return 'Username must start with a letter or underscore';
  }
  if (!str.match(/[A-Za-z0-9]/)) {
    return 'Username must contain contain at least one letter or number';
  }
  if (!(str.length >= 3)) {
    return 'Username must be at least 3 characters long';
  }
  return 'Valid username';
}

// validate password by producing appropriate status message
function checkValidPassword(str) {
  if (!str.match(/^[A-Za-z0-9\\!"#$%&'()*+,\-./:;<=>?@[\]^_`{|}~]+$/)) {
    return 'Password contains illegal character';
  }
  if (!(str.length >= 6)) {
    return 'Password must be at least 6 characters long';
  }
  return 'Valid password';
}

// setup security questions by producing appropriate status message
/*
   *NOTE: questionAnswerPairs is a 3x2 array where:
    - First row stores the security question, represented by integer 0 - 5 as the question option
      - The first entry by default stores security question number 5
    - Second row stores the corresponding answer, represented by a string
   */
function setupSecurityQuestions(questionAnswerPairs) {
  if (!questionAnswerPairs[0][1]) {
    return 'You must include at least 1 security question.';
  }

  for (let i = 1; i < 3; i += 1) {
    if (questionAnswerPairs[i][0] === '0' && !questionAnswerPairs[i][1]) {
      return 'Need to select a question to store answer';
    }
  }

  return 'Successfully set security questions';
}

// perform registration lockout by producing appropriate status message
function checkLockedOut(numTries, passwordInput, correctPassword) {
  // automatic lockout
  if (numTries >= 4) {
    return 'You are locked out. Try resetting your password';
  }

  // last try logging in unsuccessful
  if ((passwordInput != correctPassword) && numTries === 3) {
    return 'Too many attempts. Try resetting your password';
  }

  // successful login
  if (passwordInput === correctPassword) {
    return 'Successfully logged in';
  }

  return 'Password incorrect. Try logging in again';
}

module.exports = {
  checkValidUsername,
  checkValidPassword,
  checkLockedOut,
  setupSecurityQuestions,
};
