import rootURL from '../modules/url';

const axios = require('axios');
const MockAdapter = require('axios-mock-adapter');
const task = require('../modules/taskApi');

let mock;

beforeEach(() => {
  mock = new MockAdapter(axios);
});

test('get task list empty', async () => {
  const response = await task.getTaskList('serena');
  expect(response).toMatchObject([]);
});

test('get task list full', async () => {
  const expected = [{
    task_id: 0, due_date: '2022-05-09T05:29', title: 'code', progress: 50,
  }];
  mock.onGet(`${rootURL}/tasks/tasklist/bobby`).reply(200, expected);
  const response = await task.getTaskList('bobby');
  expect(response).toMatchObject(expected);
});

test('post new task failure', async () => {
  await expect(task.postNewTask('serena')).rejects.toThrow(`Error when calling ${rootURL}/tasks/create/serena`);
});

test('post new task success', async () => {
  const task0 = {
    task_id: 0, due_date: '2022-05-09T05:29', title: 'code', progress: 50,
  };
  mock.onPost(`${rootURL}/tasks/create/bobby`, task0).reply(201);
  const response = await task.postNewTask('bobby', task0);
  expect(response).toBe(201);
});

test('post update task failure', async () => {
  await expect(task.postUpdateTask('serena', 0)).rejects.toThrow(`Error when calling ${rootURL}/tasks/0/serena`);
});

test('post update task success', async () => {
  const task0 = {
    task_id: 0, due_date: '2022-05-09T09:09', title: 'eat', progress: 10,
  };
  mock.onPut(`${rootURL}/tasks/0/bobby`, task0).reply(200);
  const response = await task.postUpdateTask('bobby', 0, task0);
  expect(response).toBe(200);
});

test('delete task failure', async () => {
  await expect(task.deleteTask('serena', 0)).rejects.toThrow(`Error when calling ${rootURL}/tasks/0/serena`);
});

test('delete task success', async () => {
  mock.onDelete(`${rootURL}/tasks/0/bobby`).reply(200);
  const response = await task.deleteTask('bobby', 0);
  expect(response).toBe(200);
});
