const time = require('../modules/timeFuncs');

test('date to string local', () => {
  const result = time.dateToStringLocal(new Date(2022, 3, 29));
  expect(result).toBe('2022-04-29');
});

test('string to date local', () => {
  const result = time.stringToDateLocal('2022-04-29');
  expect(result).toMatchObject(new Date(2022, 3, 29));
});

test('date time to string local', () => {
  const result = time.datetimeToStringLocal(new Date(2022, 3, 29, 6, 29));
  expect(result).toBe('2022-04-29T06:29');
});

test('string to date time local', () => {
  const result = time.stringToDatetimeLocal('2022-04-29-06:29');
  expect(result).toMatchObject(new Date(2022, 3, 29, 6, 29));
});

test('combine date time string', () => {
  const result = time.combineDateTimeString('2022-04-29', '06:29');
  expect(result).toBe('2022-04-29T06:29');
});

test('extract date string', () => {
  const result = time.extractDateString('2022-04-29T06:29');
  expect(result).toBe('2022-04-29');
});

test('extract time string', () => {
  const result = time.extractTimeString('2022-04-29T06:29');
  expect(result).toBe('06:29');
});

test('get current time string', () => {
  const result = time.getCurrentTimeString();
  const hours = new Date().getHours().toString().padStart(2, '0');
  const minutes = new Date().getMinutes().toString().padStart(2, '0');
  expect(result).toBe(`${hours}:${minutes}`);
});

test('get current date string', () => {
  const result = time.getCurrentDateString();
  const year = new Date().getFullYear().toString();
  const month = (new Date().getMonth() + 1).toString().padStart(2, '0');
  const date = new Date().getDate().toString().padStart(2, '0');
  expect(result).toBe(`${year}-${month}-${date}`);
});

// added for compatibility - identical to timeFuncs
const util = require('../modules/utils');

test('date to string local', () => {
  const result = util.dateToStringLocal(new Date(2022, 3, 29));
  expect(result).toBe('2022-04-29');
});

test('string to date local', () => {
  const result = util.stringToDateLocal('2022-04-29');
  expect(result).toMatchObject(new Date(2022, 3, 29));
});

test('date time to string local', () => {
  const result = util.datetimeToStringLocal(new Date(2022, 3, 29, 6, 29));
  expect(result).toBe('2022-04-29T06:29');
});

test('string to date time local', () => {
  const result = util.stringToDatetimeLocal('2022-04-29-06:29');
  expect(result).toMatchObject(new Date(2022, 3, 29, 6, 29));
});

test('combine date time string', () => {
  const result = util.combineDateTimeString('2022-04-29', '06:29');
  expect(result).toBe('2022-04-29T06:29');
});

test('extract date string', () => {
  const result = util.extractDateString('2022-04-29T06:29');
  expect(result).toBe('2022-04-29');
});

test('extract time string', () => {
  const result = util.extractTimeString('2022-04-29T06:29');
  expect(result).toBe('06:29');
});
