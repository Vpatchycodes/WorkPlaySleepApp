const loginLogic = require('../modules/loginLogic');

// login logic tests
test('validate username', () => {
  const m1 = loginLogic.checkValidUsername('#dpeo');
  expect(m1).toBe('Username must be made up of letters, numbers, or underscores');
  const m2 = loginLogic.checkValidUsername('3dpeo');
  expect(m2).toBe('Username must start with a letter or underscore');
  const m3 = loginLogic.checkValidUsername('_____');
  expect(m3).toBe('Username must contain contain at least one letter or number');
  const m4 = loginLogic.checkValidUsername('pe');
  expect(m4).toBe('Username must be at least 3 characters long');
  const m5 = loginLogic.checkValidUsername('bobby1');
  expect(m5).toBe('Valid username');
});

test('validate password', () => {
  const m2 = loginLogic.checkValidPassword('3dpeo');
  expect(m2).toBe('Password must be at least 6 characters long');
  const m3 = loginLogic.checkValidPassword('bobby1');
  expect(m3).toBe('Valid password');
});

test('check registration lockout', () => {
  const m1 = loginLogic.checkLockedOut(4, 'bobby1', 'bobby1');
  expect(m1).toBe('You are locked out. Try resetting your password');
  const m2 = loginLogic.checkLockedOut(3, 'bobby2', 'bobby1');
  expect(m2).toBe('Too many attempts. Try resetting your password');
  const m3 = loginLogic.checkLockedOut(2, 'bobby1', 'bobby1');
  expect(m3).toBe('Successfully logged in');
  const m4 = loginLogic.checkLockedOut(1, 'bobby2', 'bobby1');
  expect(m4).toBe('Password incorrect. Try logging in again');
});

test('setup security questions', () => {
  const sqa1 = [['5'], [], []];
  const m1 = loginLogic.setupSecurityQuestions(sqa1);
  expect(m1).toBe('You must include at least 1 security question.');
  const sqa2 = [['5', 'namrita'], ['0', 'loggy'], ['0']];
  const m2 = loginLogic.setupSecurityQuestions(sqa2);
  expect(m2).toBe('Need to select a question to store answer');
  const sqa3 = [['5', 'namrita'], ['4', 'loggy'], ['3', 'bob']];
  const m3 = loginLogic.setupSecurityQuestions(sqa3);
  expect(m3).toBe('Successfully set security questions');
});
