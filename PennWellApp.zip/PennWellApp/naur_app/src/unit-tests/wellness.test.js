/* eslint-disable max-len */
import rootURL from '../modules/url';

const axios = require('axios');
const MockAdapter = require('axios-mock-adapter');
const wellnessApi = require('../modules/wellnessApi');

let mock;

beforeEach(() => {
  mock = new MockAdapter(axios);
});

// survey.js API tests
test('put sleep satisfaction success', async () => {
  const expected = {
    sleepSat: '4',
    workSat: '5',
    relaxSat: '5',
    priority: 'relaxation',
    mood: '5',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onPut(`${rootURL}/wellness/survey/bobby`).reply(200, expected);
  const response1 = await wellnessApi.PUT_sleepSat('bobby', '4');
  expect(response1).toBe('4');
});

test('put work satisfaction success', async () => {
  const expected = {
    sleepSat: '5',
    workSat: '3',
    relaxSat: '5',
    priority: 'relaxation',
    mood: '5',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onPut(`${rootURL}/wellness/survey/bobby`).reply(200, expected);
  const response1 = await wellnessApi.PUT_workSat('bobby', '3');
  expect(response1).toBe('3');
});

test('put relax satisfaction success', async () => {
  const expected = {
    sleepSat: '5',
    workSat: '5',
    relaxSat: '2',
    priority: 'relaxation',
    mood: '5',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onPut(`${rootURL}/wellness/survey/bobby`).reply(200, expected);
  const response1 = await wellnessApi.PUT_relaxSat('bobby', '2');
  expect(response1).toBe('2');
});

test('put mood success', async () => {
  const expected = {
    sleepSat: '5',
    workSat: '5',
    relaxSat: '5',
    priority: 'relaxation',
    mood: '0',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onPut(`${rootURL}/wellness/survey/bobby`).reply(200, expected);
  const response1 = await wellnessApi.PUT_mood('bobby', '0');
  expect(response1).toBe('0');
});

test('put priority success', async () => {
  const expected = {
    sleepSat: '5',
    workSat: '5',
    relaxSat: '5',
    priority: 'sleep',
    mood: '5',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onPut(`${rootURL}/wellness/survey/bobby`).reply(200, expected);
  const response1 = await wellnessApi.PUT_priority('bobby', 'sleep');
  expect(response1).toBe('sleep');
});

// priority.js API tests - commented out since coverage needs met

// recommendations.js API tests
test('get desired sleep', async () => {
  const expected = {
    sleepSat: '5',
    workSat: '5',
    relaxSat: '5',
    priority: 'relaxation',
    mood: '5',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onGet(`${rootURL}/wellness/survey/bobby`).reply(200, expected); // return default given no put request
  const response1 = await wellnessApi.GET_desiredHoursSleep('bobby');
  expect(response1).toBe(8);
  mock.onGet(`${rootURL}/wellness/survey/bobby`).reply(200, expected); // return default given no put request
  const response2 = await wellnessApi.GET_desiredTimeSleep('bobby');
  expect(response2).toBe('2200');
});

test('get desired work', async () => {
  const expected = {
    sleepSat: '5',
    workSat: '5',
    relaxSat: '5',
    priority: 'relaxation',
    mood: '5',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onGet(`${rootURL}/wellness/survey/bobby`).reply(200, expected); // return default given no put request
  const response = await wellnessApi.GET_desiredHoursWork('bobby');
  expect(response).toBe(8);
  mock.onGet(`${rootURL}/wellness/survey/bobby`).reply(200, expected); // return default given no put request
  const response1 = await wellnessApi.GET_desiredWorkBlock('bobby');
  expect(response1).toBe(45);
  mock.onGet(`${rootURL}/wellness/survey/bobby`).reply(200, expected); // return default given no put request
  const response2 = await wellnessApi.GET_desiredWorkEndTime('bobby');
  expect(response2).toBe('2200');
});

test('get desired relax', async () => {
  const expected = {
    sleepSat: '5',
    workSat: '5',
    relaxSat: '5',
    priority: 'relaxation',
    mood: '5',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onGet(`${rootURL}/wellness/survey/bobby`).reply(200, expected); // return default given no put request
  const response1 = await wellnessApi.GET_desiredHoursRelax('bobby');
  expect(response1).toBe(8);
  mock.onGet(`${rootURL}/wellness/survey/bobby`).reply(200, expected); // return default given no put request
  const response2 = await wellnessApi.GET_desiredRelaxActivity('bobby');
  expect(response2).toBe('Ride a bike');
});

// All together - post final survey for the day to db
test('post daily survey failure', async () => {
  await expect(wellnessApi.POST_dailySurvey('bobby')).rejects.toThrow(`Error when calling ${rootURL}/wellness/survey/bobby`);
});

test('post daily survey success', async () => {
  const final = {
    sleepSat: '5',
    workSat: '5',
    relaxSat: '5',
    priority: 'relaxation',
    mood: '5',
    desired_hours_sleep: 8,
    desired_time_sleep: '2200',
    desired_hours_work: 8,
    desired_block_work: 45,
    desired_time_work: '2200',
    desired_hours_relax: 8,
    desired_activity: 'Ride a bike',
  };
  mock.onPost(`${rootURL}/wellness/survey/bobby`).reply(200, final);
  const response1 = await wellnessApi.POST_dailySurvey('bobby');
  expect(response1).toMatchObject(final);
});
