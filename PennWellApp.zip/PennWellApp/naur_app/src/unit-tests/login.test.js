/* eslint-disable max-len */
import rootURL from '../modules/url';

const axios = require('axios');
const MockAdapter = require('axios-mock-adapter');
const loginStorage = require('../modules/loginApi');

let mock;

beforeAll(() => {
  mock = new MockAdapter(axios);
});

// login storage tests
test('creating new account failure', async () => {
  await expect(loginStorage.postRegister()).rejects.toThrow(`Error when calling ${rootURL}/register`);
});

test('creating new account success', async () => {
  mock.onPost(`${rootURL}/register`).reply(204);
  const response1 = await loginStorage.postRegister('bobby', 'bbb123');
  expect(response1).toBe(204);
});

test('creating new account already exists failure', async () => {
  mock.onPost(`${rootURL}/register`).reply(403);
  const response = await loginStorage.postRegister('bobby', 'bbb123');
  expect(response).toBe(403);
});

test('logging user in password wrong', async () => {
  mock.onPost(`${rootURL}/login`).reply(401);
  const response = await loginStorage.postLogin('bobby', 'abb123');
  expect(response).toBe(401);
});

test('logging user in too many tries', async () => {
  mock.onPost(`${rootURL}/login`).reply(403);
  const response = await loginStorage.postLogin('bobby', 'abb123');
  expect(response).toBe(403);
});

test('logging user in success', async () => {
  mock.onPost(`${rootURL}/login`).reply(204);
  const response = await loginStorage.postLogin('bobby', 'bbb123');
  expect(response).toBe(204);
});

test('post security questions failure', async () => {
  await expect(loginStorage.postSecurityQuestions('bobby')).rejects.toThrow(`Error when calling ${rootURL}/securityquestions/bobby`);
});

test('post security questions success', async () => {
  mock.onPost(`${rootURL}/securityquestions/bobby`).reply(201);
  const response = await loginStorage.postSecurityQuestions('bobby', { question: 'Your dog?', answer: 'Milo' });
  expect(response).toBe(201);
});

test('get security questions failure', async () => {
  await expect(loginStorage.getSecurityQuestions()).rejects.toThrow(`Error when calling ${rootURL}/securityquestions/`);
});

test('get security questions success', async () => {
  mock.onGet(`${rootURL}/securityquestions/bobby`).reply(200, { question: 'Your dog?', answer: 'Milo' });
  const response = await loginStorage.getSecurityQuestions('bobby');
  expect(response).toMatchObject({ question: 'Your dog?', answer: 'Milo' });
});

test('post reset password failure', async () => {
  await expect(loginStorage.postResetPassword('bobby')).rejects.toThrow(`Error when calling ${rootURL}/resetpassword/bobby`);
});

test('post reset password success', async () => {
  mock.onPost(`${rootURL}/resetpassword/bobby`).reply(200);
  const response = await loginStorage.postResetPassword('bobby', 'jon123', { question: 'Your dog?', answer: 'Milo' });
  expect(response).toBe(200);
});

test('post reset password incorrect answers', async () => {
  mock.onPost(`${rootURL}/resetpassword/bobby`).reply(403);
  const response = await loginStorage.postResetPassword('bobby', 'jon123', { question: 'Your dog?', answer: 'Adam' });
  expect(response).toBe(403);
});

// test('delete user failure', async () => {
//   await expect(loginStorage.deleteUser()).rejects.toThrow(`Error when calling ${rootURL}/deleteuser.`);
// });

test('delete user success', async () => {
  mock.onDelete(`${rootURL}/deleteuser/bobby`).reply(200);
  const response = await loginStorage.deleteUser('bobby');
  expect(response).toBe(200);
});

test('delete user does not exist', async () => {
  mock.onPost(`${rootURL}/deleteuser/gojjy`).reply(404);
  const response = await loginStorage.deleteUser('gojjy');
  expect(response).toBe(404);
});
