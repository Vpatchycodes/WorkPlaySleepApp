import rootURL from '../modules/url';

const axios = require('axios');
const MockAdapter = require('axios-mock-adapter');
const message = require('../modules/messageApi');
const { getCurrentDateString, getCurrentTimeString } = require('../modules/timeFuncs');

let mock;

beforeEach(() => {
  mock = new MockAdapter(axios);
});

test('get user exists failure', async () => {
  await expect(message.getUserExists('serena')).rejects.toThrow('Error sending request');
});

test('get user exists invalid', async () => {
  await expect(message.getUserExists()).rejects.toThrow('invalid username');
});

test('get user exists success', async () => {
  const expected = { result: true };
  mock.onGet(`${rootURL}/messaging/user/exists/bobby`).reply(200, expected);
  const response = await message.getUserExists('bobby');
  expect(response).toBe(true);
});

test('post user failure', async () => {
  await expect(message.postMessagingUser('serena')).rejects.toThrow('Error sending request');
});

test('post user invalid', async () => {
  await expect(message.postMessagingUser()).rejects.toThrow('invalid username');
});

test('post user success', async () => {
  mock.onPost(`${rootURL}/messaging/user/bobby`).reply(200);
  const response = await message.postMessagingUser('bobby');
  expect(response).toBe(undefined);
});

test('delete user failure', async () => {
  await expect(message.deleteMessagingUser('serena')).rejects.toThrow('Error sending request');
});

test('delete user invalid', async () => {
  await expect(message.deleteMessagingUser()).rejects.toThrow('invalid username');
});

test('delete user success', async () => {
  mock.onDelete(`${rootURL}/messaging/user/bobby`).reply(200);
  const response = await message.deleteMessagingUser('bobby');
  expect(response).toBe(undefined);
});

test('get friend exists failure', async () => {
  await expect(message.getFriendExists('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('get friend exists invalid', async () => {
  await expect(message.getFriendExists()).rejects.toThrow('invalid username');
  await expect(message.getFriendExists('serena')).rejects.toThrow('invalid username');
});

test('get friend exists success', async () => {
  const expected = { result: true };
  mock.onGet(`${rootURL}/messaging/friends/exists/bobby/adam`).reply(200, expected);
  const response = await message.getFriendExists('bobby', 'adam');
  expect(response).toBe(true);
});

test('get pending exists failure', async () => {
  await expect(message.getPendingExists('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('get pending exists invalid', async () => {
  await expect(message.getPendingExists()).rejects.toThrow('invalid username');
  await expect(message.getPendingExists('serena')).rejects.toThrow('invalid username');
});

test('get pending exists success', async () => {
  const expected = { result: true };
  mock.onGet(`${rootURL}/messaging/pending/exists/bobby/adam`).reply(200, expected);
  const response = await message.getPendingExists('bobby', 'adam');
  expect(response).toBe(true);
});

test('get requested exists failure', async () => {
  await expect(message.getRequestedExists('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('get requested exists invalid', async () => {
  await expect(message.getRequestedExists()).rejects.toThrow('invalid username');
  await expect(message.getRequestedExists('serena')).rejects.toThrow('invalid username');
});

test('get requested exists success', async () => {
  const expected = { result: true };
  mock.onGet(`${rootURL}/messaging/requested/exists/bobby/adam`).reply(200, expected);
  const response = await message.getRequestedExists('bobby', 'adam');
  expect(response).toBe(true);
});

test('get friend first user dont exist', async () => {
  const response = await message.getFriendFirst('serena');
  expect(response).toBe(undefined);
});

// test('get friend first failure', async () => {
//   mock.onGet(`${rootURL}/messaging/friends/first/bobby`).reply(500);
//   await expect(message.getFriendFirst('serena')).rejects.toThrow('Error sending request');
// });

test('get friend first invalid', async () => {
  await expect(message.getFriendFirst()).rejects.toThrow('invalid username');
});

test('get friend first success', async () => {
  const expected = {
    friend: 'adam',
    most_recent_message: {
      from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
    },
  };
  mock.onGet(`${rootURL}/messaging/friends/first/bobby`).reply(200, expected);
  const response = await message.getFriendFirst('bobby');
  expect(response).toBe('adam');
});

test('get pending first user dont exist', async () => {
  const response = await message.getPendingFirst('serena');
  expect(response).toBe(undefined);
});

// test('get pending first failure', async () => {
//   mock.onGet(`${rootURL}/messaging/pending/first/bobby`).reply(500);
//   await expect(message.getPendingFirst('serena')).rejects.toThrow('Error sending request');
// });

test('get pending first invalid', async () => {
  await expect(message.getPendingFirst()).rejects.toThrow('invalid username');
});

test('get pending first success', async () => {
  const expected = {
    friend: 'adam',
    most_recent_message: {
      from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
    },
  };
  mock.onGet(`${rootURL}/messaging/pending/first/bobby`).reply(200, expected);
  const response = await message.getPendingFirst('bobby');
  expect(response).toBe('adam');
});

test('get requested first user dont exist', async () => {
  const response = await message.getRequestedFirst('serena');
  expect(response).toBe(undefined);
});

// test('get requested first failure', async () => {
//   mock.onGet(`${rootURL}/messaging/requested/first/bobby`).reply(500);
//   await expect(message.getRequestedFirst('serena')).rejects.toThrow('Error sending request');
// });

test('get requested first invalid', async () => {
  await expect(message.getRequestedFirst()).rejects.toThrow('invalid username');
});

test('get requested first success', async () => {
  const expected = {
    friend: 'adam',
    most_recent_message: {
      from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
    },
  };
  mock.onGet(`${rootURL}/messaging/requested/first/bobby`).reply(200, expected);
  const response = await message.getRequestedFirst('bobby');
  expect(response).toBe('adam');
});

// get friend list
test('get friend list failure', async () => {
  await expect(message.getFriendList('serena')).rejects.toThrow('Error sending request');
});

test('get friend list invalid', async () => {
  await expect(message.getFriendList()).rejects.toThrow('invalid username');
});

test('get friend list success', async () => {
  const expected = {
    list: [{
      friend: 'adam',
      most_recent_message: {
        from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
      },
    }],
  };
  mock.onGet(`${rootURL}/messaging/friends/list/bobby`).reply(200, expected);
  const response = await message.getFriendList('bobby');
  expect(response).toMatchObject([{
    friend: 'adam',
    most_recent_message: {
      from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
    },
  }]);
});

test('get pending list failure', async () => {
  await expect(message.getPendingList('serena')).rejects.toThrow('Error sending request');
});

test('get pending list invalid', async () => {
  await expect(message.getPendingList()).rejects.toThrow('invalid username');
});

test('get pending list success', async () => {
  const expected = {
    list: [{
      friend: 'adam',
      most_recent_message: {
        from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
      },
    }],
  };
  mock.onGet(`${rootURL}/messaging/pending/list/bobby`).reply(200, expected);
  const response = await message.getPendingList('bobby');
  expect(response).toMatchObject([{
    friend: 'adam',
    most_recent_message: {
      from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
    },
  }]);
});

test('get requested list failure', async () => {
  await expect(message.getRequestedList('serena')).rejects.toThrow('Error sending request');
});

test('get requested list invalid', async () => {
  await expect(message.getRequestedList()).rejects.toThrow('invalid username');
});

test('get requested list success', async () => {
  const expected = {
    list: [{
      friend: 'adam',
      most_recent_message: {
        from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
      },
    }],
  };
  mock.onGet(`${rootURL}/messaging/requested/list/bobby`).reply(200, expected);
  const response = await message.getRequestedList('bobby');
  expect(response).toMatchObject([{
    friend: 'adam',
    most_recent_message: {
      from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
    },
  }]);
});

// put friend
test('put friend failure', async () => {
  await expect(message.putFriend('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('put friend invalid', async () => {
  await expect(message.putFriend()).rejects.toThrow('invalid username');
  await expect(message.putFriend('serena')).rejects.toThrow('invalid username');
});

test('put friend success', async () => {
  mock.onPut(`${rootURL}/messaging/friends/bobby/adam`).reply(200);
  const response = await message.putFriend('bobby', 'adam');
  expect(response).toBe(undefined);
});

test('put pending failure', async () => {
  await expect(message.putPending('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('put pending invalid', async () => {
  await expect(message.putPending()).rejects.toThrow('invalid username');
  await expect(message.putPending('serena')).rejects.toThrow('invalid username');
});

test('put pending success', async () => {
  mock.onPut(`${rootURL}/messaging/pending/bobby/adam`).reply(200);
  const response = await message.putPending('bobby', 'adam');
  expect(response).toBe(undefined);
});

test('put requested failure', async () => {
  await expect(message.putRequested('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('put requested invalid', async () => {
  await expect(message.putRequested()).rejects.toThrow('invalid username');
  await expect(message.putRequested('serena')).rejects.toThrow('invalid username');
});

test('put requested success', async () => {
  mock.onPut(`${rootURL}/messaging/requested/bobby/adam`).reply(200);
  const response = await message.putRequested('bobby', 'adam');
  expect(response).toBe(undefined);
});

// delete friend
test('delete friend failure', async () => {
  await expect(message.deleteFriend('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('delete friend invalid', async () => {
  await expect(message.deleteFriend()).rejects.toThrow('invalid username');
  await expect(message.deleteFriend('serena')).rejects.toThrow('invalid username');
});

test('delete friend success', async () => {
  mock.onDelete(`${rootURL}/messaging/friends/bobby/adam`).reply(200);
  const response = await message.deleteFriend('bobby', 'adam');
  expect(response).toBe(undefined);
});

test('delete pending failure', async () => {
  await expect(message.deletePending('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('delete pending invalid', async () => {
  await expect(message.deletePending()).rejects.toThrow('invalid username');
  await expect(message.deletePending('serena')).rejects.toThrow('invalid username');
});

test('delete pending success', async () => {
  mock.onDelete(`${rootURL}/messaging/pending/bobby/adam`).reply(200);
  const response = await message.deletePending('bobby', 'adam');
  expect(response).toBe(undefined);
});

test('delete requested failure', async () => {
  await expect(message.deleteRequested('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('delete requested invalid', async () => {
  await expect(message.deleteRequested()).rejects.toThrow('invalid username');
  await expect(message.deleteRequested('serena')).rejects.toThrow('invalid username');
});

test('delete requested success', async () => {
  mock.onDelete(`${rootURL}/messaging/requested/bobby/adam`).reply(200);
  const response = await message.deleteRequested('bobby', 'adam');
  expect(response).toBe(undefined);
});

// get * put * delete log
test('get message log failure', async () => {
  await expect(message.getMessageLog('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('get message log invalid', async () => {
  await expect(message.getMessageLog()).rejects.toThrow('invalid username');
  await expect(message.getMessageLog('serena')).rejects.toThrow('invalid username');
});

test('get message log success', async () => {
  const expected = {
    log: [{
      from: 'adam', to: 'bobby', time: '04:29', content: 'Hey',
    }],
  };
  mock.onGet(`${rootURL}/messaging/messages/bobby/adam`).reply(200, expected);
  const response = await message.getMessageLog('bobby', 'adam');
  expect(response).toMatchObject(expected.log);
});

test('put message log failure', async () => {
  await expect(message.putMessageLog('serena', 'rock', 'Hey')).rejects.toThrow('Error sending request');
});

test('put message log invalid', async () => {
  await expect(message.putMessageLog()).rejects.toThrow('invalid username');
  await expect(message.putMessageLog('serena')).rejects.toThrow('invalid username');
});

test('put message log success', async () => {
  mock.onPut(`${rootURL}/messaging/messages/bobby/adam`, { message: 'Hey', date: getCurrentDateString(), time: getCurrentTimeString() }).reply(200);
  const response = await message.putMessageLog('bobby', 'adam', 'Hey');
  expect(response).toBe(undefined);
});

test('delete message log failure', async () => {
  await expect(message.deleteMessageLog('serena', 'rock')).rejects.toThrow('Error sending request');
});

test('delete message log invalid', async () => {
  await expect(message.deleteMessageLog()).rejects.toThrow('invalid username');
  await expect(message.deleteMessageLog('serena')).rejects.toThrow('invalid username');
});

test('delete message log success', async () => {
  mock.onDelete(`${rootURL}/messaging/messages/bobby/adam`).reply(200);
  const response = await message.deleteMessageLog('bobby', 'adam');
  expect(response).toBe(undefined);
});

// get count
test('get count failure', async () => {
  await expect(message.getMessageCount('serena')).rejects.toThrow('Error sending request');
});

test('get count invalid', async () => {
  await expect(message.getMessageCount()).rejects.toThrow('invalid username');
});

test('get count success', async () => {
  const expected = { count: 27 };
  mock.onGet(`${rootURL}/messaging/messagecount/bobby`).reply(200, expected);
  const response = await message.getMessageCount('bobby');
  expect(response).toBe(27);
});
