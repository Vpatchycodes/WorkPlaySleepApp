import rootURL from '../modules/url';

const axios = require('axios');
const MockAdapter = require('axios-mock-adapter');
const calendar = require('../modules/calendarApi');

let mock;

beforeEach(() => {
  mock = new MockAdapter(axios);
});

test('get calendar event full', async () => {
  const expected = [{ color: '#404040', name: 'read' }];
  mock.onGet(`${rootURL}/calendar/event/list/bobby`).reply(200, expected);
  const response1 = await calendar.getCalendarEventList('bobby');
  expect(response1).toMatchObject(expected);
});

test('get calendar event empty', async () => {
  mock.onGet(`${rootURL}/calendar/event/list/bobby`).reply(404, []);
  const response1 = await calendar.getCalendarEventList('yun');
  expect(response1).toMatchObject([]);
});

test('post calendar event failure', async () => {
  await expect(calendar.postCalendarEventCreate('bobby')).rejects.toThrow(`Error when calling ${rootURL}/calendar/event/create/bobby`);
});

test('post calendar event success', async () => {
  const expected = { color: '#404040', name: 'read' };
  mock.onPost(`${rootURL}/calendar/event/create/bobby`).reply(201, expected);
  const response1 = await calendar.postCalendarEventCreate('bobby', 'read', '#404040');
  expect(response1).toMatchObject(expected);
});

test('get calendar event id failure', async () => {
  await expect(calendar.getCalendarEventEventID(1)).rejects.toThrow(`Error when calling ${rootURL}/calendar/event/1/`);
});

test('get calendar event id success', async () => {
  const expected = { color: '#404040', name: 'read' };
  mock.onGet(`${rootURL}/calendar/event/1/bobby`).reply(200, expected);
  const response1 = await calendar.getCalendarEventEventID(1, 'bobby');
  expect(response1).toMatchObject(expected);
});

test('put calendar event id failure', async () => {
  await expect(calendar.postCalendarEventEventID(1)).rejects.toThrow(`Error when calling ${rootURL}/calendar/event/1/`);
});

test('put calendar event id success', async () => {
  const expected = { color: '#303030', name: 'read' };
  mock.onPut(`${rootURL}/calendar/event/1/bobby`).reply(200, expected);
  const response1 = await calendar.postCalendarEventEventID(1, 'bobby', 'read', '#303030');
  expect(response1).toMatchObject(expected);
});

test('delete calendar event id failure', async () => {
  await expect(calendar.deleteCalendarEventEventID(1)).rejects.toThrow(`Error when calling ${rootURL}/calendar/event/1/`);
});

test('delete calendar event id success', async () => {
  mock.onDelete(`${rootURL}/calendar/event/1/bobby`).reply(200);
  const response1 = await calendar.deleteCalendarEventEventID(1, 'bobby');
  expect(response1).toBe(200);
});

test('get calendar blob list failure', async () => {
  const response = await calendar.getCalendarBlobList('2022-05-29');
  expect(response).toMatchObject([]);
});

test('get calendar blob list success', async () => {
  const expected = [{ time: { start: '2022-05-29T05:29', end: '2022-05-29T06:29' } },
    { time: { start: '2022-05-29T11:29', end: '2022-05-29T12:29' } }];
  mock.onGet(`${rootURL}/calendar/blob/list/2022-05-29/bobby`).reply(200, expected);
  const response1 = await calendar.getCalendarBlobList('2022-05-29', 'bobby');
  expect(response1).toMatchObject(expected);
});

test('post calendar blob failure', async () => {
  await expect(calendar.postCalendarBlobCreate(1, 'bobby', '2022-05-29T05:29')).rejects.toThrow(`Error when calling ${rootURL}/calendar/blob/create/1/bobby`);
});

test('post calendar blob success', async () => {
  const expected = { time: { start: '2022-05-29T05:29', end: '2022-05-29T06:29' } };
  mock.onPost(`${rootURL}/calendar/blob/create/1/bobby`).reply(201, expected);
  const response1 = await calendar.postCalendarBlobCreate(1, 'bobby', '2022-05-29T05:29', '2022-05-29T06:29');
  expect(response1).toMatchObject(expected);
});

test('get calendar blob id failure', async () => {
  await expect(calendar.getCalendarBlobBlobID(1, 0)).rejects.toThrow(`Error when calling ${rootURL}/calendar/blob/1/0/`);
});

test('get calendar blob id success', async () => {
  const expected = { time: { start: '2022-04-29T05:29', end: '2022-04-29T06:29' } };
  mock.onGet(`${rootURL}/calendar/blob/1/0/bobby`).reply(200, expected);
  const response1 = await calendar.getCalendarBlobBlobID(1, 0, 'bobby');
  expect(response1).toMatchObject(expected);
});

test('put calendar blob id failure', async () => {
  await expect(calendar.postCalendarBlobBlobID(1, 0)).rejects.toThrow(`Error when calling ${rootURL}/calendar/blob/1/0/`);
});

test('put calendar blob id success', async () => {
  const expected = { time: { start: '2022-05-29T05:29', end: '2022-05-29T06:29' } };
  mock.onPut(`${rootURL}/calendar/blob/1/0/bobby`).reply(200, expected);
  const response1 = await calendar.postCalendarBlobBlobID(1, 0, 'bobby', '2022-05-29T05:29', '2022-05-29T06:29');
  expect(response1).toMatchObject(expected);
});

test('delete calendar blob id failure', async () => {
  await expect(calendar.deleteCalendarBlobBlobID(1, 0)).rejects.toThrow(`Error when calling ${rootURL}/calendar/blob/1/0/`);
});

test('delete calendar event id success', async () => {
  mock.onDelete(`${rootURL}/calendar/blob/1/0/bobby`).reply(200);
  const response1 = await calendar.deleteCalendarBlobBlobID(1, 0, 'bobby');
  expect(response1).toBe(200);
});
