/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { fireEvent, render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import Register from '../components/Register';

test('renders app and checks', () => {
  render(<Register />);
  const linkElement = screen.getByText('Welcome!');
  expect(linkElement).toBeInTheDocument();

  fireEvent.click(screen.getByText('Register'));
  const linkElement2 = screen.getByText('Username must start with a letter or underscore');
  expect(linkElement2).toBeInTheDocument();
});
