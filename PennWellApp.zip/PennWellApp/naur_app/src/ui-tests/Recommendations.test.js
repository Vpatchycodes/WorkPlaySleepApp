/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import {
  render, screen, fireEvent, waitFor,
} from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import Recommendations from '../components/Recommendations';

test('renders recommendation page', async () => {
  render(<Recommendations username="JO" />);
  const linkElement = screen.getByText('Recommendations');
  await waitFor(() => (linkElement));
  expect(linkElement).toBeInTheDocument();
});
