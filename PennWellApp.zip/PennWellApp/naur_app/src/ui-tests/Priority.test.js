/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import Priority from '../components/Priority';

test('renders relaxation priority', () => {
  render(<Priority data={['relaxation']} username="hi" />);
  const linkElement = screen.getByText('Desired Relaxation (Hours)');
  expect(linkElement).toBeInTheDocument();
});

test('renders sleep priority', () => {
  render(<Priority data={['Sleep']} username="hi" />);
  const linkElement = screen.getByText('Desired Bedtime');
  expect(linkElement).toBeInTheDocument();
});

test('renders work priority', () => {
  render(<Priority data={['Work']} username="hi" />);
  const linkElement = screen.getByText('Desired Work Block (Minutes)');
  expect(linkElement).toBeInTheDocument();
});
