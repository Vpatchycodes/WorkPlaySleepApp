/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import TaskView from '../components/TaskHolder';

test('renders app and checks', () => {
  render(<TaskView username="hi" />);
  const linkElement = screen.getByText('Sort by Name');
  expect(linkElement).toBeInTheDocument();
});
