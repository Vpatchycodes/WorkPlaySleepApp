/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import SecurityQuestions from '../components/securityQuestions';

test('render security', () => {
  render(<SecurityQuestions />);
  const linkElement = screen.getByText('Welcome!');
  expect(linkElement).toBeInTheDocument();
});

test('interact with security', () => {
  render(<SecurityQuestions />);
  fireEvent.click(screen.getByText('Set'));
  const linkElement = screen.getByText('You must include at least 1 security question.');
  expect(linkElement).toBeInTheDocument();
});
