/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import Message from '../components/Message';

test('renders text message', () => {
  const message = { msgText: 'hello' };
  render(<Message message={message} user="a" sender="b" time="0000" />);
  const linkElement = screen.getByText(message.msgText);
  expect(linkElement).toBeInTheDocument();
});
