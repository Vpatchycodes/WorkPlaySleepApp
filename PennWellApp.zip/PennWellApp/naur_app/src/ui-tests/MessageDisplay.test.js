/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import MessageDisplay from '../components/MessageDisplay';

test('renders Messages', () => {
  render(<MessageDisplay username="apple" selected="orange" time={0} />);
  const linkElement = screen.getByText('Messages');
  expect(linkElement).toBeInTheDocument();
});

test('renders no friends', () => {
  render(<MessageDisplay username="apple" selected={undefined} time={0} />);
  const linkElement = screen.getByText('You currently have no friends');
  expect(linkElement).toBeInTheDocument();
});
