/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import Registration from '../components/Registration';

test('renders app and checks', () => {
  render(<Registration />);
  const linkElement = screen.getByTestId('here I am');
  expect(linkElement).toBeInTheDocument();
});
