/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import Survey from '../components/Survey';

test('renders survey', () => {
  render(<Survey username="hi" />);
  const linkElement = screen.getByText('Rate your day yesterday');
  expect(linkElement).toBeInTheDocument();
  const linkElement0 = screen.getByText('How was your sleep?');
  expect(linkElement0).toBeInTheDocument();
  const linkElement2 = screen.getByText('How was your work?');
  expect(linkElement2).toBeInTheDocument();
  const linkElement4 = screen.getByText('How was your relaxation?');
  expect(linkElement4).toBeInTheDocument();
  const linkElement56 = screen.getByText('Start your day today');
  expect(linkElement56).toBeInTheDocument();
  const linkElement6 = screen.getByText('How do you feel today?');
  expect(linkElement6).toBeInTheDocument();
  const linkElement8 = screen.getByText('What is most important to you today');
  expect(linkElement8).toBeInTheDocument();
  const linkElement9 = screen.getByText('Sleep');
  expect(linkElement9).toBeInTheDocument();
  const linkElement10 = screen.getByText('Work');
  expect(linkElement10).toBeInTheDocument();
  const linkElement11 = screen.getByText('Relaxation');
  expect(linkElement11).toBeInTheDocument();
});
