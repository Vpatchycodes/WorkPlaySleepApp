/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import AddFriendDisplay from '../components/AddFriendDisplay';

test('renders Add Friend', () => {
  render(<AddFriendDisplay username="apple" />);
  const linkElement = screen.getByText('Add Friend');
  expect(linkElement).toBeInTheDocument();
});
