/* eslint-disable react/jsx-boolean-value */
/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import RegLock from '../components/regLock';

test('renders app and checks', () => {
  render(<RegLock setLockout={true} username="Helen" />);
  const linkElement = screen.getByText('Too many password attempts! Choose a new password');
  expect(linkElement).toBeInTheDocument();
});
