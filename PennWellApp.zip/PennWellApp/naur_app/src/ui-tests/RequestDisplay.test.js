/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import RequestDisplay from '../components/RequestDisplay';

test('renders Messages', () => {
  render(<RequestDisplay username="apple" loadFriendList={false} setLoadFriendList={() => {}} setSelectedFriend={() => {}} />);
  const linkElement = screen.getByText('Recieved Friend Requests');
  expect(linkElement).toBeInTheDocument();
});
