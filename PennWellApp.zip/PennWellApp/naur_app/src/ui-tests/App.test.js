/* eslint-disable no-undef */
/* eslint-disable react/jsx-filename-extension */
/**
 * @jest-environment jsdom
 */
import React from 'react';

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import '@testing-library/jest-dom';

import App from '../components/App';

test('renders app and checks', () => {
  render(<App />);
  const linkElement = screen.getByText('stay well & get productive, all in one place');
  expect(linkElement).toBeInTheDocument();
});
