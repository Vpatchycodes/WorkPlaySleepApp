// import supertest
const request = require('supertest');

// import our web app
const webapp = require('./server');

// Import database operations
const dbLib = require('./database');

// eslint-disable-next-line no-unused-vars
let db;

beforeAll(async () => {
  webapp.listen();
  db = await dbLib.connectToDatabases();
});

afterAll(async () => {
  await dbLib.disconnectFromDatabases();
});

// Login and user management endpoints

// webapp.post('/login', wrapErrors(login.handlePostLogin));
describe('/login endpoint test', () => {
  test('POST response no parameters', async () => {
    const response = await request(webapp).post('/login').expect(400);

    return expect(JSON.parse(response.text).error).toBe('Missing parameters');
  });

  test('POST response invalid username', async () => {
    const response = await request(webapp).post('/login').send({ username: 't', password: '1' }).expect(400);

    return expect(JSON.parse(response.text).error).toBe('Invalid parameters');
  });

  test('POST response user does not exist', async () => {
    const response = await request(webapp).post('/login').send({ username: 'testuser1', password: 'testpassword2' }).expect(404);

    return expect(JSON.parse(response.text).error).toBe('User does not exist');
  });

  test('POST response wrong password', async () => {
    const response = await request(webapp).post('/login').send({ username: 'testuser2', password: 'testpassword1' }).expect(401);

    return expect(JSON.parse(response.text).error).toBe('Incorrect password');
  });

  test('POST response sucess', async () => {
    const response = await request(webapp).post('/login').send({ username: 'testuser2', password: 'testpassword2' }).expect(200);

    return expect(JSON.parse(response.text).message).toBe('Logged in');
  });
});

// webapp.post('/register', wrapErrors(login.handlePostRegister));
describe('/register endpoint test', () => {
  test('POST response no parameters', async () => {
    const response = await request(webapp).post('/register').expect(400);

    return expect(JSON.parse(response.text).error).toBe('Missing parameters');
  });

  test('POST response invalid username', async () => {
    const response = await request(webapp).post('/register').send({ username: 't', password: '1' }).expect(400);

    return expect(JSON.parse(response.text).error).toBe('Invalid parameters');
  });

  test('POST response user already exists', async () => {
    const response = await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' }).expect(403);

    return expect(JSON.parse(response.text).error).toBe('User already exists');
  });

  test('POST response sucess', async () => request(webapp).post('/register').send({ username: 'testuser1', password: 'testpassword1' }).expect(204));
});

// webapp.delete(`/deleteuser/${userParam}`, wrapErrors(login.handleDeleteDeleteuser));
describe('/deleteuser/user endpoint test', () => {
  // test('DELETE response username invalid', async () => {
  //   const response = await request(webapp).delete('/deleteuser/t').expect(400);

  //   return expect(JSON.parse(response.text).error).toBe('Invalid parameters');
  // });

  test('DELETE response user does not exist', async () => {
    const response = await request(webapp).delete('/deleteuser/testuser3').expect(404);

    return expect(JSON.parse(response.text).error).toBe('User does not exist');
  });

  test('DELETE response sucess', async () => {
    const response = await request(webapp).delete('/deleteuser/testuser1').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Deleted');
  });
});

// webapp.post(`/securityquestions/${userParam}`,
// wrapErrors(login.handlePostSecurityQuestionsUser));
// webapp.get(`/securityquestions/${userParam}`, wrapErrors(login.handleGetSecurityQuestionsUser));
describe('/securityquestions/user endpoint test', () => {
  test('POST response missing security questions', async () => {
    const response = await request(webapp).post('/securityquestions/testuser2').expect(400);

    return expect(JSON.parse(response.text).error).toBe('Missing parameters');
  });

  test('POST response sucess', async () => {
    await request(webapp).post('/securityquestions/testuser2').send([{
      question: 'What was the name of your first pet?',
      answer: 'Fido',
    }]).expect(201);
  });

  test('POST response user does not exist', async () => {
    await request(webapp).post('/securityquestions/testuser3').send([{
      question: 'What was the name of your first pet?',
      answer: 'Fido',
    }]).expect(404);
  });

  test('GET response user does not exist', async () => {
    const response = await request(webapp).get('/securityquestions/testuser3').expect(404);

    return expect(JSON.parse(response.text).error).toBe('User does not exist');
  });

  test('GET response success', async () => {
    await request(webapp).get('/securityquestions/testuser2').expect(200);
  });

  test('DELETE testuser2', async () => {
    await request(webapp).delete('/deleteuser/testuser2');
  });

  test('create new testuser2', async () => {
    await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' });
  });

  test('GET response no security questions', async () => {
    await request(webapp).get('/securityquestions/testuser2').expect(405);
  });
});

// webapp.post(`/resetpassword/${userParam}`, wrapErrors(login.handlePostResetpasswordUser));
describe('/resetpassword/user endpoint test', () => {
  test('POST response invalid parameters', async () => {
    await request(webapp).post('/resetpassword/test').expect(400);
  });

  test('POST response user not found', async () => {
    await request(webapp).post('/resetpassword/testuser3').send({
      new_password: 'testpassword2',
      security_questions: [
        {
          question: 'What was the name of your first pet?',
          answer: 'Snowy',
        },
      ],
    }).expect(404);
  });

  test('POST response user does not have security questions', async () => {
    await request(webapp).post('/resetpassword/testuser2').send({
      new_password: 'testpassword2',
      security_questions: [
        {
          question: 'What was the name of your first pet?',
          answer: 'Snowy',
        },
      ],
    }).expect(405);
  });

  test('Add security questions to testuser2', async () => {
    await request(webapp).post('/securityquestions/testuser2').send([{
      question: 'What was the name of your first pet?',
      answer: 'Fido',
    }]).expect(201);
  });

  test('POST response incorrect answers', async () => {
    await request(webapp).post('/resetpassword/testuser2').send({
      new_password: 'testpassword2',
      security_questions: [
        {
          question: 'What was the name of your first pet?',
          answer: 'Snowy',
        },
      ],
    }).expect(403);
  });

  test('POST response reset', async () => {
    await request(webapp).post('/resetpassword/testuser2').send({
      new_password: 'testpassword2',
      security_questions: [
        {
          question: 'What was the name of your first pet?',
          answer: 'Fido',
        },
      ],
    }).expect(200);
  });

  test('DELETE testuser2', async () => {
    await request(webapp).delete('/deleteuser/testuser2');
  });

  test('create new testuser2', async () => {
    await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' });
  });
});

// Calendar

// webapp.get(`/calendar/event/list/${userParam}`, wrapErrors(calendar.handleGetCalendarEventList));
describe('/calendar/event/list/user endpoint test', () => {
  test('GET response invalid parameters', async () => {
    await request(webapp).get('/calendar/event/list/testuser3').expect(404);
  });

  test('GET response success', async () => {
    await request(webapp).get('/calendar/event/list/testuser2').expect(200);
  });
});

// webapp.post(`/calendar/event/create/${userParam}`,
// wrapErrors(calendar.handlePostCalendarEventCreate));
describe('/calendar/event/create/user endpoint test', () => {
  test('POST response no username', async () => {
    await request(webapp).post('/calendar/event/create/').send({
      name: 'TestEvent1',
      color: '',
    }).expect(404);
  });

  test('POST response invalid parameters', async () => {
    await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: '',
    }).expect(400);
  });

  test('POST response invalid color', async () => {
    await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: '102',
    }).expect(400);
  });

  test('POST response success', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      event_id: 0,
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    // console.log(JSON.parse(response.text).value.event_id);
    request(webapp).delete(`/calendar/event/${id}/testuser2`).expect(200);
    request(webapp).get(`/calendar/event/${id}/testuser2`).expect(404);
  });
});

// webapp.get(`/calendar/event/${eventIdParam}/${userParam}`,
// wrapErrors(calendar.handleGetCalendarEventEventID));
describe('/calendar/event/eventid/user endpoint test', () => {
  test('GET response success', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    request(webapp).get(`/calendar/event/${id}/testuser2`).expect(200);
    request(webapp).delete(`/calendar/event/${id}/testuser2`).expect(200);
    request(webapp).get(`/calendar/event/${id}/testuser2`).expect(404);
  });

  test('GET response event not found', async () => {
    request(webapp).get('/calendar/event/0/testuser2').expect(404);
  });
});

// webapp.put(`/calendar/event/${eventIdParam}/${userParam}`,
// wrapErrors(calendar.handlePutCalendarEventEventID));
// webapp.delete(`/calendar/event/${eventIdParam}/${userParam}`,
// wrapErrors(calendar.handleDeleteCalendarEventEventID));
describe('/calendar/event/eventid/user endpoint test', () => {
  test('PUT response success', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    request(webapp).put(`/calendar/event/${id}/testuser2`).send({
      name: 'TestEvent1',
      color: 'red',
    }).expect(200);
    request(webapp).delete(`/calendar/event/${id}/testuser2`).expect(200);
    request(webapp).get(`/calendar/event/${id}/testuser2`).expect(404);
  });

  test('PUT response missing valid parameters', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    request(webapp).put(`/calendar/event/${id}/testuser2`).send({
      name: '',
      color: 'red',
    }).expect(400);
    request(webapp).delete(`/calendar/event/${id}/testuser2`).expect(200);
    request(webapp).get(`/calendar/event/${id}/testuser2`).expect(404);
  });

  test('PUT response invalid color', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    request(webapp).put(`/calendar/event/${id}/testuser2`).send({
      name: 'TestEvent1',
      color: '102',
    }).expect(400);
    request(webapp).delete(`/calendar/event/${id}/testuser2`).expect(200);
    request(webapp).get(`/calendar/event/${id}/testuser2`).expect(404);
  });

  test('PUT response event not found', async () => {
    request(webapp).put('/calendar/event/0/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(404);
  });
});

// webapp.get(`/calendar/blob/list/:date/${userParam}`,
// wrapErrors(calendar.handleGetCalendarBlobList)); "2022-02-27T15:00:00Z"
describe('/calendar/blob/list/:date/user endpoint test', () => {
  test('GET response invalid date', async () => {
    await request(webapp).get('/calendar/blob/list/:20/testuser2').expect(400);
  });

  test('GET response invalid date', async () => {
    await request(webapp).get('/calendar/blob/list/:2022-05-10/testuser2').expect(200);
  });
});

// webapp.post(`/calendar/blob/create/${eventIdParam}/${userParam}`,
// wrapErrors(calendar.handlePostCalendarBlobCreate));
describe('/calendar/blob/create/eventid/user endpoint test', () => {
  test('POST response missing time', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    await request(webapp).post(`/calendar/blob/create/${id}/testuser2`).send({
      time: '',
    }).expect(400);
  });

  test('POST response invalid time', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    await request(webapp).post(`/calendar/blob/create/${id}/testuser2`).send({
      time: {
        start: 'abc',
        end: '123',
      },
    }).expect(400);
  });

  test('POST response blob create', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    await request(webapp).post(`/calendar/blob/create/${id}/testuser2`).send({
      time: {
        start: '2022-05-10T06:29:36.258Z',
        end: '2022-05-10T07:29:36.258Z',
      },
    }).expect(201);
  });
});

// webapp.get(`/calendar/blob/${blobIdParam}/${eventIdParam}/${userParam}`,
// wrapErrors(calendar.handleGetCalendarBlobBlobID));
describe('/calendar/blob/create/eventid/user endpoint test', () => {
  test('GET response blob not found', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const id = JSON.parse(response.text).event_id;
    await request(webapp).get(`/calendar/blob/${id}/testuser2`).expect(404);
  });

  test('GET response success', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const eventId = JSON.parse(response.text).event_id;

    const response2 = await request(webapp).post(`/calendar/blob/create/${eventId}/testuser2`).send({
      time: {
        start: '2022-05-10T06:29:36.258Z',
        end: '2022-05-10T07:29:36.258Z',
      },
    }).expect(201);

    const blobId = JSON.parse(response2.text).blob_id;
    await request(webapp).get(`/calendar/blob/${blobId}/${eventId}/testuser2`).expect(200);
  });

  test('DELETE testuser2', async () => {
    await request(webapp).delete('/deleteuser/testuser2');
  });

  test('create new testuser2', async () => {
    await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' });
  });
});

// webapp.put(`/calendar/blob/${blobIdParam}/${eventIdParam}/${userParam}`,
// wrapErrors(calendar.handlePutCalendarBlobBlobID));
describe('/calendar/blob/blobId/eventid/user endpoint test', () => {
  test('PUT response missing time', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const eventId = JSON.parse(response.text).event_id;

    const response2 = await request(webapp).post(`/calendar/blob/create/${eventId}/testuser2`).send({
      time: {
        start: '2022-05-10T06:29:36.258Z',
        end: '2022-05-10T07:29:36.258Z',
      },
    }).expect(201);

    const blobId = JSON.parse(response2.text).blob_id;
    await request(webapp).put(`/calendar/blob/${blobId}/${eventId}/testuser2`).expect(400);
  });

  test('PUT response invalid time', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const eventId = JSON.parse(response.text).event_id;

    const response2 = await request(webapp).post(`/calendar/blob/create/${eventId}/testuser2`).send({
      time: {
        start: '2022-05-10T06:29:36.258Z',
        end: '2022-05-10T07:29:36.258Z',
      },
    }).expect(201);

    const blobId = JSON.parse(response2.text).blob_id;
    await request(webapp).put(`/calendar/blob/${blobId}/${eventId}/testuser2`).send({
      time: {
        start: 'abc',
        end: '123',
      },
    }).expect(400);
  });

  test('PUT response blob not found', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const eventId = JSON.parse(response.text).event_id;

    await request(webapp).put(`/calendar/blob/${eventId}/testuser2`).send({
      time: {
        start: '2022-05-10T06:29:36.258Z',
        end: '2022-05-10T07:29:36.258Z',
      },
    }).expect(404);
  });

  test('PUT response success', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const eventId = JSON.parse(response.text).event_id;

    const response2 = await request(webapp).post(`/calendar/blob/create/${eventId}/testuser2`).send({
      time: {
        start: '2022-05-10T07:29:36.258Z',
        end: '2022-05-10T08:29:36.258Z',
      },
    }).expect(201);

    const blobId = JSON.parse(response2.text).blob_id;
    await request(webapp).put(`/calendar/blob/${blobId}/${eventId}/testuser2`).send({
      time: {
        start: '2022-05-10T06:29:36.258Z',
        end: '2022-05-10T07:29:36.258Z',
      },
    }).expect(200);
  });

  test('DELETE testuser2', async () => {
    await request(webapp).delete('/deleteuser/testuser2');
  });

  test('create new testuser2', async () => {
    await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' });
  });
});

// webapp.delete(`/calendar/blob/${blobIdParam}/${eventIdParam}/${userParam}`,
// wrapErrors(calendar.handleDeleteCalendarBlobBlobID));
describe('/calendar/blob/blobId/eventid/user endpoint test', () => {
  // blob not found
  test('DELETE response blob not found', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const eventId = JSON.parse(response.text).event_id;

    await request(webapp).delete(`/calendar/blob/${eventId}/testuser2`).expect(404);
  });

  // blob deleted
  test('DELETE response success', async () => {
    const response = await request(webapp).post('/calendar/event/create/testuser2').send({
      name: 'TestEvent1',
      color: 'blue',
    }).expect(201);

    const eventId = JSON.parse(response.text).event_id;

    const response2 = await request(webapp).post(`/calendar/blob/create/${eventId}/testuser2`).send({
      time: {
        start: '2022-05-10T07:29:36.258Z',
        end: '2022-05-10T08:29:36.258Z',
      },
    }).expect(201);

    const blobId = JSON.parse(response2.text).blob_id;
    await request(webapp).delete(`/calendar/blob/${blobId}/${eventId}/testuser2`).expect(200);
  });

  test('DELETE testuser2', async () => {
    await request(webapp).delete('/deleteuser/testuser2');
  });

  test('create new testuser2', async () => {
    await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' });
  });
});

// Wellness

// webapp.get(`/wellness/survey/${userParam}`, wrapErrors(wellness.handleGetWellnessSurvey));
describe('/wellness/survey/user endpoint test', () => {
  test('GET response user does not exist', async () => {
    await request(webapp).get('/wellness/survey/testuser3').expect(404);
  });

  test('GET response success', async () => {
    await request(webapp).get('/calendar/event/list/testuser2').expect(200);
  });
});

// webapp.post(`/wellness/survey/${userParam}`, wrapErrors(wellness.handlePostWellnessSurvey));
describe('/wellness/survey/user endpoint test', () => {
  // survey not found 404
  // success 200
  test('POST response user does not exist', async () => {
    await request(webapp).post('/wellness/survey/').expect(404);
  });

  test('POST response success', async () => {
    await request(webapp).post('/wellness/survey/testuser2').expect(200);
  });

  test('DELETE testuser2', async () => {
    await request(webapp).delete('/deleteuser/testuser2');
  });

  test('create new testuser2', async () => {
    await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' });
  });
});

// webapp.put(`/wellness/survey/${userParam}`, wrapErrors(wellness.handlePutWellnessSurvey));
// webapp.post(`/wellness/survey/${userParam}`, wrapErrors(wellness.handlePostWellnessSurvey));
describe('/wellness/survey/user endpoint test', () => {
  test('PUT response user does not exist', async () => {
    await request(webapp).put('/wellness/survey/').expect(404);
  });

  test('PUT response success', async () => {
    await request(webapp).put('/wellness/survey/testuser2').expect(200);
  });

  test('DELETE testuser2', async () => {
    await request(webapp).delete('/deleteuser/testuser2');
  });

  test('create new testuser2', async () => {
    await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' });
  });
});

// Tasks

// webapp.get(`/tasks/tasklist/${userParam}`, wrapErrors(tasks.handleGetTasksTasklist));
describe('/tasks/tasklist/user endpoint test', () => {
  test('GET response success', async () => {
    await request(webapp).get('/tasks/tasklist/testuser2').expect(200);
  });
});

// webapp.post(`/tasks/create/${userParam}`, wrapErrors(tasks.handlePostTasksCreate));
describe('/tasks/create/user endpoint test', () => {
  // missing parameters 400
  test('POST response success', async () => {
    await request(webapp).post('/tasks/create/testuser2').send({
      due_date: '2022-02-27T15:00:00Z',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(400);
  });

  // invalid parameter 400
  test('POST response success', async () => {
    await request(webapp).post('/tasks/create/testuser2').send({
      due_date: 'abc',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(400);
  });

  // success 201
  test('POST response success', async () => {
    await request(webapp).post('/tasks/create/testuser2').send({
      due_date: '2022-02-27T15:00:00Z',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(201);
  });
});

// webapp.get(`/tasks/${taskIdParam}/${userParam}`, wrapErrors(tasks.handleGetTasksTaskID));
describe('/tasks/taskId/user endpoint test', () => {
  // task not found 404
  test('GET response task not found', async () => {
    await request(webapp).get('/tasks/0/testuser2').expect(404);
  });

  // success 200
  test('GET response success', async () => {
    const response = await request(webapp).post('/tasks/create/testuser2').send({
      due_date: '2022-02-27T15:00:00Z',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(201);

    const taskId = JSON.parse(response.text).task_id;
    await request(webapp).get(`/tasks/${taskId}/testuser2`).expect(200);
  });
});

// webapp.put(`/tasks/${taskIdParam}/${userParam}`, wrapErrors(tasks.handlePutTasksTaskID));
describe('/tasks/taskId/user endpoint test', () => {
  // missing parameters 400
  test('PUT response missing parameters', async () => {
    const response = await request(webapp).post('/tasks/create/testuser2').send({
      due_date: '2022-02-27T15:00:00Z',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(201);

    const taskId = JSON.parse(response.text).task_id;
    await request(webapp).put(`/tasks/${taskId}/testuser2`).expect(400);
  });

  // invalid parameters 400
  test('PUT response invalid parameters', async () => {
    const response = await request(webapp).post('/tasks/create/testuser2').send({
      due_date: '2022-02-27T15:00:00Z',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(201);

    const taskId = JSON.parse(response.text).task_id;
    await request(webapp).put(`/tasks/${taskId}/testuser2`).send({
      due_date: 'abc',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(400);
  });

  // task not found 404
  test('PUT response task not found', async () => {
    await request(webapp).put('/tasks/testuser2').send({
      due_date: '2022-02-27T15:00:00Z',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(404);
  });

  // task found 200
  test('PUT response success', async () => {
    const response = await request(webapp).post('/tasks/create/testuser2').send({
      due_date: '2022-02-27T15:00:00Z',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(201);

    const taskId = JSON.parse(response.text).task_id;
    await request(webapp).put(`/tasks/${taskId}/testuser2`).send({
      due_date: '2022-03-27T15:00:00Z',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(200);
  });
});

// webapp.delete(`/tasks/${taskIdParam}/${userParam}`, wrapErrors(tasks.handleDeleteTasksTaskID));
describe('/tasks/taskId/user endpoint test', () => {
  // task not found 404
  test('DELETE response task not found', async () => {
    await request(webapp).delete('/tasks/testuser2').expect(404);
  });

  // success 200
  test('DELETE response success', async () => {
    const response = await request(webapp).post('/tasks/create/testuser2').send({
      due_date: '2022-02-27T15:00:00Z',
      title: 'CIS 350 Project Sprint 1',
      progress: 90,
      notes: 'Finish SwaggerHub documentation for Tasks',
    }).expect(201);

    const taskId = JSON.parse(response.text).task_id;
    await request(webapp).delete(`/tasks/${taskId}/testuser2`).expect(200);
    await request(webapp).get(`/tasks/${taskId}/testuser2`).expect(404);
  });

  test('DELETE testuser2', async () => {
    await request(webapp).delete('/deleteuser/testuser2');
  });

  test('create new testuser2', async () => {
    await request(webapp).post('/register').send({ username: 'testuser2', password: 'testpassword2' });
  });
});

// Messaging

// webapp.post(`/messaging/user/${userParam}`, wrapErrors(messaging.handlePostMessagingUser));
describe('/messaging/user/user endpoint test', () => {
  // user already exists 200
  test('POST response user already exists', async () => {
    await request(webapp).post('/messaging/user/testuser2').expect(200);
  });

  // added new user 201 & user sucessfully removed
  test('POST response create new user', async () => {
    await request(webapp).post('/messaging/user/testuser4').expect(201);
    await request(webapp).delete('/messaging/user/testuser4').expect(200);
  });
});

// webapp.delete(`/messaging/user/${userParam}`, wrapErrors(messaging.handleDeleteMessagingUser));
describe('/messaging/user/user endpoint test', () => {
  // Inexistent User 404
  test('DELETE response inexistent user', async () => {
    await request(webapp).delete('/messaging/user/testuser3').expect(404);
  });
});

// webapp.get(`/messaging/user/exists/${userParam}`,
// wrapErrors(messaging.handleGetMessagingUserExists));
describe('/messaging/user/exists/user endpoint test', () => {
  // user not found
  test('GET response user not found', async () => {
    const response = await request(webapp).get('/messaging/user/exists/testuser3').expect(200);

    return expect(JSON.parse(response.text).message).toBe('User not found');
  });

  // user found
  test('GET response user found', async () => {
    const response = await request(webapp).get('/messaging/user/exists/testuser2').expect(200);

    return expect(JSON.parse(response.text).message).toBe('User found');
  });
});

// webapp.get(`/messaging/friends/exists/${userParam}/${friendParam}`,
// wrapErrors(messaging.handleGetMessagingFriendExists));
describe('/messaging/friends/exists/user1/user2 endpoint test', () => {
  // inexistent user 404
  // friend not found 200 message: 'Friend not found'
  // friend found 200 message: 'Friend found'

  // inexistent user 404
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/friends/exists/testuser1/testuser3').expect(404);
  });

  // friend not found 200 message: 'Friend not found'
  test('GET response friend not found', async () => {
    const response = await request(webapp).get('/messaging/friends/exists/testuser2/testuser5').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Friend not found');
  });

  // friend found 200 message: 'Friend found'
  test('GET response friend found', async () => {
    const response = await request(webapp).get('/messaging/friends/exists/testuser5/testuser6').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Friend found');
  });
});

// webapp.get(`/messaging/pending/exists/${userParam}/${friendParam}`,
// wrapErrors(messaging.handleGetMessagingPendingExists));
describe('/messaging/pending/exists/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/pending/exists/testuser1/testuser3').expect(404);
  });

  // pending friend not found 200 message: 'Pending friend not found'
  test('GET response pending friend not found', async () => {
    const response = await request(webapp).get('/messaging/pending/exists/testuser2/testuser5').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Pending friend not found');
  });

  // pending friend found 200 message: 'Pending friend found'
  test('GET response pending friend found', async () => {
    const response = await request(webapp).get('/messaging/pending/exists/testuser7/testuser5').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Pending friend found');
  });
});

// webapp.get(`/messaging/requested/exists/${userParam}/${friendParam}`,
// wrapErrors(messaging.handleGetMessagingRequestedExists));
describe('/messaging/requested/exists/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/requested/exists/testuser1/testuser3').expect(404);
  });

  // requested friend not found 200 message: 'Requested friend not found'
  test('GET response requested friend not found', async () => {
    const response = await request(webapp).get('/messaging/requested/exists/testuser2/testuser5').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Requested friend not found');
  });

  // requested friend found 200 message: 'Requested friend found'
  test('GET response requested friend found', async () => {
    const response = await request(webapp).get('/messaging/requested/exists/testuser5/testuser7').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Requested friend found');
  });
});

// webapp.get(`/messaging/friends/first/${userParam}`,
// wrapErrors(messaging.handleGetMessagingFriendFirst));
describe('/messaging/friends/first/user endpoint test', () => {
  // inexistent user 400
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/friends/first/testuser1').expect(400);
  });

  // user has no friends 404
  test('GET response user has no friends', async () => {
    await request(webapp).get('/messaging/friends/first/testuser7').expect(404);
  });

  // success 200
  test('GET response success', async () => {
    const response = await request(webapp).get('/messaging/friends/first/testuser5').expect(200);

    return expect(JSON.parse(response.text).friend).toBe('testuser6');
  });
});

// webapp.get(`/messaging/pending/first/${userParam}`,
// wrapErrors(messaging.handleGetMessagingPendingFirst));
describe('/messaging/pending/first/user endpoint test', () => {
  // inexistent user 400
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/pending/first/testuser1').expect(400);
  });

  // user has no pending 404
  test('GET response user has no pending friends', async () => {
    await request(webapp).get('/messaging/pending/first/testuser6').expect(404);
  });

  // success 200
  test('GET response success', async () => {
    const response = await request(webapp).get('/messaging/pending/first/testuser7').expect(200);

    return expect(JSON.parse(response.text).friend).toBe('testuser5');
  });
});

// webapp.get(`/messaging/requested/first/${userParam}`,
// wrapErrors(messaging.handleGetMessagingRequestedFirst));
describe('/messaging/pending/first/user endpoint test', () => {
  // inexistent user 400
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/requested/first/testuser1').expect(400);
  });

  // user has no pending 404
  test('GET response user has no pending friends', async () => {
    await request(webapp).get('/messaging/requested/first/testuser6').expect(404);
  });

  // success 200
  test('GET response success', async () => {
    const response = await request(webapp).get('/messaging/requested/first/testuser5').expect(200);

    return expect(JSON.parse(response.text).friend).toBe('testuser7');
  });
});

// webapp.get(`/messaging/friends/list/${userParam}`,
// wrapErrors(messaging.handleGetMessagingFriendList));
describe('/messaging/friends/list/user endpoint test', () => {
  // inexistent user 400
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/friends/list/testuser1').expect(400);
  });

  // success 200
  test('GET response success', async () => {
    await request(webapp).get('/messaging/friends/list/testuser6').expect(200);
  });
});

// webapp.get(`/messaging/pending/list/${userParam}`,
// wrapErrors(messaging.handleGetMessagingPendingList));
describe('/messaging/pending/list/user endpoint test', () => {
  // inexistent user 400
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/pending/list/testuser1').expect(400);
  });

  // success 200
  test('GET response success', async () => {
    await request(webapp).get('/messaging/pending/list/testuser5').expect(200);
  });
});

// webapp.get(`/messaging/requested/list/${userParam}`,
// wrapErrors(messaging.handleGetMessagingRequestedList));
describe('/messaging/requested/list/user endpoint test', () => {
  // inexistent user 400
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/requested/list/testuser1').expect(400);
  });

  // success 200
  test('GET response success', async () => {
    await request(webapp).get('/messaging/requested/list/testuser7').expect(200);
  });
});

// webapp.put(`/messaging/friends/${userParam}/${friendParam}`,
// wrapErrors(messaging.handlePutMessagingFriend));
describe('/messaging/friends/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('PUT response inexistent user', async () => {
    await request(webapp).put('/messaging/friends/testuser1/testuser3').expect(404);
  });

  // user was already a friend 200
  test('PUT response user was already a friend', async () => {
    await request(webapp).put('/messaging/friends/testuser6/testuser5').expect(200);
  });

  // added friend 201
  test('PUT response add friend', async () => {
    await request(webapp).put('/messaging/friends/testuser6/testuser8').expect(201);
    await request(webapp).delete('/messaging/friends/testuser6/testuser8').expect(200);
  });
});

// webapp.put(`/messaging/pending/${userParam}/${friendParam}`,
// wrapErrors(messaging.handlePutMessagingPending));
describe('/messaging/pending/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('PUT response inexistent user', async () => {
    await request(webapp).put('/messaging/pending/testuser1/testuser3').expect(404);
  });

  // user was already a friend 200
  test('PUT response user was already pending', async () => {
    await request(webapp).put('/messaging/pending/testuser7/testuser5').expect(200);
  });

  // added friend 201
  test('PUT response add pending friend', async () => {
    await request(webapp).put('/messaging/pending/testuser6/testuser8').expect(201);
    await request(webapp).delete('/messaging/pending/testuser6/testuser8').expect(200);
  });
});

// webapp.put(`/messaging/requested/${userParam}/${friendParam}`,
// wrapErrors(messaging.handlePutMessagingRequested));
describe('/messaging/requested/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('PUT response inexistent user', async () => {
    await request(webapp).put('/messaging/requested/testuser1/testuser3').expect(404);
  });

  // user was already a friend 200
  test('PUT response user was already requested', async () => {
    await request(webapp).put('/messaging/requested/testuser5/testuser7').expect(200);
  });

  // added friend 201
  test('PUT response add requested friend', async () => {
    await request(webapp).put('/messaging/requested/testuser6/testuser8').expect(201);
    await request(webapp).delete('/messaging/requested/testuser6/testuser8').expect(200);
  });
});

// webapp.delete(`/messaging/friends/${userParam}/${friendParam}`,
// wrapErrors(messaging.handleDeleteMessagingFriend));
describe('/messaging/friends/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('DELETE response inexistent user', async () => {
    await request(webapp).delete('/messaging/friends/testuser1/testuser3').expect(404);
  });

  // friend not found 404
  test('DELETE response friend not found', async () => {
    await request(webapp).delete('/messaging/friends/testuser7/testuser5').expect(404);
  });
});

// webapp.delete(`/messaging/pending/${userParam}/${friendParam}`,
// wrapErrors(messaging.handleDeleteMessagingPending));
describe('/messaging/pending/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('DELETE response inexistent user', async () => {
    await request(webapp).delete('/messaging/pending/testuser1/testuser3').expect(404);
  });

  // friend not found 404
  test('DELETE response pending friend not found', async () => {
    await request(webapp).delete('/messaging/pending/testuser6/testuser8').expect(404);
  });
});

// webapp.delete(`/messaging/requested/${userParam}/${friendParam}`,
// wrapErrors(messaging.handleDeleteMessagingRequested));
describe('/messaging/requested/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('DELETE response inexistent user', async () => {
    await request(webapp).delete('/messaging/requested/testuser1/testuser3').expect(404);
  });

  // friend not found 404
  test('DELETE response requested friend not found', async () => {
    await request(webapp).delete('/messaging/requested/testuser6/testuser8').expect(404);
  });
});

// webapp.get(`/messaging/messagecount/${userParam}`,
// wrapErrors(messaging.handleGetMessagingCount));
describe('/messaging/messagecount/user endpoint test', () => {
  // inexistent user 404
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/messagecount/testuser1').expect(404);
  });

  // success 200 message: 'Retrieved message count'
  test('DEGETLETE response success', async () => {
    const response = await request(webapp).get('/messaging/messagecount/testuser2').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Retrieved message count');
  });
});

// webapp.get(`/messaging/messages/${userParam}/${friendParam}`,
// wrapErrors(messaging.handleGetMessagingMessages));
describe('/messaging/messages/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('GET response inexistent user', async () => {
    await request(webapp).get('/messaging/messages/testuser1/testuser3').expect(404);
  });

  // users are not friends 403
  test('GET response users are not friends', async () => {
    await request(webapp).get('/messaging/messages/testuser6/testuser8').expect(403);
  });

  // retrieved message log 200 message: 'Retrieved message log'
  test('GET response success', async () => {
    const response = await request(webapp).get('/messaging/messages/testuser6/testuser5').expect(200);

    return expect(JSON.parse(response.text).message).toBe('Retrieved message log');
  });
});

// webapp.put(`/messaging/messages/${userParam}/${friendParam}`,
// wrapErrors(messaging.handlePutMessagingMessage));
describe('/messaging/messages/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('PUT response inexistent user', async () => {
    await request(webapp).put('/messaging/messages/testuser1/testuser3').expect(404);
  });

  // users are not friends 403
  test('PUT response users are not friends', async () => {
    await request(webapp).put('/messaging/messages/testuser6/testuser8').send({
      message: 'hello',
      date: '2022-05-10',
      time: '07:29:36.258Z',
    }).expect(403);
  });

  // success 200 message: 'Message sent'
  test('PUT response success', async () => {
    const response = await request(webapp).put('/messaging/messages/testuser6/testuser5').send({
      message: 'hello',
      date: '2022-05-10',
      time: '07:29:36.258Z',
    }).expect(200);

    return expect(JSON.parse(response.text).message).toBe('Message sent');
  });
});

// webapp.delete(`/messaging/messages/${userParam}/${friendParam}`,
// wrapErrors(messaging.handleDeleteMessagingMessages));
describe('/messaging/messages/user1/user2 endpoint test', () => {
  // inexistent user 404
  test('DELETE response inexistent user', async () => {
    await request(webapp).delete('/messaging/messages/testuser1/testuser3').expect(404);
  });

  // success 200
  test('DELETE response success', async () => {
    await request(webapp).delete('/messaging/messages/testuser6/testuser5').expect(200);
  });
});
