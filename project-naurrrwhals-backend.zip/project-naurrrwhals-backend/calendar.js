const colors = require('is-valid-css-color');
const DB = require('./database');
const dt = require('./dateTimeFuncs');

const ignoreID = { projection: { _id: 0 } };

async function calendarCreateUser(username) {
  await DB.eventsDB.createCollection(username);
  await DB.blobsDB.createCollection(username);
}

async function calendarDeleteUser(username) {
  await DB.eventsDB.collection(username).drop();
  await DB.blobsDB.collection(username).drop();
}

function validColor(color) {
  return (
    colors.isValidColorName(color)
    || colors.isValidHSL(color)
    || colors.isValidRGB(color)
  );
}

function validTimeRange(timeRange) {
  if (!timeRange.start || !timeRange.end) {
    return false;
  }
  if (!dt.validDateTime(timeRange.start) || !dt.validDateTime(!timeRange.end)) {
    return false;
  }

  return true;
}

async function handleGetCalendarEventList(req, resp) {
  const username = req?.params?.user;
  // if (!username) {
  //   return resp.status(400).json('Missing parameters');
  // }

  const userObj = await DB.usersCollection.findOne(
    { username: username },
    { projection: { _id: 0 } },
  );
  if (!userObj) {
    return resp.status(404).send('User not found');
  }

  const collection = DB.eventsDB.collection(username);
  const found = await collection.find({}, ignoreID).toArray();
  return resp.status(200).json(found);
}

async function handlePostCalendarEventCreate(req, resp) {
  const username = req?.params?.user;
  const name = req?.body?.name;
  const color = req?.body?.color;
  if (!username || !name || !color) {
    return resp.status(400).json('Missing parameters');
  }
  if (!validColor(color)) {
    return resp.status(400).json('Invalid parameters');
  }

  const collection = DB.eventsDB.collection(username);
  const { insertedId } = await collection.insertOne({ name, color });

  const query = { _id: insertedId };
  const update = { $set: { event_id: insertedId.toString() } };
  const options = {
    returnDocument: 'after',
    upsert: true,
    projection: { _id: 0 },
  };
  let eventObj = await collection.findOneAndUpdate(query, update, options);
  if (eventObj.value) {
    eventObj = eventObj.value;
  }
  if (!eventObj) {
    return resp.status(404).json('Event not found');
  }
  return resp.status(201).json(eventObj);
}

async function handleGetCalendarEventEventID(req, resp) {
  const eventID = req?.params?.event_id;
  const username = req?.params?.user;
  // if (!username || !eventID) {
  //   return resp.status(400).json('Missing parameters');
  // }
  const collection = DB.eventsDB.collection(username);
  const eventObj = await collection.findOne({ event_id: eventID }, ignoreID);
  if (!eventObj) {
    return resp.status(404).json('Event not found');
  }
  return resp.status(200).json(eventObj);
}

async function handlePutCalendarEventEventID(req, resp) {
  const eventID = req?.params?.event_id;
  const username = req?.params?.user;
  const name = req?.body?.name;
  const color = req?.body?.color;
  if (!username || !eventID || !name || !color) {
    return resp.status(400).json('Missing parameters');
  }
  if (!validColor(color)) {
    return resp.status(400).json('Invalid parameters');
  }

  const query = { _id: eventID };
  const replacement = {
    event_id: eventID,
    color: color,
    name: name,
  };
  const options = {
    returnNewDocument: true,
    projection: { _id: 0 },
  };
  const collection = DB.eventsDB.collection(username);
  const eventObj = await collection.findOneAndReplace(query, replacement, options);
  if (!eventObj) {
    return resp.status(404).json('Event not found');
  }
  return resp.status(200).json(eventObj);
}

async function handleDeleteCalendarEventEventID(req, resp) {
  const eventID = req?.params?.event_id;
  const username = req?.params?.user;
  // if (!username || !eventID) {
  //   return resp.status(400).json('Missing parameters');
  // }
  const eventsCollection = DB.eventsDB.collection(username);
  const blobsCollection = DB.blobsDB.collection(username);
  const deleteResult = await eventsCollection.deleteOne({ event_id: eventID });
  await blobsCollection.deleteMany({ event_id: eventID });
  if (!deleteResult?.deletedCount) {
    return resp.status(404).json('Event not found');
  }
  return resp.status(200).json('Deleted');
}

/* Blob structure stored:

{
  "blob_id": 0,
  "event_id": 0,
  "time": {
    "start": "2022-05-04T18:46:39.120Z",
    "end": "2022-05-04T18:46:39.120Z"
  }
}

*/

// https://stackoverflow.com/a/14696535/14013278
function groupBy(xs, prop) {
  const grouped = {};
  for (let i = 0; i < xs.length; i += 1) {
    const p = xs[i][prop];
    if (!grouped[p]) {
      grouped[p] = [];
    }
    grouped[p].push(xs[i]);
  }
  return grouped;
}

async function handleGetCalendarBlobList(req, resp) {
  const username = req?.params?.user;
  const dateAndMaybeTime = req?.params?.date;

  // if (!username || !dateAndMaybeTime) {
  //   return resp.status(400).json('Missing parameters');
  // }
  const date = dt.extractDateString(dateAndMaybeTime);

  if (!dt.validDateTime(date)) {
    return resp.status(400).json('Invalid parameters');
  }

  const blobsCollection = DB.blobsDB.collection(username);
  const eventsCollection = DB.eventsDB.collection(username);

  const query = { 'time.start': { $regex: `^${date}` } };
  const found = await blobsCollection.find(query, ignoreID).toArray();
  const grouped = groupBy(found, 'event_id');

  const eventIDs = Object.keys(grouped);
  for (let i = 0; i < eventIDs.length; i += 1) {
    const eventID = eventIDs[i];
    // eslint-disable-next-line no-await-in-loop
    const eventObj = await eventsCollection.findOne({ event_id: eventID }, ignoreID);
    if (!eventObj) {
      throw new Error('Event not found');
    }
    for (let j = 0; j < grouped[eventID].length; j += 1) {
      const blobObj = grouped[eventID][j];
      grouped[eventID][j] = {
        blob_id: blobObj.blob_id,
        time: blobObj.time,
        event: eventObj,
      };
    }
  }

  const rtnArr = Object.values(grouped).flat();

  // const rtnArr = Object.entries(grouped).map(([eventID, blobObjs]) => {
  //   const eventObj = await eventsCollection.findOne({ event_id: eventID }, ignoreID);
  //   if (!eventObj) {
  //     throw new Error('Event not found');
  //   }
  //   const mapped = blobObjs.map(((blobObj) => (
  //     {
  //       blob_id: blobObj.blob_id,
  //       time: blobObj.time,
  //       event: eventObj,
  //     }
  //   )));
  //   return mapped;
  // }).flat();

  // console.log(rtnArr);

  return resp.status(200).json(rtnArr);
}

async function handlePostCalendarBlobCreate(req, resp) {
  const username = req?.params?.user;
  const eventID = req?.params?.event_id;
  const time = req?.body?.time;

  if (!username || !eventID || !time) {
    return resp.status(400).json('Missing parameters');
  }
  if (!validTimeRange(time)) {
    return resp.status(400).json('Invalid parameters');
  }

  const blobsCollection = DB.blobsDB.collection(username);
  const eventsCollection = DB.eventsDB.collection(username);
  const { insertedId } = await blobsCollection.insertOne({ event_id: eventID, time });
  // console.log(insertedId);
  const query = { _id: insertedId };
  const update = { $set: { blob_id: insertedId.toString() } };
  const options = {
    returnDocument: 'after',
    upsert: true,
    projection: { _id: 0 },
  };
  let blobObj = await blobsCollection.findOneAndUpdate(query, update, options);
  if (blobObj.value) {
    blobObj = blobObj.value;
  }
  // console.log(JSON.stringify(blobObj));
  if (!blobObj?.blob_id) {
    return resp.status(404).json('Blob not found');
  }

  const eventObj = eventsCollection.findOne({ event_id: blobObj.event_id }, ignoreID);

  const rtnObj = {
    blob_id: blobObj.blob_id,
    time: blobObj.time,
    event: eventObj,
  };

  return resp.status(201).json(rtnObj);
}

async function handleGetCalendarBlobBlobID(req, resp) {
  const username = req?.params?.user;
  const eventID = req?.params?.event_id;
  const blobID = req?.params?.blob_id;

  // if (!username || !eventID || !blobID) {
  //   return resp.status(400).json('Missing parameters');
  // }

  const blobsCollection = DB.blobsDB.collection(username);
  const eventsCollection = DB.eventsDB.collection(username);

  const blobObj = blobsCollection.findOne({ event_id: eventID, blob_id: blobID }, ignoreID);
  const eventObj = eventsCollection.findOne({ event_id: eventID }, ignoreID);
  if (!eventObj || !blobObj) {
    return resp.status(404).json('Event or blob not found');
  }
  const rtnObj = {
    blob_id: blobObj.blob_id,
    time: blobObj.time,
    event: eventObj,
  };
  return resp.status(200).json(rtnObj);
}

async function handleDeleteCalendarBlobBlobID(req, resp) {
  const username = req?.params?.user;
  const eventID = req?.params?.event_id;
  const blobID = req?.params?.blob_id;

  // if (!username || !eventID || !blobID) {
  //   return resp.status(400).json('Missing parameters');
  // }

  const blobsCollection = DB.blobsDB.collection(username);
  const deleteResult = await blobsCollection.deleteOne({ event_id: eventID, blob_id: blobID });
  if (!deleteResult?.deletedCount) {
    return resp.status(404).json('Blob not found');
  }
  return resp.status(200).json('Deleted');
}

async function handlePutCalendarBlobBlobID(req, resp) {
  const username = req?.params?.user;
  const eventID = req?.params?.event_id;
  const blobID = req?.params?.blob_id;
  const time = req?.body?.time;

  if (!username || !eventID || !blobID || !time) {
    return resp.status(400).json('Missing parameters');
  }
  if (!validTimeRange(time)) {
    return resp.status(400).json('Invalid parameters');
  }

  const blobsCollection = DB.blobsDB.collection(username);
  const eventsCollection = DB.eventsDB.collection(username);

  const query = {
    event_id: eventID,
    blob_id: blobID,
  };
  const update = { $set: { time: time } };
  const options = {
    returnNewDocument: true,
    projection: { _id: 0 },
  };
  const blobObj = await blobsCollection.findOneAndUpdate(query, update, options);
  const eventObj = eventsCollection.findOne({ event_id: eventID }, ignoreID);
  if (!eventObj || !blobObj) {
    return resp.status(404).json('Event or blob not found');
  }
  const rtnObj = {
    blob_id: blobObj.blob_id,
    time: blobObj.time,
    event: eventObj,
  };
  return resp.status(200).json(rtnObj);
}

module.exports = {
  calendarCreateUser,
  calendarDeleteUser,
  handleGetCalendarEventList,
  handlePostCalendarEventCreate,
  handleGetCalendarEventEventID,
  handlePutCalendarEventEventID,
  handleDeleteCalendarEventEventID,
  handleGetCalendarBlobList,
  handlePostCalendarBlobCreate,
  handleGetCalendarBlobBlobID,
  handleDeleteCalendarBlobBlobID,
  handlePutCalendarBlobBlobID,
};
