const express = require('express');
const cors = require('cors');
const path = require('path');
const login = require('./login');
const calendar = require('./calendar');
const messaging = require('./messaging');
const wellness = require('./wellness');
const tasks = require('./tasks');
const DB = require('./database');

// Create our express app
const webapp = express();

// Configure the app to handle JSON and parse the request body
webapp.use(express.json());
webapp.use(express.urlencoded({
  extended: true,
}));

// Fix CORS issue
webapp.use(cors());
webapp.options('*', cors());

function wrapErrors(func) {
  return (async (req, resp) => {
    try {
      // console.log(`\nRecived request: ${req.method} ${req.originalUrl}`);
      // console.log(`Body: ${JSON.stringify(req.body)}`);
      return func(req, resp);
    } catch (err) {
      console.log('\nError caught by wrapErrors:');
      console.log(err);
      return resp.status(500).json('An unknown error occured');
    }
  });
}

// === Declare Endpoints ===

webapp.use(express.static(path.join(__dirname, './client/naur_app/build')));

webapp.get('/', (_req, resp) => {
  resp.sendFile(path.join(__dirname, './client/naur_app/build/index.html'));
});

// Login and user management
const userParam = ':user([A-Za-z_][A-Za-z0-9_]{2,})';

webapp.post('/login', wrapErrors(login.handlePostLogin));
webapp.post('/register', wrapErrors(login.handlePostRegister));
webapp.delete(`/deleteuser/${userParam}`, wrapErrors(login.handleDeleteDeleteuser));
webapp.post(`/securityquestions/${userParam}`, wrapErrors(login.handlePostSecurityQuestionsUser));
webapp.get(`/securityquestions/${userParam}`, wrapErrors(login.handleGetSecurityQuestionsUser));
webapp.post(`/resetpassword/${userParam}`, wrapErrors(login.handlePostResetpasswordUser));

// Calendar
const eventIdParam = ':event_id([0-9a-fA-F]+)';
const blobIdParam = ':blob_id([0-9a-fA-F]+)';

webapp.get(`/calendar/event/list/${userParam}`, wrapErrors(calendar.handleGetCalendarEventList));
webapp.post(`/calendar/event/create/${userParam}`, wrapErrors(calendar.handlePostCalendarEventCreate));
webapp.get(`/calendar/event/${eventIdParam}/${userParam}`, wrapErrors(calendar.handleGetCalendarEventEventID));
webapp.put(`/calendar/event/${eventIdParam}/${userParam}`, wrapErrors(calendar.handlePutCalendarEventEventID));
webapp.delete(`/calendar/event/${eventIdParam}/${userParam}`, wrapErrors(calendar.handleDeleteCalendarEventEventID));

webapp.get(`/calendar/blob/list/:date/${userParam}`, wrapErrors(calendar.handleGetCalendarBlobList));
webapp.post(`/calendar/blob/create/${eventIdParam}/${userParam}`, wrapErrors(calendar.handlePostCalendarBlobCreate));
webapp.get(`/calendar/blob/${blobIdParam}/${eventIdParam}/${userParam}`, wrapErrors(calendar.handleGetCalendarBlobBlobID));
webapp.put(`/calendar/blob/${blobIdParam}/${eventIdParam}/${userParam}`, wrapErrors(calendar.handlePutCalendarBlobBlobID));
webapp.delete(`/calendar/blob/${blobIdParam}/${eventIdParam}/${userParam}`, wrapErrors(calendar.handleDeleteCalendarBlobBlobID));

// Wellness

webapp.get(`/wellness/survey/${userParam}`, wrapErrors(wellness.handleGetWellnessSurvey));
webapp.post(`/wellness/survey/${userParam}`, wrapErrors(wellness.handlePostWellnessSurvey));
webapp.put(`/wellness/survey/${userParam}`, wrapErrors(wellness.handlePutWellnessSurvey));

// Tasks
const taskIdParam = ':task_id([0-9a-fA-F]+)';

webapp.get(`/tasks/tasklist/${userParam}`, wrapErrors(tasks.handleGetTasksTasklist));
webapp.post(`/tasks/create/${userParam}`, wrapErrors(tasks.handlePostTasksCreate));
webapp.get(`/tasks/${taskIdParam}/${userParam}`, wrapErrors(tasks.handleGetTasksTaskID));
webapp.put(`/tasks/${taskIdParam}/${userParam}`, wrapErrors(tasks.handlePutTasksTaskID));
webapp.delete(`/tasks/${taskIdParam}/${userParam}`, wrapErrors(tasks.handleDeleteTasksTaskID));

// Messaging
const friendParam = ':friend([A-Za-z_][A-Za-z0-9_]{2,})';

webapp.post(`/messaging/user/${userParam}`, wrapErrors(messaging.handlePostMessagingUser));
webapp.delete(`/messaging/user/${userParam}`, wrapErrors(messaging.handleDeleteMessagingUser));
webapp.get(`/messaging/user/exists/${userParam}`, wrapErrors(messaging.handleGetMessagingUserExists));
webapp.get(`/messaging/friends/exists/${userParam}/${friendParam}`, wrapErrors(messaging.handleGetMessagingFriendExists));
webapp.get(`/messaging/pending/exists/${userParam}/${friendParam}`, wrapErrors(messaging.handleGetMessagingPendingExists));
webapp.get(`/messaging/requested/exists/${userParam}/${friendParam}`, wrapErrors(messaging.handleGetMessagingRequestedExists));
webapp.get(`/messaging/friends/first/${userParam}`, wrapErrors(messaging.handleGetMessagingFriendFirst));
webapp.get(`/messaging/pending/first/${userParam}`, wrapErrors(messaging.handleGetMessagingPendingFirst));
webapp.get(`/messaging/requested/first/${userParam}`, wrapErrors(messaging.handleGetMessagingRequestedFirst));
webapp.get(`/messaging/friends/list/${userParam}`, wrapErrors(messaging.handleGetMessagingFriendList));
webapp.get(`/messaging/pending/list/${userParam}`, wrapErrors(messaging.handleGetMessagingPendingList));
webapp.get(`/messaging/requested/list/${userParam}`, wrapErrors(messaging.handleGetMessagingRequestedList));
webapp.put(`/messaging/friends/${userParam}/${friendParam}`, wrapErrors(messaging.handlePutMessagingFriend));
webapp.put(`/messaging/pending/${userParam}/${friendParam}`, wrapErrors(messaging.handlePutMessagingPending));
webapp.put(`/messaging/requested/${userParam}/${friendParam}`, wrapErrors(messaging.handlePutMessagingRequested));
webapp.delete(`/messaging/friends/${userParam}/${friendParam}`, wrapErrors(messaging.handleDeleteMessagingFriend));
webapp.delete(`/messaging/pending/${userParam}/${friendParam}`, wrapErrors(messaging.handleDeleteMessagingPending));
webapp.delete(`/messaging/requested/${userParam}/${friendParam}`, wrapErrors(messaging.handleDeleteMessagingRequested));
webapp.get(`/messaging/messagecount/${userParam}`, wrapErrors(messaging.handleGetMessagingCount));
webapp.get(`/messaging/messages/${userParam}/${friendParam}`, wrapErrors(messaging.handleGetMessagingMessages));
webapp.put(`/messaging/messages/${userParam}/${friendParam}`, wrapErrors(messaging.handlePutMessagingMessage));
webapp.delete(`/messaging/messages/${userParam}/${friendParam}`, wrapErrors(messaging.handleDeleteMessagingMessages));

// Default route

webapp.all('*', (_req, resp) => (resp.status(404).json('Invalid URI or method')));

// === End Declare Endpoints ===

// Declare the port
const port = process?.env?.PORT || 80;

// Start the app
(async () => {
  await DB.connectToDatabases();
  webapp.listen(port, async () => {
    console.log(`NaurServer listening on port ${port}`);
  });
})();

module.exports = webapp; // export for testing
