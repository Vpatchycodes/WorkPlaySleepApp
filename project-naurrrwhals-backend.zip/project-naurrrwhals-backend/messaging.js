// The database you will be using is `DB.messagingDB`

// Use this to access the databases
const DB = require('./database');

async function isPreexistingUser(username) {
  const preexistingUser = await DB.messagingDB.collection('Users').findOne({ username: username });
  if (preexistingUser) {
    return true;
  }
  return false;
}

// GET /messaging/user/exists/{user}
async function handleGetMessagingUserExists(req, resp) {
  const username = req?.params?.user;
  const result = await isPreexistingUser(username);
  if (!result) {
    return resp.status(200).json({ message: 'User not found', result: false });
  }
  return resp.status(200).json({ message: 'User found', result: true });
}

async function messagingCreateUser(username) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (isPreexisting) {
    return undefined;
  }
  // add player to the list
  const friendList = [];
  const pendingList = [];
  const requestList = [];
  const user = {
    username: username,
    friends: friendList,
    pending: pendingList,
    requested: requestList,
    message_count: 0,
  };
  const result = await DB.messagingDB.collection('Users').insertOne(user);
  console.log(`Created new user with username: ${username}`);
  return result;
}

// POST /messaging/users/{user}
async function handlePostMessagingUser(req, resp) {
  const username = req?.params?.user;
  try {
    const result = await messagingCreateUser(username);
    if (!result) {
      return resp.status(200).json('User already existed');
    }
    return resp.status(201).json('Added new user');
  } catch (error) {
    return resp.status(400).json('Undefined username');
  }
}

async function messagingDeleteUser(username) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    return false;
  }
  await DB.messagingDB.collection('Users').deleteMany({ username: username });
  // console.log(`Removed user with username: ${username}`);
  return true;
}

// DELETE /messaging/users/{user}
async function handleDeleteMessagingUser(req, resp) {
  const username = req?.params?.user;
  try {
    const result = await messagingDeleteUser(username);
    if (!result) {
      return resp.status(404).json('Inexistant user');
    }
    return resp.status(200).json('User successfully removed');
  } catch (error) {
    return resp.status(400).json('Undefined username');
  }
}

async function getFriendList(username) {
  const user = await DB.messagingDB.collection('Users').findOne({ username: username });
  if (!user) {
    return undefined;
  }
  return user.friends;
}

async function getPendingList(username) {
  const user = await DB.messagingDB.collection('Users').findOne({ username: username });
  if (!user) {
    return undefined;
  }
  return user.pending;
}

async function getRequestedList(username) {
  const user = await DB.messagingDB.collection('Users').findOne({ username: username });
  if (!user) {
    return undefined;
  }
  return user.requested;
}

async function hasFriend(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').findOne(
    { username: username, friends: friendName },
  );
  if (result) {
    return true;
  }
  return false;
}

// GET /messaging/friends/exists/{user}/{friend}
async function handleGetMessagingFriendExists(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await hasFriend(username, friendName);
    if (result === undefined) {
      return resp.status(404).json('Inexistant User');
    }
    if (result === false) {
      return resp.status(200).json({ message: 'Friend not found', result: false });
    }
    return resp.status(200).json({ message: 'Friend found', result: true });
  } catch (error) {
    return resp.status(400).json('Undefined input');
  }
}

async function hasPending(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').findOne(
    { username: username, pending: friendName },
  );
  if (result) {
    return true;
  }
  return false;
}

// GET /messaging/pending/exists/{user}/{friend}
async function handleGetMessagingPendingExists(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await hasPending(username, friendName);
    if (result === undefined) {
      return resp.status(404).json('Inexistant User');
    }
    if (result === false) {
      return resp.status(200).json({ message: 'Pending friend not found', result: false });
    }
    return resp.status(200).json({ message: 'Pending friend found', result: true });
  } catch (error) {
    return resp.status(400).json('Undefined input');
  }
}

async function hasRequested(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').findOne(
    { username: username, requested: friendName },
  );
  if (result) {
    return true;
  }
  return false;
}

// GET /messaging/requested/exists/{user}/{friend}
async function handleGetMessagingRequestedExists(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await hasRequested(username, friendName);
    if (result === undefined) {
      return resp.status(404).json('Inexistant User');
    }
    if (result === false) {
      return resp.status(200).json({ message: 'Requested friend not found', result: false });
    }
    return resp.status(200).json({ message: 'Requested friend found', result: true });
  } catch (error) {
    return resp.status(400).json('Undefined input');
  }
}

// GET /messaging/friends/first/{user}
async function handleGetMessagingFriendFirst(req, resp) {
  const username = req?.params?.user;
  const result = await getFriendList(username);
  if (result === undefined) {
    return resp.status(400).json('Inexistant User');
  }
  if (result.length === 0) {
    return resp.status(404).json('User has no friends');
  }
  return resp.status(200).json({ message: 'Got first friend', friend: result[0] });
}

// GET /messaging/pending/first/{user}
async function handleGetMessagingPendingFirst(req, resp) {
  const username = req?.params?.user;
  const result = await getPendingList(username);
  if (result === undefined) {
    return resp.status(400).json('Inexistant User');
  }
  if (result.length === 0) {
    return resp.status(404).json('User has no pending friends');
  }
  return resp.status(200).json({ message: 'Got first pending friend', friend: result[0] });
}

// GET /messaging/requested/first/{user}
async function handleGetMessagingRequestedFirst(req, resp) {
  const username = req?.params?.user;
  const result = await getRequestedList(username);
  if (result === undefined) {
    return resp.status(400).json('Inexistant User');
  }
  if (result.length === 0) {
    return resp.status(404).json('User has no requested friends');
  }
  return resp.status(200).json({ message: 'Got first requested friend', friend: result[0] });
}

// GET /messaging/friends/list/{user}
async function handleGetMessagingFriendList(req, resp) {
  const username = req?.params?.user;
  const result = await getFriendList(username);
  if (result === undefined) {
    return resp.status(400).json('Inexistant User');
  }
  return resp.status(200).json({ message: 'Got friend list', list: result });
}

// GET /messaging/pending/list/{user}
async function handleGetMessagingPendingList(req, resp) {
  const username = req?.params?.user;
  const result = await getPendingList(username);
  if (result === undefined) {
    return resp.status(400).json('Inexistant User');
  }
  return resp.status(200).json({ message: 'Got pending list', list: result });
}

// GET /messaging/requested/list/{user}
async function handleGetMessagingRequestedList(req, resp) {
  const username = req?.params?.user;
  const result = await getRequestedList(username);
  if (result === undefined) {
    return resp.status(400).json('Inexistant User');
  }
  return resp.status(200).json({ message: 'Got requested list', list: result });
}

async function putFriend(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const isPreexistingFriend = await hasFriend(username, friendName);
  if (isPreexistingFriend) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').updateOne({ username: username }, { $push: { friends: friendName } });
  // console.log(`Added new friend ${friendName} to ${username}`);
  return result;
}

// PUT /messaging/friends/{user}/{friend}
async function handlePutMessagingFriend(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await putFriend(username, friendName);
    if (result === undefined) {
      return resp.status(200).json('User was already a friend');
    }
    return resp.status(201).json('Added friend');
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

async function putPending(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const isPreexistingPending = await hasPending(username, friendName);
  if (isPreexistingPending) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').updateOne({ username: username }, { $push: { pending: friendName } });
  // console.log(`Added new pending friend ${friendName} to ${username}}`);
  return result;
}

// PUT /messaging/pending/{user}/{friend}
async function handlePutMessagingPending(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await putPending(username, friendName);
    if (result === undefined) {
      return resp.status(200).json('User was already a pending friend');
    }
    return resp.status(201).json('Added pending friend');
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

async function putRequested(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const isPreexistingRequested = await hasRequested(username, friendName);
  if (isPreexistingRequested) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').updateOne({ username: username }, { $push: { requested: friendName } });
  // console.log(`Added new requested friend ${friendName} to ${username}}`);
  return result;
}

// PUT /messaging/requested/{user}/{friend}
async function handlePutMessagingRequested(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await putRequested(username, friendName);
    if (result === undefined) {
      return resp.status(200).json('User was already a requested friend');
    }
    return resp.status(201).json('Added requested friend');
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

async function deleteFriend(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const isPreexistingFriend = await hasFriend(username, friendName);
  if (!isPreexistingFriend) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').updateOne({ username: username }, { $pull: { friends: friendName } });
  // console.log(`Removed friend ${friendName} from ${username}`);
  return result;
}

// DELETE /messaging/friends/{user}/{friend}
async function handleDeleteMessagingFriend(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await deleteFriend(username, friendName);
    if (result === undefined) {
      return resp.status(404).json('Friend not found');
    }
    return resp.status(200).json('Removed friend');
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

async function deletePending(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const isPreexistingPending = await hasPending(username, friendName);
  if (!isPreexistingPending) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').updateOne({ username: username }, { $pull: { pending: friendName } });
  // console.log(`Removed pending friend ${friendName} from ${username}`);
  return result;
}

// DELETE /messaging/pending/{user}/{friend}
async function handleDeleteMessagingPending(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await deletePending(username, friendName);
    if (result === undefined) {
      return resp.status(404).json('Pending friend not found');
    }
    return resp.status(200).json('Removed pending friend');
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

async function deleteRequested(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const isPreexistingRequested = await hasRequested(username, friendName);
  if (!isPreexistingRequested) {
    return undefined;
  }
  const result = await DB.messagingDB.collection('Users').updateOne({ username: username }, { $pull: { requested: friendName } });
  // console.log(`Removed requested friend ${friendName} from ${username}`);
  return result;
}

// DELETE /messaging/pending/{user}/{friend}
async function handleDeleteMessagingRequested(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await deleteRequested(username, friendName);
    if (result === undefined) {
      return resp.status(404).json('Requested friend not found');
    }
    return resp.status(200).json('Removed requested friend');
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

async function getMessageCount(username) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const result = await DB.messagingDB.collection('Users').findOne({ username: username }, { message_count: 1 });
  return result.message_count;
}

// GET /messaging/messagecount/{user}
async function handleGetMessagingCount(req, resp) {
  const username = req?.params?.user;
  try {
    const result = await getMessageCount(username);
    return resp.status(200).json({ message: 'Retrieved message count', count: result });
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

async function writeMessage(username, friendName, message, time, date) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const isPreexistingFriendOne = await hasFriend(username, friendName);
  if (!isPreexistingFriendOne) {
    return undefined;
  }
  const isPreexistingFriendTwo = await hasFriend(friendName, username);
  if (!isPreexistingFriendTwo) {
    return undefined;
  }
  const count = await getMessageCount(friendName);
  const incrCount = +count + 1;
  await DB.messagingDB.collection('Users').updateOne({ username: friendName }, { $set: { message_count: incrCount } });

  const keyOne = [username, friendName];
  const searchResultOne = await DB.messagingDB.collection('Messages').findOne({ pair: JSON.stringify(keyOne) });
  if (searchResultOne) {
    const len = searchResultOne.messages.length;
    const lastEntry = searchResultOne.messages[len - 1].entry;
    const msgCount = lastEntry[4];

    const result = await DB.messagingDB.collection('Messages').updateOne({ pair: JSON.stringify(keyOne) }, {
      $push:
      { messages: { entry: [username, message, time, date, +msgCount + 1] } },
    });
    return result;
  }
  const keyTwo = [friendName, username];
  const searchResultTwo = await DB.messagingDB.collection('Messages').findOne({ pair: JSON.stringify(keyTwo) });
  if (searchResultTwo) {
    const len = searchResultTwo.messages.length;
    const lastEntry = searchResultTwo.messages[len - 1].entry;
    const msgCount = lastEntry[4];

    const result = await DB.messagingDB.collection('Messages').updateOne({ pair: JSON.stringify(keyTwo) }, {
      $push:
      { messages: { entry: [username, message, time, date, +msgCount + 1] } },
    });
    return result;
  }
  const result = await DB.messagingDB.collection('Messages').insertOne({
    pair: JSON.stringify(keyOne),
    messages: [{ entry: [username, message, time, date, 1] }],
  });
  return result;
}

// PUT /messaging/messages/{user}/{friend}
async function handlePutMessagingMessage(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  const message = req?.body?.message;
  const date = req?.body?.date;
  const time = req?.body?.time;
  try {
    const result = await writeMessage(username, friendName, message, time, date);
    if (result === undefined) {
      return resp.status(403).json('Users not friends');
    }
    return resp.status(200).json({ message: 'Message sent' });
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

function parseMessageLog(log) {
  const messageList = [];
  for (let i = 0; i < log.length; i += 1) {
    messageList.push(log[i].entry);
  }
  return messageList;
}

async function getMessageLog(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const isPreexistingFriendOne = await hasFriend(username, friendName);
  if (!isPreexistingFriendOne) {
    return undefined;
  }
  const isPreexistingFriendTwo = await hasFriend(friendName, username);
  if (!isPreexistingFriendTwo) {
    return undefined;
  }
  let messages;
  const keyOne = [username, friendName];
  const searchResultOne = await DB.messagingDB.collection('Messages').findOne({ pair: JSON.stringify(keyOne) }, { messages: 1 });
  if (searchResultOne) {
    messages = searchResultOne.messages;
  } else {
    const keyTwo = [friendName, username];
    const searchResultTwo = await DB.messagingDB.collection('Messages').findOne({ pair: JSON.stringify(keyTwo) }, { messages: 1 });
    if (searchResultTwo) {
      messages = searchResultTwo.messages;
    } else {
      return [];
    }
  }
  return parseMessageLog(messages);
}

// GET /messaging/messages/{user}/{friend}
async function handleGetMessagingMessages(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await getMessageLog(username, friendName);
    if (result === undefined) {
      return resp.status(403).json('Users not friends');
    }
    return resp.status(200).json({ message: 'Retrieved message log', log: result });
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

async function deleteMessageLog(username, friendName) {
  if (username === undefined) {
    throw new Error('undefined username');
  }
  if (friendName === undefined) {
    throw new Error('undefined friendName');
  }
  const isPreexisting = await isPreexistingUser(username);
  if (!isPreexisting) {
    throw new Error('Inexistant user');
  }
  const keyOne = [username, friendName];
  const keyTwo = [friendName, username];
  await DB.messagingDB.collection('Messages').deleteMany({ pair: JSON.stringify(keyOne) });
  await DB.messagingDB.collection('Messages').deleteMany({ pair: JSON.stringify(keyTwo) });
  return true;
}

// DELETE /messaging/messages/{user}/{friend}
async function handleDeleteMessagingMessages(req, resp) {
  const username = req?.params?.user;
  const friendName = req?.params?.friend;
  try {
    const result = await deleteMessageLog(username, friendName);
    if (result === undefined) {
      return resp.status(403).json('Users not friends');
    }
    return resp.status(200).json(`Deleted messages between ${username} and ${friendName}`);
  } catch (error) {
    if (error.message === 'Inexistant user') {
      return resp.status(404).json('Inexistant User');
    }
    return resp.status(400).json('Undefined input');
  }
}

module.exports = {
  messagingCreateUser,
  messagingDeleteUser,
  handlePostMessagingUser,
  handleDeleteMessagingUser,
  handleGetMessagingUserExists,
  handleGetMessagingFriendExists,
  handleGetMessagingPendingExists,
  handleGetMessagingRequestedExists,
  handleGetMessagingFriendFirst,
  handleGetMessagingPendingFirst,
  handleGetMessagingRequestedFirst,
  handleGetMessagingFriendList,
  handleGetMessagingPendingList,
  handleGetMessagingRequestedList,
  handlePutMessagingFriend,
  handlePutMessagingPending,
  handlePutMessagingRequested,
  handleDeleteMessagingFriend,
  handleDeleteMessagingPending,
  handleDeleteMessagingRequested,
  handleGetMessagingCount,
  handlePutMessagingMessage,
  handleGetMessagingMessages,
  handleDeleteMessagingMessages,
};
