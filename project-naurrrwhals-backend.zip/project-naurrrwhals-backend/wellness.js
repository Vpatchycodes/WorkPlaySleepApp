const DB = require('./database');
// const dt = require('./dateTimeFuncs');

// const ignoreID = { projection: { _id: 0 } };

async function wellnessCreateUser(username) {
  await DB.wellnessCollection.insertOne({
    username: username,
    // preferences: null,
    // surveys: [],
    // last_survey: null,
    // last_survey_time: '1970-01-01T01:01',
  });
}

async function wellnessDeleteUser(username) {
  await DB.wellnessCollection.deleteOne({ username: username });
}

// async function handleGetWellnessPreferences(req, resp) {
//   const username = req?.params?.user;
//   if (!username) {
//     return resp.status(400).json('Missing parameters');
//   }

//   const preferences = DB.wellnessCollection.findOne({ username }, ignoreID)?.preferences;
//   if (!preferences) {
//     return resp.status(404).json('Preferences not found');
//   }
//   return resp.status(200).json(preferences);
// }

// async function handlePostWellnessPreferences(req, resp) {
//   const username = req?.params?.user;
//   if (!username) {
//     return resp.status(400).json('Missing parameters');
//   }

//   const query = { username: username };
//   const update = { $set: { preferences: req.body } };
//   const options = {
//     returnNewDocument: true,
//     projection: { _id: 0 },
//   };
//   const pref = await DB.wellnessCollection.findOneAndUpdate(query, update, options)?.preferences;

//   if (!pref) {
//     return resp.status(404).json('Preferences not found');
//   }
//   return resp.status(200).json(pref);
// }

async function handleGetWellnessSurvey(req, resp) {
  const username = req?.params?.user;
  // if (!username) {
  //   return resp.status(400).json('Missing parameters');
  // }

  // const query = { username: username };
  // const lastSurveyTime = DB.wellnessCollection.findOne(query, ignoreID)?.last_survey_time;
  // if (!lastSurveyTime) {
  //   return resp.status(404).json('Survey not found');
  // }

  // const needNew = (dt.extractDateString(lastSurveyTime) !== dt.dateToStringLocal(new Date()));
  // return resp.status(200).json(needNew);

  const query = { username: username };
  const surv = await DB.wellnessCollection.findOne(query, { projection: { _id: 0, username: 0 } });
  if (!surv) {
    return resp.status(404).json('Survey not found');
  }

  const userObj = await DB.usersCollection.findOne(
    { username: username },
    { projection: { _id: 0 } },
  );
  if (!userObj) {
    return resp.status(404).send({ error: 'User does not exist' });
  }

  return resp.status(200).json(surv);
}

async function handlePutWellnessSurvey(req, resp) {
  const username = req?.params?.user;
  // if (!username) {
  //   return resp.status(400).json('Missing parameters');
  // }

  // const lastSurveyTime = (await DB.wellnessCollection.findOne({ username }))?.last_survey_time;
  // if (dt.extractDateString(lastSurveyTime) === dt.datetimeToStringLocal(new Date())) {
  //   return resp.status(403).json('Already filled out today');
  // }

  // const query = { username: username };
  // const update = {
  //   $set: {
  //     last_survey: req.body,
  //     last_survey_time: dt.datetimeToStringLocal(new Date()),
  //   },
  //   $push: {
  //     surveys: req.body,
  //   },
  // };
  // const opt = {
  //   returnNewDocument: true,
  //   projection: { _id: 0 },
  // };
  // const surv = (await DB.wellnessCollection.findOneAndUpdate(query, update, opt))?.last_survey;

  // if (!surv) {
  //   return resp.status(404).json('Survey not found');
  // }
  // return resp.status(200).json(surv);

  const query = { username: username };
  const update = { $set: req.body };
  const options = {
    returnNewDocument: true,
    projection: { _id: 0, username: 0 },
  };
  let surv = (await DB.wellnessCollection.findOneAndUpdate(query, update, options));
  if (surv.value) {
    surv = surv.value;
  }

  if (!surv) {
    return resp.status(404).json('Survey not found');
  }

  return resp.status(200).json(surv);
}

const handlePostWellnessSurvey = handlePutWellnessSurvey;

module.exports = {
  wellnessCreateUser,
  wellnessDeleteUser,
  // handleGetWellnessPreferences,
  // handlePostWellnessPreferences,
  handleGetWellnessSurvey,
  handlePostWellnessSurvey,
  handlePutWellnessSurvey,
};
