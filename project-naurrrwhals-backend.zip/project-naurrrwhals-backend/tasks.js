const DB = require('./database');
const dt = require('./dateTimeFuncs');

const ignoreID = { projection: { _id: 0 } };

async function tasksCreateUser(username) {
  await DB.tasksDB.createCollection(username);
}

async function tasksDeleteUser(username) {
  await DB.tasksDB.collection(username).drop();
}

async function handleGetTasksTasklist(req, resp) {
  const username = req?.params?.user;
  // if (!username) {
  //   return resp.status(400).json('Missing parameters');
  // }
  const collection = DB.tasksDB.collection(username);
  const found = await collection.find({}, ignoreID).toArray();
  return resp.status(200).json(found);
}

async function handlePostTasksCreate(req, resp) {
  const username = req?.params?.user;
  const dueDate = req?.body?.due_date;
  const title = req?.body?.title;
  const progress = req?.body?.progress || 0;
  const notes = req?.body?.notes || '';

  if (!username || !dueDate || !title) {
    return resp.status(400).json('Missing parameters');
  }
  if (!dt.validDateTime(dueDate) || !Number.isInteger(progress) || progress < 0 || progress > 100) {
    return resp.status(400).json('Invalid parameters');
  }

  const newObj = {
    due_date: dueDate,
    title: title,
    progress: progress,
    notes: notes,
  };
  const collection = DB.tasksDB.collection(username);
  const { insertedId } = await collection.insertOne(newObj);

  const query = { _id: insertedId };
  const update = { $set: { task_id: insertedId.toString() } };
  const options = {
    returnDocument: 'after',
    upsert: true,
    projection: { _id: 0 },
  };
  let taskObj = await collection.findOneAndUpdate(query, update, options);
  if (taskObj.value) {
    taskObj = taskObj.value;
  }
  if (!taskObj) {
    return resp.status(404).json('Task not found');
  }
  return resp.status(201).json(taskObj);
}

async function handleGetTasksTaskID(req, resp) {
  const taskID = req?.params?.task_id;
  const username = req?.params?.user;
  // if (!username || !taskID) {
  //   return resp.status(400).json('Missing parameters');
  // }
  const collection = DB.tasksDB.collection(username);
  const taskObj = await collection.findOne({ task_id: taskID }, ignoreID);
  if (!taskObj) {
    return resp.status(404).json('Task not found');
  }
  return resp.status(200).json(taskObj);
}

async function handlePutTasksTaskID(req, resp) {
  const username = req?.params?.user;
  const taskID = req?.params?.task_id;
  const dueDate = req?.body?.due_date;
  const title = req?.body?.title;
  const progress = req?.body?.progress || 0;
  const notes = req?.body?.notes || '';
  if (!username || !taskID || !dueDate || !title) {
    return resp.status(400).json('Missing parameters');
  }
  if (!dt.validDateTime(dueDate)
    || !Number.isInteger(progress)
    || progress < 0
    || progress > 100
  ) {
    return resp.status(400).json('Invalid parameters');
  }

  const query = { task_id: taskID };
  const replacement = {
    task_id: taskID,
    due_date: dueDate,
    title: title,
    progress: progress,
    notes: notes,
  };
  const options = {
    returnDocument: 'after',
    projection: { _id: 0 },
  };
  const collection = DB.tasksDB.collection(username);
  const taskObj = await collection.findOneAndReplace(query, replacement, options);
  if (!taskObj) {
    return resp.status(404).json('Task not found');
  }
  return resp.status(200).json(taskObj);
}

async function handleDeleteTasksTaskID(req, resp) {
  const taskID = req?.params?.task_id;
  const username = req?.params?.user;
  // if (!username || !taskID) {
  //   return resp.status(400).json('Missing parameters');
  // }
  const tasksCollection = DB.tasksDB.collection(username);
  const deleteResult = await tasksCollection.deleteOne({ task_id: taskID });
  if (!deleteResult?.deletedCount) {
    return resp.status(404).json('Task not found');
  }
  return resp.status(200).json('Deleted');
}

module.exports = {
  tasksCreateUser,
  tasksDeleteUser,
  handleGetTasksTasklist,
  handlePostTasksCreate,
  handleGetTasksTaskID,
  handlePutTasksTaskID,
  handleDeleteTasksTaskID,
};
