# project-naurrrwhals-backend
Backend/deployment for cis350/project-naurrrwhals.

## To get the most recent version of the frontend:

* Run `git submodule update --recursive --remote --init --merge`

## To setup and compile:
* Create a file called `.env` in the root directory. Define `DATABASE_URL=` as the url of the database, including username and password. (The URL is available upon request).
* Run `npm run build`

## To run:
* Run `npm start`
