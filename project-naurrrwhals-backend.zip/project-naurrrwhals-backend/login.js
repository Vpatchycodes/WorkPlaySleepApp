const crypto = require('crypto');
const DB = require('./database');
const calendar = require('./calendar');
const messaging = require('./messaging');
const wellness = require('./wellness');
const tasks = require('./tasks');

// Returns error if the given string is not a valid username
function validUsername(str) {
  return (
    str.match(/^[A-Za-z0-9_]*$/)
    && str.match(/^[A-Za-z_][A-Za-z0-9_]*$/)
    && str.match(/[A-Za-z0-9]/)
    && (str.length >= 3)
  );
}

function validPassword(str) {
  return (
    str.match(/^[A-Za-z0-9\\!"#$%&'()*+,\-./:;<=>?@[\]^_`{|}~]+$/)
    && (str.length >= 6)
  );
}

function validSecurityQuestions(arr) {
  return Array.isArray(arr) && arr.every((el) => {
    const q = el?.question;
    const a = el?.answer;
    return (
      q && a
      && (typeof q === 'string' || q instanceof String)
      && (typeof a === 'string' || a instanceof String)
    );
  });
}

function hashPassword(str) {
  const hash = crypto.createHash('SHA3-512');
  hash.update(str);
  return hash.digest('base64');
}

async function createNewUser(username, password, securityQuestions) {
  try {
    await DB.usersCollection.insertOne({
      username,
      hashed_password: hashPassword(password),
      security_questions: securityQuestions,
      registration_date: (new Date()).getTime(),
      login_attempts: [0, 0, 0],
    });
  } catch (err) {
    console.log('\nError caught in createNewUser');
    console.log(err);
  }

  try {
    await calendar.calendarCreateUser(username);
  } catch (err) {
    console.log('\nError caught from calendarCreateUser:');
    console.log(err);
  }
  try {
    await messaging.messagingCreateUser(username);
  } catch (err) {
    console.log('\nError caught from messagingCreateUser:');
    console.log(err);
  }
  try {
    await wellness.wellnessCreateUser(username);
  } catch (err) {
    console.log('\nError caught from wellnessCreateUser:');
    console.log(err);
  }
  try {
    await tasks.tasksCreateUser(username);
  } catch (err) {
    console.log('\nError caught from tasksCreateUser:');
    console.log(err);
  }
}

async function deleteUser(username) {
  try {
    await DB.usersCollection.deleteOne({ username: username });
  } catch (err) {
    console.log('\nError caught in deleteUser:');
    console.log(err);
  }

  try {
    await calendar.calendarDeleteUser(username);
  } catch (err) {
    console.log('\nError caught from calendarDeleteUser:');
    console.log(err);
  }
  try {
    await messaging.messagingDeleteUser(username);
  } catch (err) {
    console.log('\nError caught from messagingDeleteUser:');
    console.log(err);
  }
  try {
    await wellness.wellnessDeleteUser(username);
  } catch (err) {
    console.log('\nError caught from wellnessDeleteUser:');
    console.log(err);
  }
  try {
    await tasks.tasksDeleteUser(username);
  } catch (err) {
    console.log('\nError caught from tasksDeleteUser:');
    console.log(err);
  }
}

async function handlePostLogin(req, resp) {
  const username = req?.body?.username;
  const password = req?.body?.password;
  if (!username || !password) {
    return resp.status(400).json({ error: 'Missing parameters' });
  }
  if (!validUsername(username) || !validPassword(password)) {
    return resp.status(400).json({ error: 'Invalid parameters' });
  }

  const userObj = await DB.usersCollection.findOne(
    { username: username },
    { projection: { _id: 0 } },
  );
  if (!userObj) {
    return resp.status(404).json({ error: 'User does not exist' });
  }

  const time = (new Date()).getTime();
  const oneHour = 60 * 60 * 1000; // 1 hour in milliseconds
  const leastRecent = Math.min(...userObj.login_attempts);
  const sinceLeastRecent = time - leastRecent;
  if (sinceLeastRecent < oneHour) {
    return resp.status(403).json(oneHour - sinceLeastRecent);
  }

  if (userObj.hashed_password !== hashPassword(password)) {
    // Track unsuccesful login attempts
    userObj.login_attempts.push(time);
    userObj.login_attempts.shift();
    await DB.usersCollection.replaceOne(
      { username: username },
      userObj,
    );

    return resp.status(401).json({ error: 'Incorrect password' });
  }

  userObj.login_attempts = (new Array(userObj.login_attempts.length)).fill(0);
  await DB.usersCollection.replaceOne(
    { username: username },
    userObj,
  );

  return resp.status(200).json({ message: 'Logged in' });
}

async function handlePostRegister(req, resp) {
  const username = req?.body?.username;
  const password = req?.body?.password;
  const securityQuestions = req?.body?.security_questions || [];
  if (!username || !password) {
    return resp.status(400).json({ error: 'Missing parameters' });
  }
  if (!validUsername(username)
    || !validPassword(password)
    || (securityQuestions && !validSecurityQuestions(securityQuestions))) {
    return resp.status(400).json({ error: 'Invalid parameters' });
  }

  const userObj = await DB.usersCollection.findOne(
    { username: username },
    { projection: { _id: 0 } },
  );
  if (userObj) {
    return resp.status(403).json({ error: 'User already exists' });
  }

  await createNewUser(username, password, securityQuestions);

  return resp.status(204).json({ message: 'Registered' });
}

async function handlePostSecurityQuestionsUser(req, resp) {
  const username = req?.params?.user;

  let securityQuestions = null;
  if (Array.isArray(req.body)) {
    securityQuestions = req.body;
  } else if (Array.isArray(req.body.security_questions)) {
    securityQuestions = req.body.security_questions;
  } else if (req.body.question && req.body.answer) {
    securityQuestions = [req.body];
  }

  if (!username || !securityQuestions) {
    return resp.status(400).json({ error: 'Missing parameters' });
  }

  if (!validUsername(username) || !validSecurityQuestions(securityQuestions)) {
    return resp.status(400).json({ error: 'Invalid parameters' });
  }

  // const userObj = await DB.usersCollection.findOne(
  //   { username: username },
  //   { projection: { _id: 0 } },
  // );
  // if (!userObj) {
  //   return resp.status(404).json({ error: 'User does not exist' });
  // }

  const query = { username: username };
  const update = { $push: { security_questions: { $each: securityQuestions } } };
  const updateResult = await DB.usersCollection.updateOne(query, update);
  if (!updateResult?.matchedCount && !updateResult?.modifiedCount) {
    return resp.status(404).json({ error: 'User does not exist' });
  }

  return resp.status(201).json({ message: 'Added' });
}

async function handleDeleteDeleteuser(req, resp) {
  const username = req?.params?.user;
  // if (!username) {
  //   return resp.status(400).json({ error: 'Missing parameters' });
  // }
  // if (!validUsername(username)) {
  //   return resp.status(400).json({ error: 'Invalid parameters' });
  // }

  const userObj = await DB.usersCollection.findOne(
    { username: username },
    { projection: { _id: 0 } },
  );
  if (!userObj) {
    return resp.status(404).json({ error: 'User does not exist' });
  }

  await deleteUser(username);

  return resp.status(200).json({ message: 'Deleted' });
}

async function handleGetSecurityQuestionsUser(req, resp) {
  const username = req?.params?.user;
  // if (!username) {
  //   return resp.status(400).json({ error: 'Missing parameters' });
  // }
  // if (!validUsername(username)) {
  //   return resp.status(400).json({ error: 'Invalid parameters' });
  // }

  const userObj = await DB.usersCollection.findOne(
    { username: username },
    { projection: { _id: 0 } },
  );

  if (!userObj) {
    return resp.status(404).json({ error: 'User does not exist' });
  }

  const questions = userObj?.security_questions?.map((el) => el.question);

  if (!questions?.length) {
    return resp.status(405).json([]);
  }

  return resp.status(200).json(questions);
}

async function handlePostResetpasswordUser(req, resp) {
  const username = req?.params?.user;
  const newPassword = req?.body?.new_password;
  const securityQuestions = req?.body?.security_questions;
  if (!username || !newPassword || !securityQuestions) {
    return resp.status(400).json('Missing parameters');
  }
  if (!validUsername(username)
    || !validPassword(newPassword)
    || !validSecurityQuestions(securityQuestions)) {
    return resp.status(400).json('Invalid parameters');
  }

  const userObj = await DB.usersCollection.findOne(
    { username: username },
    { projection: { _id: 0 } },
  );
  if (!userObj) {
    return resp.status(404).json('User not found');
  }
  if (!(userObj?.security_questions?.length)) {
    return resp.status(405).json('User does not have security questions');
  }

  function cmp(a, b) {
    // eslint-disable-next-line no-nested-ternary
    return (a < b ? -1 : (a > b ? 1 : 0));
  }

  function comparator(a, b) {
    return cmp(a.question, b.question);
  }

  securityQuestions.sort(comparator);
  const expectedSecurityQuestions = userObj.security_questions.sort(comparator);
  if (JSON.stringify(securityQuestions) !== JSON.stringify(expectedSecurityQuestions)) {
    // console.log(JSON.stringify(securityQuestions));
    // console.log(JSON.stringify(expectedSecurityQuestions));
    return resp.status(403).json('Incorrect answers');
  }

  const loginAttempts = (new Array(userObj.login_attempts.length)).fill(0);

  await DB.usersCollection.updateOne(
    { username: username },
    {
      $set: {
        hashed_password: hashPassword(newPassword),
        login_attempts: loginAttempts,
      },
    },
  );

  return resp.status(200).json('Reset');
}

module.exports = {
  handlePostLogin,
  handlePostRegister,
  handlePostSecurityQuestionsUser,
  handleDeleteDeleteuser,
  handleGetSecurityQuestionsUser,
  handlePostResetpasswordUser,
};
