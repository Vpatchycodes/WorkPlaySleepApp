/* eslint-disable lines-between-class-members */
/* eslint-disable no-underscore-dangle */

require('dotenv').config();

const { MongoClient, ServerApiVersion } = require('mongodb');

const databaseURL = process.env.DATABASE_URL;

class DB {
  constructor() {
    throw new Error('Error: DB is a static-only class');
  }
  static #client = null;

  static #usersCollection = null;
  static get usersCollection() { return DB.#usersCollection; }

  static #wellnessCollection = null;
  static get wellnessCollection() { return DB.#wellnessCollection; }

  static #eventsDB = null;
  static get eventsDB() { return DB.#eventsDB; }

  static #blobsDB = null;
  static get blobsDB() { return DB.#blobsDB; }

  static #tasksDB = null;
  static get tasksDB() { return DB.#tasksDB; }

  static #messagingDB = null;
  static get messagingDB() { return DB.#messagingDB; }

  static async connectToDatabases() {
    try {
      await DB.disconnectFromDatabases();
      DB.#client = (await MongoClient.connect(
        databaseURL,
        {
          useNewUrlParser: true,
          useUnifiedTopology: true,
          serverApi: ServerApiVersion.v1,
        },
      ));
      DB.#usersCollection = DB.#client.db('Users').collection('Users');
      DB.#wellnessCollection = DB.#client.db('Users').collection('Wellness');
      DB.#eventsDB = DB.#client.db('Events');
      DB.#blobsDB = DB.#client.db('Blobs');
      DB.#tasksDB = DB.#client.db('Tasks');
      DB.#messagingDB = DB.#client.db('Messaging');
    } catch (err) {
      console.error(err);
      throw new Error('Could not connect to the database');
    }
    console.log('Succesfully connected to the database');
  }

  static async disconnectFromDatabases() {
    if (!DB.#client) {
      return;
    }
    try {
      await DB.#client.close();
      DB.#client = null;
      DB.#usersCollection = null;
      DB.#wellnessCollection = null;
      DB.#eventsDB = null;
      DB.#blobsDB = null;
      DB.#tasksDB = null;
      DB.#messagingDB = null;
    } catch (err) {
      console.error(err);
      throw new Error('Could not disconnect from the database');
    }
    console.log('Succesfully disconnected from the database');
  }
}

module.exports = DB;
